<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Po_Bahan extends Model
{
    protected $table = 'po_bahan';
    protected $primaryKey = 'id_po_bahan';
    protected $allowedFields = [
        'id_po_bahan', 'tanggal', 'supplier', 'jatuh_tempo', 'keterangan',
        'no_ro', 'asuransi', 'jenis_mobil', 'warna', 'nama_pemilik', 'no_kendaraan', 'total_qty',
        'total_jumlah'
    ];

    

    public function generateId()
    {
        $builder = $this->db->table($this->table);
        $builder->select('id_po_bahan');
        $builder->orderBy('id_po_bahan', 'DESC');
        $builder->limit(1);
        $query = $builder->get();
        $result = $query->getRow();

        if ($result) {
            $last_id = $result->id_po_bahan;
            $last_number = intval(substr($last_id, -3));
            $new_number = $last_number + 1;
            $new_id = 'PO' . date('Ymd') . str_pad($new_number, 3, '0', STR_PAD_LEFT);
        } else {
            $new_id = 'PO' . date('Ymd') . '001';
        }

        return $new_id;
    }

    public function getAllSupplier()
    {
        $builder = $this->db->table('supplier');
        $builder->select('kode, nama');
        $query = $builder->get();
        return $query->getResult();
    }

    public function getAllBarang()
    {
        $builder = $this->db->table('barang');
        $builder->select('kode, nama, sat_B, hargabeli_B');
        $query = $builder->get();
        return $query->getResult();
    }
}
