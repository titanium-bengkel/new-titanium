<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Detail_Barang extends Model
{
    protected $table = 'detail_barang';
    protected $primaryKey = 'id_kode_barang';

    protected $allowedFields = [
        'id_kode_barang', 
        'nama_barang', 
        'qty', 
        'satuan', 
        'harga', 
        'jumlah', 
        'qty_beli', 
        'qty_sisa', 
        'no_faktur', 
        'tgl_faktur',
        'id_po_bahan'
    ];
}
