<?php

namespace App\Models;

use CodeIgniter\Model;

class Model_api extends Model
{

    function __construct()
    {
        // $this->url = 'https://apititanium.ankabuttech.com/office/';
        $this->url = 'https://devapi.bengkeltitanium.com//office/';
    }

    function get_login($username, $password)
    {
        // echo $username."-".$password; die();

        $curl = curl_init();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://apititanium.ankabuttech.com/office/apiauth',
            CURLOPT_URL => $this->url . 'apiauth',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('username' => $username, 'password' => $password),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function showdata($keyCodeStaff, $secret, $api_name)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://apititanium.ankabuttech.com/office/'.$api_name,
            CURLOPT_URL => $this->url . $api_name,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function GetNotrans($keyCodeStaff, $secret, $api_name, $tanggalmasuk)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://apititanium.ankabuttech.com/office/'.$api_name,
            CURLOPT_URL => $this->url . $api_name,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","tanggalmasuk":"' . $tanggalmasuk . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function cekberkas($keyCodeStaff, $secret, $api_name, $kode)
    {
        //echo $this->url.$api_name;
        $curl = curl_init();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://apititanium.ankabuttech.com/office/'.$api_name,
            CURLOPT_URL => $this->url . $api_name,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","kode":"' . $kode . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function showdata_with_page($keyCodeStaff, $secret, $api_name, $page, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://apititanium.ankabuttech.com/office/'.$api_name,
            CURLOPT_URL => $this->url . $api_name,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","page":"' . $page . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function showdata_with_filter_user($keyCodeStaff, $secret, $api_name, $page, $cari_data, $tgl1, $tgl2, $sortby, $progres, $cari_user, $statusbayar)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://apititanium.ankabuttech.com/office/'.$api_name,
            CURLOPT_URL => $this->url . $api_name,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","page":"' . $page . '","cari_data":"' . $cari_data . '","tgl1":"' . $tgl1 . '","tgl2":"' . $tgl2 . '","sortby":"' . $sortby . '","progres":"' . $progres . '","cari_user":"' . $cari_user . '","statusbayar":"' . $statusbayar . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }



    function showdata_with_filter($keyCodeStaff, $secret, $api_name, $page, $cari_data, $tgl1, $tgl2, $sortby, $progres)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://apititanium.ankabuttech.com/office/'.$api_name,
            CURLOPT_URL => $this->url . $api_name,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","page":"' . $page . '","cari_data":"' . $cari_data . '","tgl1":"' . $tgl1 . '","tgl2":"' . $tgl2 . '","sortby":"' . $sortby . '","progres":"' . $progres . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function showdatadetail($keyCodeStaff, $secret, $api_name, $kode)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://apititanium.ankabuttech.com/office/'.$api_name,
            CURLOPT_URL => $this->url . $api_name,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","kode":"' . $kode . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function postdata($datapost, $api_name)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            // CURLOPT_URL => 'https://apititanium.ankabuttech.com/office/'.$api_name,
            CURLOPT_URL => $this->url . $api_name,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $datapost,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function useradmin_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/adminview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function useradmingrup_view($keyCodeStaff, $secret, $id_user)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/admingrupview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","id_user":"' . $id_user . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function fatloss_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/fatlossview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function fatloss_viewv2($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/mealfatloss',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function weightgain_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/weightgainview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function weightgain_viewv2($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/mealweightgain',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function mealevent_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/mealevent',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function weightgain_update($data)
    {
        $headers = array("Content-Type" => "multipart/form-data");
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/weightgain',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function weightgainv2_update($data)
    {
        $headers = array("Content-Type" => "multipart/form-data");
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/mealedit',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function mealevent_update($data)
    {
        $headers = array("Content-Type" => "multipart/form-data");
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/mealedit',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function fatloss_update($data)
    {
        $headers = array("Content-Type" => "multipart/form-data");
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/fatloss',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function fatlossv2_update($data)
    {
        $headers = array("Content-Type" => "multipart/form-data");
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/mealedit',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function jadwal_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/scheduleview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function general_class($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/schedulegeneral',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function coaching_class($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/schedulecoaching',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function jadwal_insert($dataJadwal)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/scheduleadd',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataJadwal,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function admin_insert($dataJadwal)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/adminadd',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataJadwal,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function jadwal_edit($dataJadwal)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/scheduleupdate',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataJadwal,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function jadwal_delete($dataDelete)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/scheduledelete',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataDelete,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function member_update($data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/userupdate',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function tones_view($keyCodeStaff, $secret, $toneslevel)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/tones',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","level":"' . $toneslevel . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function tones_insert($dataTones)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/tonesadd',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataTones,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function tones_edit($dataTones)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/tonesupdate',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataTones,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function order_view($keyCodeStaff, $secret, $page)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/orderview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","page":"' . $page . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function order_detail($keyCodeStaff, $secret, $trx_id)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/orderdetail',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","idtransaction":"' . $trx_id . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function tones_user_view($dataTonesUser)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/tonesuser',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataTonesUser,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function tones_code_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/codeview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function grup_view($keyCodeStaff, $secret, $is_coach, $id_user)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/gruopview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","is_coach":"' . $is_coach . '","id_user":"' . $id_user . '"}'),
            // CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"'.$keyCodeStaff.'","secret":"'.$secret.'"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function order_edit($dataOrder)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/orderupdate',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataOrder,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function order_entry($dataOrder)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/ordercreate',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataOrder,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function usermember($keyCodeStaff, $secret)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/usermember',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","page":"0"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function fatloss_puasa_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/fatpuasaview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function fatloss_puasa_update($data)
    {
        $headers = array("Content-Type" => "multipart/form-data");
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/fatpuasa',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function weighpuasa_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/weightpuasaview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function weighgain_puasa_update($data)
    {
        $headers = array("Content-Type" => "multipart/form-data");
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/weightgainpuasa',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $data,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function quote_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/viewqoute',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function quote_insert($dataQuote)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/addqoute',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataQuote,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function useradmingrup_insert($datagrup)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/useradmingrupinsert',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $datagrup,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function quote_edit($dataQuote)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/editqoute',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $dataQuote,
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function affiliate_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/affiliateview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }


    function Jurnalprogrestubuh($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/progrestubuh',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function fittest_member($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/fittest',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function daily_activity($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/dailyactivity',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function informasi_tubuh($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/informasitubuh',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function absen_member($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/absen',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function not_absen_member($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/notabsen',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function not_progres_tubuh($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/notprogrestubuh',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function not_fittest($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/notfittest',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function not_dailyactivity($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/notdailyactivity',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }


    function not_toneuser($keyCodeStaff, $secret, $grup, $bulan_post, $tahun_post, $cari_data)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/nottoneuser',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","grup":"' . $grup . '","bulan_post":"' . $bulan_post . '","tahun_post":"' . $tahun_post . '","cari_data":"' . $cari_data . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function affiliate_member($keyCodeStaff, $secret, $affiliate_code)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/affiliatemeber',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","code":"' . $affiliate_code . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function affiliate_edit($keyCodeStaff, $secret, $idaffiliate, $status, $persentase)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/affiliatestatus',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","status":"' . $status . '","idaffiliate":"' . $idaffiliate . '","persentase":"' . $persentase . '"}'),
        ));


        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function withdraw_approve($keyCodeStaff, $secret, $id_withdraw, $kode_bank, $rekening, $nominal, $biaya_trf)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/wd_approve',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '","id_withdraw":"' . $id_withdraw . '","kode_bank":"' . $kode_bank . '","rekening":"' . $rekening . '","nominal":"' . $nominal . '","biaya_trf":"' . $biaya_trf . '"}'),
        ));


        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function withdraw_view($keyCodeStaff, $secret)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.lisfits.com/office/withdrawview',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('data' => '{"keyCodeStaff":"' . $keyCodeStaff . '","secret":"' . $secret . '"}'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
}
