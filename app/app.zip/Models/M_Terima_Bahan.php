<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Terima_Bahan extends Model
{
    protected $table = 'terima_bahan';
    protected $primaryKey = 'id_penerimaan';
    protected $allowedFields = [
        'id_penerimaan', 'tanggal', 'supplier', 'jatuh_tempo', 'keterangan',
        'gudang', 'no_kendaraan', 'kota', 'alamat', 'nopol', 'pembayaran', 'ppn', 'term',
        'total_qty', 'total_jumlah', 'nilai_ppn', 'netto'
    ];

    // Method to generate a unique ID for 'terima_bahan'
    public function generateIdTerima()
    {
        $builder = $this->db->table($this->table);
        $builder->select('id_penerimaan');
        $builder->orderBy('id_penerimaan', 'DESC');
        $builder->limit(1);
        $query = $builder->get();
        $result = $query->getRow();

        if ($result) {
            $last_id = $result->id_penerimaan;
            $last_number = intval(substr($last_id, -3));
            $new_number = $last_number + 1;
            $new_id = 'PC' . date('Ymd') . str_pad($new_number, 3, '0', STR_PAD_LEFT);
        } else {
            $new_id = 'PC' . date('Ymd') . '001';
        }

        return $new_id;
    }

    public function getAllSupplier()
    {
        $builder = $this->db->table('supplier');
        $builder->select('kode, nama, alamat, kota');
        $query = $builder->get();
        return $query->getResult();
    }

    public function getAllBarang()
    {
        $builder = $this->db->table('barang');
        $builder->select('kode, nama, sat_B, hargabeli_B');
        $query = $builder->get();
        return $query->getResult();
    }

    // public function getAllSupplier()
    // {
    //     return $this->db->table('supplier')->get()->getResult();
    // }

    // public function getAllPoBahan()
    // {
    //     return $this->db->table('po_bahan')->get()->getResult();
    // }

    // public function getDetailBahan()
    // {
    //     return $this->db->table('detail_barang')->get()->getResult();
    // }
}
