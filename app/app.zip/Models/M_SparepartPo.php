<?php

namespace App\Models;

use CodeIgniter\Model;

class M_SparepartPo extends Model
{
    protected $table = 'sparepart_po';
    protected $primaryKey = 'id_sparepart_po';

    // Daftar field yang dapat diisi
    protected $allowedFields = [
        'id_terima_po',
        'kode_sparepart',
        'nama_sparepart',
        'qty',
        'harga',
        'total_qty',
        'total_harga',
        'kode_pengerjaan',
        'jenis_part'
    ];

    // Set time columns to true if you are using created_at and updated_at
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getAllSparepartPo()
    {
        $builder = $this->db->table('barang');
        $builder->select('kode, nama, hargabeli_B as harga');
        $query = $builder->get();
        return $query->getResultArray(); // Mengembalikan array asosiatif
    }

    public function getPengerjaanByIdTerimaPo($id_terima_po)
    {
        $builder = $this->db->table('pengerjaan_po');
        $builder->select('kode_pengerjaan, nama_pengerjaan');
        $builder->where('id_terima_po', $id_terima_po); // Filter berdasarkan id_terima_po
        $query = $builder->get();
        return $query->getResultArray(); // Mengembalikan array asosiatif
    }

    public function getSparepartByIdTerimaPo($id_terima_po)
    {
        $builder = $this->db->table('sparepart_po');
        $builder->select('id_sparepart_po, kode_sparepart, nama_sparepart, qty, harga, total_harga, kode_pengerjaan, jenis_part');
        $builder->where('id_terima_po', $id_terima_po); // Filter berdasarkan id_terima_po
        $query = $builder->get();
        return $query->getResultArray();
    }
}
