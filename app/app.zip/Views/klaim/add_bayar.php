<?= $this->extend('layout/template'); ?>
<?= $this->section('content') ?>
<h3>Asuransi</h3>

<!-- Horizontal Input start -->
<section id="horizontal-input">
    <div class="row">
        <div class="container mt-4">
            <div class="card">
                <div class="card-body">
                    <div class="form-group row align-items-center">
                        <div class="col-md-6">
                            <div class="row align-items-center">
                                <div class="col-lg-4 col-4 mb-3">
                                    <label class="col-form-label" for="id-bayar">Id pembayaran</label>
                                </div>
                                <div class="col-lg-8 col-8 mb-3">
                                    <input type="text" id="id-bayar" class="form-control" name="id-bayar" disabled>
                                </div>
                                <div class="col-lg-4 col-4 mb-3">
                                    <label class="col-form-label" for="tgl">Tanggal</label>
                                </div>
                                <div class="col-lg-8 col-8 mb-3">
                                    <input type="date" id="tgl" class="form-control" name="tgl" onkeydown="return false" onclick="this.showPicker()">
                                </div>
                                <div class="col-lg-4 col-4">
                                    <label class="col-form-label" for="keterangan">Keterangan</label>
                                </div>
                                <div class="col-lg-8 col-8">
                                    <textarea class="form-control" id="keterangan" rows="1"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row align-items-center">
                                <div class="col-lg-4 col-4 mb-3">
                                    <label class="col-form-label" for="total-kredit">Total kredit</label>
                                </div>
                                <div class="col-lg-8 col-8 mb-3">
                                    <input type="text" id="total-kredit" class="form-control" name="total-kredit">
                                </div>
                                <div class="col-lg-4 col-4 mb-3">
                                    <label class="col-form-label" for="total-debet">Total debet</label>
                                </div>
                                <div class="col-lg-8 col-8 mb-3">
                                    <input type="text" id="total-debet" class="form-control" name="total-debet">
                                </div>
                                <div class="col-lg-4 col-4 mb-3">
                                    <label class="col-form-label" for="selisih">Selisih</label>
                                </div>
                                <div class="col-lg-8 col-8 mb-3">
                                    <input type="text" id="selisih" class="form-control" name="selisih">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="button" class="btn btn-primary">Simpan</button>
                        <button type="button" class="btn btn-danger">Batal</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>No invoice</th>
                                    <th>Tgl Invoice</th>
                                    <th>Keterangan Invoice</th>
                                    <th>Nama asuransi</th>
                                    <th>Jasa</th>
                                    <th>Sparepart</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="8" class="text-bold-500">
                                        <!-- button modal -->
                                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalinvo">
                                            Add Invoice
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>No invoice</th>
                                    <th>Pembayaran</th>
                                    <th>No bukti /BG /SO</th>
                                    <th>Kode bank</th>
                                    <th>Debet</th>
                                    <th>Jatuh tempo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="7" class="text-bold-500">
                                        <!-- button modal -->
                                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#entryPembayaranModal">
                                            Pembayaran
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Horizontal Input end -->


<!-- Modal Input Invo -->
<div class="modal fade text-left" id="modalinvo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Entry invoice yang telah terima pembayaran</h5>
                <button type="button" class="close rounded-pill" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="col-md-12 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <form class="form form-horizontal">
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label for="nomor-invoice">Nomor Invoice </label>
                                            </div>
                                            <div class="col-md-7 form-group">
                                                <input type="text" id="nomor-invoice" class="form-control" name="fname">
                                            </div>
                                            <div class="col-lg-1 col-2 mb-3">
                                                <button type="button" class="btn btn-secondary btn-sm" data-toggle="modal" data-target="#secondarymodal">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="tgl-invo">Tgl.Invoice </label>
                                            </div>
                                            <div class="col-md-8 form-group">
                                                <input type="text" id="tgl-invo" class="form-control" name="fname">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="asur">Asuransi</label>
                                            </div>
                                            <div class="col-md-8 form-group">
                                                <input type="text" id="asur" class="form-control" name="fname">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="jasaa">Jasa</label>
                                            </div>
                                            <div class="col-md-8 form-group">
                                                <input type="text" id="jasaa" class="form-control" name="fname">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="spare-part">Sparepart</label>
                                            </div>
                                            <div class="col-md-8 form-group">
                                                <input type="text" id="spare-part" class="form-control" name="fname">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="ket">Keterangan</label>
                                            </div>
                                            <div class="col-md-8 form-group">
                                                <input type="text" id="ket" class="form-control" name="fname">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ms-1" data-dismiss="modal">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Submit</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Invoice sebagai modal sekunder -->
<div class="modal fade text-left" id="secondarymodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document" style="max-width: 60%;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel2">Masukan Invoice</h5>
                <button type="button" class="close rounded-pill" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="search-input">Cari</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="search-input" class="form-control" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Jenis Mobil</th>
                                <th>Tanggal</th>
                                <th>Type mobil</th>
                                <th>Nopol</th>
                                <th>Warna</th>
                                <th>Tahun</th>
                                <th>Asuransi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ms-1" data-dismiss="modal">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Submit</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- modal pembayaran -->
<div class="modal fade" id="entryPembayaranModal" tabindex="-1" aria-labelledby="entryPembayaranModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="entryPembayaranModalLabel">Entry Pembayaran</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="row g-3 mb-3">
                        <div class="col-md-2">
                            <select id="kodeBayar" class="form-select">
                                <option selected>-- Kode Bayar --</option>
                                <option value="1">Transfer</option>
                                <option value="2">TITIP</option>
                                <option value="3">CASH</option>
                                <option value="4">TIDAK DITAGIHKAN</option>

                            </select>
                        </div>
                        <div class="col-md-2">
                            <input type="text" class="form-control" id="metodePembayaran" placeholder="Metode Pembayaran">
                        </div>
                        <div class="col-md-2">
                            <input type="text" class="form-control" id="noBukti" placeholder="No Bukti/No BG">
                        </div>
                        <div class="col-md-2">
                            <input type="text" class="form-control" id="bank" placeholder="Bank">
                        </div>
                        <div class="col-md-2">
                            <input type="text" class="form-control" id="debet" placeholder="Debet">
                        </div>
                        <div class="col-md-2">
                            <input type="date" id="tgl-tmp" class="form-control" name="tgl-tmp" onkeydown="return false" onclick="this.showPicker()">
                        </div>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-success me-2">Add</button>
                        <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
    // Menampilkan modal kedua saat tombol di modal pertama diklik
    $('#secondarymodal').on('show.bs.modal', function() {
        $('#modalinvo').modal('hide');
    });

    // Menampilkan kembali modal pertama saat modal kedua ditutup
    $('#secondarymodal').on('hidden.bs.modal', function() {
        $('#modalinvo').modal('show');
    });
</script>

<!-- js tgl -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var today = new Date();
        var day = String(today.getDate()).padStart(2, '0');
        var month = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
        var year = today.getFullYear();
        var todayString = year + '-' + month + '-' + day;

        document.getElementById('tgl').value = todayString;
        document.getElementById('tgl-tmp').value = todayString;
    });
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<?= $this->endSection() ?>