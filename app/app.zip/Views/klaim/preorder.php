<?= $this->extend('layout/template'); ?>
<?= $this->section('content') ?>

<!-- Table Pre-order -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <h4 class="ms-3 mb-3">Pre Order</h4>
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-start" style="padding: 20px;">
                    <div class="mr-auto">
                        <a href="<?= base_url('order_pos') ?>" class="btn btn-primary btn-sm" style="width: 60px;">Add</a>
                        <a href="#" class="btn btn-secondary btn-sm" style="width: 80px;">Export</a>
                    </div>
                    <div class="d-flex align-items-center ms-auto">
                        <form action="/preorder/filter" method="get" class="d-flex align-items-center">
                            <input type="text" name="search" class="form-control form-control-sm me-2" placeholder="Cari Preorder" style="width: 130px;">
                            <input type="text" name="sa" class="form-control form-control-sm me-2" placeholder="SA" style="width: 130px;">
                            <button type="submit" class="btn btn-info btn-sm me-2" style="width: 80px;">Show</button>
                            <input type="date" name="date" class="form-control form-control-sm flatpickr-range me-2" placeholder="Select date.." style="width: 130px;">
                            <h6 class="mt-1 me-2" style="font-size: 12px;">Sort by</h6>
                            <select name="month" class="form-control form-control-sm me-2" id="selectMonth" style="width: 100px;">
                                <option value="1">Januari</option>
                                <option value="2">Februari</option>
                                <option value="3">Maret</option>
                                <option value="4">April</option>
                                <option value="5">Mei</option>
                                <option value="6">Juni</option>
                                <option value="7">Juli</option>
                                <option value="8">Agustus</option>
                                <option value="9">September</option>
                                <option value="10">Oktober</option>
                                <option value="11">November</option>
                                <option value="12">Desember</option>
                            </select>
                            <select name="year" class="form-control form-control-sm" id="selectYear" style="width: 100px;">
                                <!-- Tahun akan diisi otomatis -->
                            </select>
                        </form>
                    </div>
                </div>
                <div class="table-responsive text-center" style="font-size: 12px; margin: 20px;">
                    <table class="table table-bordered mb-0">
                        <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>No. Klaim</th>
                                <th>Tgl Klaim</th>
                                <th>Tgl Acc</th>
                                <th>Status</th>
                                <th>Progres</th>
                                <th>User ID</th>
                                <th>Harga Estimasi</th>
                                <th>Harga Acc</th>
                                <th>Nopol</th>
                                <th>Jenis Mobil</th>
                                <th>Customer</th>
                                <th>Nama Asuransi</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php if (!empty($po)) : ?>
                                <?php foreach ($po as $index => $po_item) : ?>
                                    <tr>
                                        <td><?= count($po) - $index ?></td> <!-- Menampilkan nomor urut dari 1 hingga n -->
                                        <td><a href="<?= base_url('order_posprev/' . $po_item['id_terima_po']) ?>"><?= esc($po_item['id_terima_po']) ?></a></td>
                                        <td><?= date('d F Y', strtotime($po_item['tgl_klaim'])) ?></td>
                                        <td><?= !empty($po_item['tgl_acc']) ? date('d F Y', strtotime($po_item['tgl_acc'])) : 'N/A'; ?></td>
                                        <td style="padding: 0.5rem;">
                                            <?php
                                            $badgeClass = 'bg-secondary'; // Default
                                            $status = esc($po_item['status']);
                                            if ($status === 'Pre-Order') {
                                                $badgeClass = 'bg-danger';
                                            } elseif ($status === 'Repair Order') {
                                                $badgeClass = 'bg-success';
                                            } elseif ($status === 'Acc Asuransi') {
                                                $badgeClass = 'bg-warning';
                                            }
                                            ?>
                                            <span class="badge <?= $badgeClass ?>" style="color: white; padding: 0.25rem 0.5rem;"><?= $status ?></span>
                                        </td>
                                        <td><?= esc($po_item['progres']) ?></td>
                                        <td><?= isset($po_item['username']) ? esc($po_item['username']) : 'N/A'; ?></td>
                                        <td><?= esc(number_format($po_item['harga_estimasi'], 0, ',', '.')) ?></td>
                                        <td><?= !empty($po_item['harga_acc']) ? esc(number_format($po_item['harga_acc'], 0, ',', '.')) : 'N/A'; ?></td>
                                        <td><?= esc($po_item['no_kendaraan']) ?></td>
                                        <td><?= esc($po_item['jenis_mobil']) ?></td>
                                        <td><?= esc($po_item['customer_name']) ?></td>
                                        <td><?= esc($po_item['asuransi']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="13">No data available</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get the current date
        const now = new Date();
        const currentMonth = now.getMonth() + 1; // Months are 0-based in JavaScript
        const currentYear = now.getFullYear();

        // Set the current month in the select
        const monthSelect = document.getElementById('selectMonth');
        monthSelect.value = currentMonth;

        // Set the current year and populate the year select
        const yearSelect = document.getElementById('selectYear');
        for (let year = 2020; year <= 2030; year++) {
            const option = document.createElement('option');
            option.value = year;
            option.text = year;
            if (year === currentYear) {
                option.selected = true;
            }
            yearSelect.appendChild(option);
        }
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php if (session()->getFlashdata('error')) : ?>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?= esc(session()->getFlashdata('error')) ?>',
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
        <?php endif; ?>

        <?php if (session()->getFlashdata('success')) : ?>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '<?= esc(session()->getFlashdata('success')) ?>',
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
        <?php endif; ?>
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Function to reverse the table rows
        function reverseTableRows() {
            const tableBody = document.querySelector('tbody');
            if (tableBody) {
                const rows = Array.from(tableBody.querySelectorAll('tr'));
                rows.reverse().forEach(row => tableBody.appendChild(row));
            }
        }

        reverseTableRows();
    });
</script>

<?= $this->endSection() ?>