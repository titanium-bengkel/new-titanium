<?= $this->extend('layout/template'); ?>

<?= $this->section('content') ?>


    <h3>List Invoice</h3>


    <!-- List Invoice Piutang -->
    <section class="section">
        <div class="row" id="table-bordered">
            <div class="col-12">
                <div class="card">
                    <div class="card-content">
                            <div class="card-header">
                                <div class="buttons">
                                    <a href="#" class="btn btn-primary"> ADD Invoice</a>
                                    <a href="#" class="btn btn-secondary">Export excel</a>
                                </div>
                                <div class="card-body"> 
                                    <input type="date" class="form-control mb-3 flatpickr-no-config" placeholder="Select date..">
                                </div>
                            </div>
                        <!-- table head dark -->
                        <div class="table-responsive" style="margin: 20px;">
                            <table class="table table-bordered mb-0">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>Kwitansi</th>
                                        <th>Unit</th>
                                        <th>Asuransi</th>
                                        <th>Tgl</th>
                                        <th>Jasa</th>
                                        <th>Sparepart</th>
                                        <th>Tagihan</th>
                                        <th>Pembayaran</th>
                                        <th>Sisa tagihan</th>
                                        <th>Keterangan</th>
                                        <th>User ID</th>
                                        <th>aksi</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center">
                                <tr>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th>
                                        <!-- button hapus -->
                                        <button type="button" class="btn btn-danger btn-sm delete-user-btn"><i class="fas fa-trash-alt"></i></button>
                                    </th>
                                </tr>
                                </tbody>
                            </table>
                        
                            <div class="card-body">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination pagination-primary">
                                        <li class="page-item"><a class="page-link" href="#">Prev</a></li>
                                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Table Pembayaran Piutang end -->

<?= $this->endSection() ?>