<?= $this->extend('layout/template'); ?>
<?= $this->section('content') ?>

<!-- Table acc Asuransi -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <h4 class="ms-3 mb-3">List ACC asuransi</h4>
            <div class="card">
                <div class="card-content">
                    <div class="table-responsive" style="font-size: 12px; margin: 20px;">
                        <table class="table table-bordered text-center mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>No Asuransi</th>
                                    <th>Tgl Acc</th>
                                    <th>Nama Asuransi</th>
                                    <th>No.Order</th>
                                    <th>Jasa</th>
                                    <th>Sparepart</th>
                                    <th>Nilai</th>
                                    <th>Tanggal Masuk</th>
                                    <th>Jenis Mobil</th>
                                    <th>Nopol</th>
                                    <th>Salesman</th>
                                    <th>User ID</th>
                                    <th>Tgl. Input</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($accData)): ?>
                                    <?php foreach ($accData as $index => $acc): ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><a href="order_pos_asprev"><?= $acc['id_acc_asuransi'] ?></a></td>
                                            <td><?= $acc['tgl_acc'] ?></td>
                                            <td><?= $acc['asuransi'] ?></td>
                                            <td><?= $acc['id_terima_po'] ?></td>
                                            <td><?= number_format($acc['biaya_jasa'], 0, ',', '.') ?></td>
                                            <td><?= number_format($acc['biaya_sparepart'], 0, ',', '.') ?></td>
                                            <td><?= number_format($acc['biaya_total'], 0, ',', '.') ?></td>
                                            <td><?= $acc['tgl_masuk'] ?></td>
                                            <td><?= $acc['jenis_mobil'] ?></td>
                                            <td><?= $acc['no_kendaraan'] ?></td>
                                            <td><?= $acc['customer_name'] ?></td>
                                            <td><?= isset($acc['username']) ? esc($acc['username']) : 'N/A'; ?></td>
                                            <td><?= date('d F Y') ?></td>
                                            <td>
                                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#uploadfile">
                                                    <i class="bi bi-cloud-upload" style="font-size: 0.8rem;"></i>
                                                </button>
                                                <button type="button" class="btn btn-warning btn-sm">
                                                    <i class="bi bi-file-pdf" style="font-size: 0.8rem;"></i>
                                                </button>
                                                <button type="button" class="btn btn-success btn-sm" onclick="lihatPdf()">
                                                    <i class="bi bi-eye" style="font-size: 0.8rem;"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="15" class="text-center">No data available</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Table head options end -->

<!-- modal foto-->
<div class="modal fade text-left" id="uploadfile" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <button type="button" class="btn btn-success btn-sm" id="add-row-btn"><i class="fas fa-plus"></i> Tambah Baris</button>
                <div class="table-responsive">
                    <table class="table table-bordered mt-2">
                        <thead>
                            <tr>
                                <th>No.Acc</th>
                                <th>Keterangan</th>
                                <th>File PDF</th>
                            </tr>
                        </thead>
                        <tbody class="table-debet">
                            <tr>
                                <td></td>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="file" class="basic-filepond" data-parsley-required="true"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Accept</span>
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get the current date
        const now = new Date();
        const currentMonth = now.getMonth() + 1; // Months are 0-based in JavaScript
        const currentYear = now.getFullYear();

        // Set the current month in the select
        const monthSelect = document.getElementById('selectMonth');
        monthSelect.value = currentMonth;

        // Set the current year and populate the year select
        const yearSelect = document.getElementById('selectYear');
        for (let year = 2020; year <= 2030; year++) {
            const option = document.createElement('option');
            option.value = year;
            option.text = year;
            if (year === currentYear) {
                option.selected = true;
            }
            yearSelect.appendChild(option);
        }
    });
</script>

<?= $this->endSection() ?>