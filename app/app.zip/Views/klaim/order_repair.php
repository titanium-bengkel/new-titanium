app/Views/klaim/bayar_piutang.php app/Views/klaim/invoice_or.php app/Views/klaim/kwitansi_piutang.php app/Views/klaim/kwitansi.php app/Views/klaim/order_pos_as.php app/Views/klaim/order_pos.php app/Views/klaim/order_postV2.php app/Views/klaim/orderlist_asuransi.php app/Views/klaim/orderlist_pending.php app/Views/klaim/preorder.php app/Views/klaim/repair_order.php<?= $this->extend('layout/template'); ?>
<?= $this->section('content') ?>
<h3>Repair Order</h3>

<!-- Horizontal Input start -->
<section id="horizontal-input">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5>Kendaraan</h5>
                    <div class="form-group row align-items-center">
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="pre-order-id">Pre-Order ID</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="pre-order-id" class="form-control" name="pre-order-id" disabled>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="no-kendaraan">No. Kendaraan</label>
                        </div>
                        <div class="col-lg-9 col-7 mb-3">
                            <input type="text" id="no-kendaraan" class="form-control" name="no-kendaraan">
                        </div>
                        <div class="col-lg-1 col-2 mb-3">
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#no-ken">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="jenis-mobil">Jenis Mobil</label>
                        </div>
                        <div class="col-lg-9 col-7 mb-3">
                            <input type="text" id="jenis-mobil" class="form-control" name="jenis-mobil">
                        </div>
                        <div class="col-lg-1 col-2 mb-3">
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#merk-mobil">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="warna">Warna</label>
                        </div>
                        <div class="col-lg-9 col-7 mb-3">
                            <input type="text" id="warna" class="form-control" name="warna">
                        </div>
                        <div class="col-lg-1 col-2 mb-3">
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#jenis-warna">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="no-polis">No Polis</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="no-polis" class="form-control" name="no-polis">
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="no-rangka">No Rangka</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="no-rangka" class="form-control" name="no-rangka">
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="tahun-kendaraan">Tahun Kendaraan</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="tahun-kendaraan" class="form-control" name="tahun-kendaraan">
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="no-contact">No Contact</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="no-contact" class="form-control" name="no-contact">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5>Customer</h5>
                    <div class="form-group row align-items-center">
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="customer-name">Customer Name</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="customer-name" class="form-control" name="customer-name">
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="alamat">Alamat</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="alamat" class="form-control" name="alamat">
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="kota">Kota</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="kota" class="form-control" name="kota">
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h5>Asuransi</h5>
                    <div class="form-group row align-items-center">
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="asuransi">Asuransi</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="asuransi" class="form-control" name="asuransi">
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="tanggal-masuk">Tanggal Masuk</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="date" id="tanggal-masuk" class="form-control" name="tanggal-masuk" onkeydown="return false" onclick="this.showPicker()">
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="tanggal-estimasi">Tanggal Estimasi </label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="date" id="tanggal-estimasi" class="form-control" name="tanggal-estimasi" onkeydown="return false" onclick="this.showPicker()">
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="harga-estimasi">Harga Estimasi</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="harga-estimasi" class="form-control" name="harga-estimasi">
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="keterangan">Keterangan</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <textarea class="form-control" id="keterangan" rows="1"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h5>Checklist Proses Klaim</h5>
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="ketok" name="status" onclick="toggleCheckbox(this)">
                                <label class="form-check-label" for="ketok">Ketok</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="dempul" name="status" onclick="toggleCheckbox(this)">
                                <label class="form-check-label" for="dempul">Dempul</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="epoxy" name="status" onclick="toggleCheckbox(this)">
                                <label class="form-check-label" for="epoxy">Epoxy</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="cat" name="status" onclick="toggleCheckbox(this)">
                                <label class="form-check-label" for="cat">Cat</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="poles" name="status" onclick="toggleCheckbox(this)">
                                <label class="form-check-label" for="poles">Poles</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="beres-pengerjaan" name="status" onclick="toggleCheckbox(this)">
                                <label class="form-check-label" for="batal-mobil-masuk">Beres Pengerjaan</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="menunggu-sparepart" name="status" onclick="toggleCheckbox(this)">
                                <label class="form-check-label" for="batal-mobil-masuk">Menunggu SparePart Tambahan</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="comment user" name="status" onclick="toggleCheckbox(this)">
                                <label class="form-check-label" for="batal-mobil-masuk">Menunggu Comment User</label>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="button" class="btn btn-primary">Simpan</button>
                            <button type="button" class="btn btn-danger">Batal</button>
                            <button type="button" class="btn btn-success" style="margin-left: 20px  ;">Cetak Estimasi</button>
                            <button type="button" class="btn btn-success">Cetak SPK B</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- pengerjaan -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <!-- Button Accordion -->
                    <button type="button" class="btn btn-success btn-sm" data-bs-toggle="collapse" data-bs-target="#collapsePengerjaan" id="togglePengerjaanButton">
                        Add
                    </button>
                    <!-- pengerjaan -->
                    <div id="collapsePengerjaan" class="collapse mt-2">
                        <form id="pengerjaanForm">
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="kodePengerjaan" class="col-form-label">Kode Pengerjaan</label>
                                </div>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control form-control-sm" id="kodePengerjaan">
                                </div>
                                <div class="col-sm-2">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#kodekerja">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="pengerjaan" class="col-form-label">Pengerjaan</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="pengerjaan">
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="harga" class="col-form-label">Harga</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="harga">
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div>
                                    <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                    <button type="button" class="btn btn-danger btn-sm" id="cancelPengerjaanButton">Batal</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Kode Pengerjaan</th>
                                    <th>Pengerjaan</th>
                                    <th>Harga</th>
                                    <th>ACT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>KD001</td>
                                    <td>Contoh Pengerjaan</td>
                                    <td>100000</td>
                                    <td><a href="#"><i class="fas fa-trash-alt"></i></a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Sperpat -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <!-- Button Accordion untuk Sparepart -->
                    <button type="button" class="btn btn-success btn-sm" data-bs-toggle="collapse" data-bs-target="#collapseSparepart" id="toggleSparepartButton">
                        Add
                    </button>
                    <!-- Sperpat -->
                    <div id="collapseSparepart" class="collapse mt-2">
                        <form id="sparepartForm">
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="kodeSparepart" class="col-form-label">Kode Sparepart</label>
                                </div>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control form-control-sm" id="kodeSparepart">
                                </div>
                                <div class="col-sm-2">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#kodepart">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="sparepart" class="col-form-label">Qty</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="sparepart">
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="hargaSparepart" class="col-form-label">Harga</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="hargaSparepart">
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="kodeSparepartPengerjaan" class="col-form-label">Pengerjaan</label>
                                </div>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control form-control-sm" id="kodeSparepartPengerjaan">
                                </div>
                                <div class="col-sm-2">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="sparepartNama" class="col-form-label">Nama</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="sparepartNama">
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="jenisPart" class="col-form-label">Jenis Part</label>
                                </div>
                                <div class="col-sm-6">
                                    <fieldset class="form-group">
                                        <select class="form-select form-select-sm" id="jenisPart">
                                            <option>NON-SUPPLY</option>
                                            <option>SUPPLY</option>
                                            <option>BORONG</option>
                                            <option>TIDAK JADI GANTI</option>
                                        </select>
                                    </fieldset>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div>
                                    <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                    <button type="button" class="btn btn-danger btn-sm" id="cancelSparepartButton">Batal</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class=" table-responsive">
                        <table class="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama</th>
                                    <th>Jenis</th>
                                    <th>Qty</th>
                                    <th>Harga</th>
                                    <th>Kode pengerjaan</th>
                                    <!-- <th>Q_PO</th>
                                    <th>Q_Beli</th>
                                    <th>Q_Trpsang</th> -->
                                    <th>ACT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>0</td>
                                    <th>0</th>
                                    <th>0</th>
                                    <!-- <th>0</th>
                                    <th>0</th>
                                    <th>0</th> -->
                                    <td><a href="#"><i class="fas fa-trash-alt"></i></a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- bukti gambar -->
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#gambar">
                        Upload foto
                    </button>

                    <div class="table-responsive">
                        <table class="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>keterangan</th>
                                    <th>Foto</th>
                                    <th>Deskripsi</th>
                                    <th>ACT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Horizontal Input end -->

<!-- modal pengerjaan -->
<div class="modal fade text-left" id="kodekerja" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4 mt-1">
                        <label for="search-input">Cari</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="search-input" class="form-control form-control-sm" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama Pengerjaan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Accept</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- modal pengerjaan -->
<div class="modal fade text-left" id="kodepart" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4 mt-1">
                        <label for="search-input">Cari</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="search-input" class="form-control form-control-sm" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Qty Stock</th>
                                <th>Harga</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Accept</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- modal foto-->
<div class="modal fade text-left" id="gambar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <button type="button" class="btn btn-success btn-sm" id="add-row-btn"><i class="fas fa-plus"></i> Tambah Baris</button>
                <div class="table-responsive">
                    <table class="table table-bordered mt-2">
                        <thead>
                            <tr>
                                <th>keterangan</th>
                                <th>Deskripsi</th>
                                <th>File Foto</th>
                                <th>Act</th>
                            </tr>
                        </thead>
                        <tbody class="table-debet">
                            <tr>
                                <td>
                                    <select class="form-select" id="basicSelect">
                                        <option>Sebelum</option>
                                        <option>Epoxy</option>
                                        <option>Finish</option>
                                    </select>
                                </td>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="file" class="image-resize-filepond"></td>
                                <td>
                                    <button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Accept</span>
                </button>
            </div>
        </div>
    </div>
</div>


<!-- modal Search no.kendaraan -->
<div class="modal fade text-left" id="no-ken" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel3"></h5>
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="col-md-12 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <form class="form form-horizontal">
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label for="search-input">Cari</label>
                                            </div>
                                            <div class="col-md-8 form-group">
                                                <input type="text" id="search-input" class="form-control" name="search">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                            <tr>
                                <th>No. Kendaraan</th>
                                <th>Nama Pemilik</th>
                                <th>No. Kontak</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Submit</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End -->

<!-- modal jenis mobil -->
<div class="modal fade text-left" id="merk-mobil" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1"></h5>
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="col-md-12 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <form class="form form-horizontal">
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label for="search-input">Cari</label>
                                            </div>
                                            <div class="col-md-8 form-group">
                                                <input type="text" id="search-input" class="form-control" name="search">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Jenis Mobil</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Submit</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End -->

<!-- modal warna -->
<div class="modal fade text-left" id="jenis-warna" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel3"></h5>
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="col-md-12 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <form class="form form-horizontal">
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label for="search-input">Cari</label>
                                            </div>
                                            <div class="col-md-8 form-group">
                                                <input type="text" id="search-input" class="form-control" name="search">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Warna</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-bs-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Submit</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End -->


<!-- js checkbox -->
<script>
    function toggleCheckbox(element) {
        var checkboxes = document.getElementsByName("status");
        checkboxes.forEach((item) => {
            if (item !== element) item.checked = false;
        });
    }
</script>
<!-- end -->

<!-- Script untuk modal -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Menambahkan baris pada bagian Account Debet
        $('#gambar').on('click', '#add-row-btn', function() {
            var row = '<tr>' +
                '<td><select class="form-select" id="basicSelect"><option>Sebelum</option><option>Epoxy</option><option>Finish</option></td>' +
                '<td><input type="text" class="form-control"></td>' +
                '<td><input type="file" class="image-resize-filepond"></td>' +
                '<td>' +
                '<button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>' +
                '</td>' +
                '</tr>';
            $(this).closest('.modal-content').find('.table-debet').append(row); // Memilih tbody di dalam bagian Account Debet
            updateRemoveButtonStatus();
        });

        // Menghapus baris
        $('#gambar').on('click', '.remove-row', function() {
            $(this).closest('tr').remove();
            updateRemoveButtonStatus();
        });

        // Fungsi untuk mengatur status tombol kurangi
        function updateRemoveButtonStatus() {
            var rowCount = $('#gambar').find('.table-debet tr').length;
            if (rowCount === 1) {
                $('#gambar').find('.table-debet .remove-row').prop('disabled', true); // Menonaktifkan tombol jika hanya ada satu baris
            } else {
                $('#gambar').find('.table-debet .remove-row').prop('disabled', false); // Mengaktifkan tombol jika lebih dari satu baris
            }
        }

        // Memastikan status tombol saat halaman dimuat
        updateRemoveButtonStatus();
    });
</script>
<!-- css table gambar -->
<style>
    /* Gaya untuk tabel di dalam modal */
    .modal-content {
        font-size: 14px;
        /* Ukuran font default */
    }

    /* Gaya untuk input pada tabel */
    .table input[type="text"] {
        width: 100%;
        /* Lebar input 100% dari kolom */
    }

    /* Gaya untuk tombol remove */
    .remove-row {
        margin-top: 5px;
        /* Spasi atas tombol */
    }

    /* Gaya untuk baris Account Credit (readonly) */
    .table-credit tbody tr td {
        background-color: #f5f5f5;
        /* Warna latar belakang abu-abu muda */
        color: #888;
        /* Warna teks abu-abu */
    }

    /* Gaya untuk tombol tambah baris */
    #add-row-btn {
        margin-bottom: 10px;
        /* Spasi bawah tombol Tambah Baris */
    }
</style>
<!-- end -->

<!-- js accordion -->
<script>
    // Fungsi untuk mereset dan menyembunyikan form
    function resetAndHideForm(formId, collapseId, buttonId) {
        document.getElementById(formId).reset(); // Reset form
        document.getElementById(collapseId).classList.remove('show'); // Sembunyikan form
        document.getElementById(buttonId).style.display = 'inline-block'; // Tampilkan tombol
    }

    // Event listener untuk tombol batal
    document.getElementById('cancelPengerjaanButton').addEventListener('click', function() {
        resetAndHideForm('pengerjaanForm', 'collapsePengerjaan', 'togglePengerjaanButton');
    });

    document.getElementById('cancelSparepartButton').addEventListener('click', function() {
        resetAndHideForm('sparepartForm', 'collapseSparepart', 'toggleSparepartButton');
    });

    // Event listener untuk tombol toggle
    document.getElementById('togglePengerjaanButton').addEventListener('click', function() {
        this.style.display = 'none'; // Sembunyikan tombol saat form dibuka
    });

    document.getElementById('toggleSparepartButton').addEventListener('click', function() {
        this.style.display = 'none'; // Sembunyikan tombol saat form dibuka
    });

    // Event listener untuk collapse
    document.getElementById('collapsePengerjaan').addEventListener('show.bs.collapse', function() {
        document.getElementById('togglePengerjaanButton').style.display = 'none';
    });

    document.getElementById('collapsePengerjaan').addEventListener('hide.bs.collapse', function() {
        document.getElementById('togglePengerjaanButton').style.display = 'inline-block';
    });

    document.getElementById('collapseSparepart').addEventListener('show.bs.collapse', function() {
        document.getElementById('toggleSparepartButton').style.display = 'none';
    });

    document.getElementById('collapseSparepart').addEventListener('hide.bs.collapse', function() {
        document.getElementById('toggleSparepartButton').style.display = 'inline-block';
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">


<?= $this->endSection() ?>