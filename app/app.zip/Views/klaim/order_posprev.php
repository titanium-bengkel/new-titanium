<?= $this->extend('layout/template'); ?>
<?= $this->section('content') ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    <?php if (session()->getFlashdata('success')) : ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'success',
            title: '<?= session()->getFlashdata('success') ?>',
            showConfirmButton: false,
            timer: 3000
        });
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')) : ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'error',
            title: '<?= session()->getFlashdata('error') ?>',
            showConfirmButton: false,
            timer: 3000
        });
    <?php endif; ?>
</script>
<!-- Horizontal Input start -->
<section id="horizontal-input">
    <div class="row">
        <h4 class="ms-3 mb-3">Edit Pre Order</h4>
        <form action="<?= base_url('updatePo/' . $po['id_terima_po']) ?>" method="post">
            <div class="accordion" id="accordionExample">
                <!-- Kendaraan Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Kendaraan
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <div class="form-group row align-items-center" style="margin: 20px;">
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="id-terima-po">Pre-Order ID</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="hidden" id="id-terima-po" name="id_terima_po" value="<?= isset($po['id_terima_po']) ? esc($po['id_terima_po']) : '' ?>">
                                    <input type="text" class="form-control" value="<?= isset($po['id_terima_po']) ? esc($po['id_terima_po']) : '' ?>" disabled>
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="no-kendaraan">No. Kendaraan</label>
                                </div>
                                <div class="col-lg-9 col-7 mb-3">
                                    <input type="text" id="no_kendaraan" class="form-control" name="no_kendaraan" value="<?= isset($po['no_kendaraan']) ? esc($po['no_kendaraan']) : '' ?>">
                                </div>
                                <div class="col-lg-1 col-2 mb-3">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#kendaraanModal">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="jenis-mobil">Jenis Mobil</label>
                                </div>
                                <div class="col-lg-9 col-7 mb-3">
                                    <input type="text" id="jenis-mobil" class="form-control" name="jenis_mobil" value="<?= isset($po['jenis_mobil']) ? esc($po['jenis_mobil']) : '' ?>">
                                </div>
                                <div class="col-lg-1 col-2 mb-3">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#jenisMobilModal">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="warna">Warna</label>
                                </div>
                                <div class="col-lg-9 col-7 mb-3">
                                    <input type="text" id="warna" class="form-control" name="warna" value="<?= isset($po['warna']) ? esc($po['warna']) : '' ?>">
                                </div>
                                <div class="col-lg-1 col-2 mb-3">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#warnaModal">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="no-rangka">No Rangka</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="text" id="no-rangka" class="form-control" name="no_rangka" value="<?= isset($po['no_rangka']) ? esc($po['no_rangka']) : '' ?>">
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="tahun-kendaraan">Tahun Kendaraan</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="text" id="tahun-kendaraan" class="form-control" name="tahun_kendaraan" value="<?= isset($po['tahun_kendaraan']) ? esc($po['tahun_kendaraan']) : '' ?>">
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="no-contact">No. Contact</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="text" id="no-contact" class="form-control" name="no_contact" value="<?= isset($po['no_contact']) ? esc($po['no_contact']) : '' ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Customer Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                            Customer
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse show" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <div class="form-group row align-items-center" style="margin: 20px;">
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="customer-name">Customer Name</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="text" id="customer-name" class="form-control" name="customer_name" value="<?= isset($po['customer_name']) ? esc($po['customer_name']) : '' ?>">
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="alamat">Alamat</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="text" id="alamat" class="form-control" name="alamat" value="<?= isset($po['alamat']) ? esc($po['alamat']) : '' ?>">
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="kota">Kota</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="text" id="kota" class="form-control" name="kota" value="<?= isset($po['kota']) ? esc($po['kota']) : '' ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Insurance Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingAsuransi">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAsuransi" aria-expanded="true" aria-controls="collapseAsuransi">
                            Asuransi
                        </button>
                    </h2>
                    <div id="collapseAsuransi" class="accordion-collapse collapse show" aria-labelledby="headingAsuransi" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <div class="form-group row align-items-center" style="margin: 20px;">
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="asuransi">Asuransi</label>
                                </div>
                                <div class="col-lg-9 col-9 mb-3">
                                    <input type="text" id="asuransi" class="form-control" name="asuransi" value="<?= isset($po['asuransi']) ? esc($po['asuransi']) : '' ?>">
                                </div>
                                <div class="col-lg-1 col-2 mb-3">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#asur">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="no-polis">No. Polis</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="text" id="no-polis" class="form-control" name="no_polis" value="<?= isset($po['no_polis']) ? esc($po['no_polis']) : '' ?>">
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="tanggal-masuk">Tanggal Masuk</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="date" id="tanggal-masuk" class="form-control" name="tanggal_masuk" value="<?= isset($po['tgl_klaim']) ? esc($po['tgl_klaim']) : '' ?>" onkeydown="return false" onclick="this.showPicker()">
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="harga-estimasi">Harga Estimasi</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <input type="text" id="harga-estimasi" class="form-control" name="harga_estimasi" value="<?= isset($hargaEstimasi) ? esc(number_format($hargaEstimasi, 0, ',', '.')) : '' ?>" readonly>
                                </div>
                                <div class="col-lg-2 col-3 mb-3">
                                    <label class="col-form-label" for="keterangan">Keterangan</label>
                                </div>
                                <div class="col-lg-10 col-9 mb-3">
                                    <textarea class="form-control" id="keterangan" name="keterangan" rows="1"><?= isset($po['keterangan']) ? esc($po['keterangan']) : '' ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Checklist -->
            <div class="col-md-12 mt-3">
                <div class="card">
                    <div class="card-body">
                        <div class="form-group row align-items-center">
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="status-order">Status Order</label>
                            </div>
                            <div class="col-lg-2 col-4 mb-2">
                                <fieldset class="form-group">
                                    <select class="form-select" id="status-order" name="status_order">
                                        <option value="Repair Order" <?= (isset($po['status_order']) && $po['status_order'] == 'Repair Order') ? 'selected' : '' ?>>Repair Order</option>
                                        <option value="Pre-Order" <?= (isset($po['status_order']) && $po['status_order'] == 'Pre-Order') ? 'selected' : '' ?>>Pre-Order</option>
                                        <option value="Acc Asuransi" <?= (isset($po['status_order']) && $po['status_order'] == 'Acc Asuransi') ? 'selected' : '' ?>>Acc Asuransi</option>
                                    </select>
                                </fieldset>
                            </div>
                        </div>
                        <h5>Checklist Proses Klaim</h5>
                        <div class="form-group">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="proses-klaim" name="progres" value="Proses Klaim" <?= (isset($po['progres']) && $po['progres'] == 'Proses Klaim') ? 'checked' : '' ?>>
                                <label class="form-check-label" for="proses-klaim">Proses Klaim</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="menunggu-sparepart" name="progres" value="Menunggu Sparepart" <?= (isset($po['progres']) && $po['progres'] == 'Menunggu Sparepart') ? 'checked' : '' ?>>
                                <label class="form-check-label" for="menunggu-sparepart">Menunggu Sparepart</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="menunggu-supply" name="progres" value="Menunggu Supply" <?= (isset($po['progres']) && $po['progres'] == 'Menunggu Supply') ? 'checked' : '' ?>>
                                <label class="form-check-label" for="menunggu-supply">Menunggu Supply</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="siap-masuk" name="progres" value="Siap Masuk" <?= (isset($po['progres']) && $po['progres'] == 'Siap Masuk') ? 'checked' : '' ?>>
                                <label class="form-check-label" for="siap-masuk">Siap Masuk</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="batal-klaim-asuransi" name="progres" value="Batal Klaim Asuransi" <?= (isset($po['progres']) && $po['progres'] == 'Batal Klaim Asuransi') ? 'checked' : '' ?>>
                                <label class="form-check-label" for="batal-klaim-asuransi">Batal Klaim Asuransi</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="batal-mobil-masuk" name="progres" value="Batal Mobil Masuk" <?= (isset($po['progres']) && $po['progres'] == 'Batal Mobil Masuk') ? 'checked' : '' ?>>
                                <label class="form-check-label" for="batal-mobil-masuk">Batal Mobil Masuk</label>
                            </div>
                        </div>
                        <div class="mt-3">
                            <?php
                            // Ambil status dari tabel acc_asuransi
                            $accAsuransiModel = new \App\Models\M_AccAsuransi();
                            $asuransiData = $accAsuransiModel->where('id_terima_po', $po['id_terima_po'])->first();
                            $isApproved = !empty($po) && $po['status'] === 'Acc Asuransi';
                            ?>

                            <div class="mt-3">
                                <button type="submit" class="btn btn-sm btn-primary">Update</button>
                                <button type="button" class="btn btn-sm btn-secondary" style="margin-left: 20px;">Cetak Estimasi</button>
                                <!-- Button Modal -->
                                <?php if ($isApproved) : ?>
                                    <a href="<?= base_url('edit-asuransi/' . $po['id_terima_po']); ?>" class="btn btn-sm btn-success">
                                        Sudah Approve
                                    </a>
                                <?php else : ?>
                                    <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#asur-acc">
                                        Approve Asuransi
                                    </button>
                                <?php endif; ?>
                            </div>

                        </div>


                    </div>
                </div>
            </div>
        </form>

        <!-- Form Input Pengerjaan -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <!-- Button Accordion -->
                    <button type="button" class="btn btn-success btn-sm" data-bs-toggle="collapse" data-bs-target="#collapsePengerjaan" id="togglePengerjaanButton">
                        Add
                    </button>
                    <!-- Form Pengerjaan -->
                    <div id="collapsePengerjaan" class="collapse mt-2">
                        <form id="pengerjaanForm" method="post" action="<?= base_url('createPengerjaanPo') ?>">
                            <input type="hidden" name="id_terima_po" value="<?= esc($po['id_terima_po']) ?>"> <!-- Add this line -->
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="kodePengerjaan" class="col-form-label">Kode Pengerjaan</label>
                                </div>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control form-control-sm" id="kodePengerjaan" name="kodePengerjaan" readonly>
                                </div>
                                <div class="col-sm-2">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#pengerjaanModal">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="pengerjaan" class="col-form-label">Pengerjaan</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="pengerjaan" name="pengerjaan">
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="harga" class="col-form-label">Harga</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="harga" name="harga">
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div>
                                    <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                    <button type="button" class="btn btn-danger btn-sm" id="cancelPengerjaanButton">Batal</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- Tabel Pengerjaan -->
                    <div class="table-responsive mt-2">
                        <table class="table table-bordered text-center">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Kode Pengerjaan</th>
                                    <th>Pengerjaan</th>
                                    <th>Harga</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $totalHarga = 0;
                                if (!empty($pengerjaanList)) :
                                    foreach ($pengerjaanList as $index => $p) :
                                        $totalHarga += $p['harga'];
                                ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><?= esc($p['kode_pengerjaan']) ?></td>
                                            <td><?= esc($p['nama_pengerjaan']) ?></td>
                                            <td><?= number_format($p['harga'], 0, ',', '.') ?></td> <!-- Format harga -->
                                            <td>
                                                <a href="<?= base_url('deletePengerjaan/' . urlencode($p['kode_pengerjaan'])) ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus item ini?');">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td colspan="3"><strong>Total Harga</strong></td>
                                        <td><strong><?= number_format($totalHarga, 0, ',', '.') ?></strong></td>
                                        <td></td>
                                    </tr>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="5">Tidak ada data pengerjaan</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sparepart -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <!-- Button Accordion untuk Sparepart -->
                    <button type="button" class="btn btn-success btn-sm" data-bs-toggle="collapse" data-bs-target="#collapseSparepart" id="toggleSparepartButton">
                        Add
                    </button>
                    <!-- Sparepart Form -->
                    <div id="collapseSparepart" class="collapse mt-2">
                        <form id="sparepartForm" action="<?= base_url('/createSparepart/' . esc($id_terima_po)) ?>" method="post">
                            <input type="hidden" name="id_terima_po" value="<?= esc($id_terima_po) ?>">
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="kodeSparepart" class="col-form-label">Kode Sparepart</label>
                                </div>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control form-control-sm" id="kodeSparepart" name="kodeSparepart" readonly>
                                </div>
                                <div class="col-sm-2">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#kodepart">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="sparepart" class="col-form-label">Qty</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="sparepart" name="sparepart">
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="hargaSparepart" class="col-form-label">Harga</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="hargaSparepart" name="hargaSparepart">
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="kodePengerjaan" class="col-form-label">Pengerjaan</label>
                                </div>
                                <div class="col-sm-6">
                                    <select class="form-control form-control-sm" id="kodePengerjaan" name="kodePengerjaan">
                                        <?php if (!empty($daftarPengerjaan)) : ?>
                                            <?php foreach ($daftarPengerjaan as $p) : ?>
                                                <option value="<?= esc($p['kode_pengerjaan']) ?>">
                                                    <?= esc($p['nama_pengerjaan']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        <?php else : ?>
                                            <option value="">Tidak ada data</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="sparepartNama" class="col-form-label">Nama</label>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-sm" id="sparepartNama" name="sparepartNama" readonly>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-5">
                                    <label for="jenisPart" class="col-form-label">Jenis Part</label>
                                </div>
                                <div class="col-sm-6">
                                    <fieldset class="form-group">
                                        <select class="form-select form-select-sm" id="jenisPart" name="jenisPart">
                                            <option value="NON-SUPPLY">NON-SUPPLY</option>
                                            <option value="SUPPLY">SUPPLY</option>
                                            <option value="BORONG">BORONG</option>
                                            <option value="TIDAK JADI GANTI">TIDAK JADI GANTI</option>
                                        </select>
                                    </fieldset>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div>
                                    <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                    <button type="button" class="btn btn-danger btn-sm" id="cancelSparepartButton">Batal</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive text-center">
                        <table class="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama</th>
                                    <th>Jenis</th>
                                    <th>Qty</th>
                                    <th>Harga</th>
                                    <th>Kode Pengerjaan</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($daftarSparepart)) : ?>
                                    <?php $index = 1; ?>
                                    <?php $totalQty = 0; ?>
                                    <?php $totalHarga = 0; ?>
                                    <?php foreach ($daftarSparepart as $sparepart) : ?>
                                        <?php
                                        $qty = $sparepart['qty'];
                                        $harga = $sparepart['harga'];
                                        // Hitung total harga per item
                                        $totalHargaPerItem = $harga * $qty;
                                        ?>
                                        <tr>
                                            <td><?= $index++ ?></td>
                                            <td><?= esc($sparepart['nama_sparepart']) ?></td>
                                            <td><?= esc($sparepart['jenis_part']) ?></td>
                                            <td><?= esc($qty) ?></td>
                                            <td><?= number_format($totalHargaPerItem, 0, ',', '.') ?></td>
                                            <td><?= esc($sparepart['kode_pengerjaan']) ?></td>
                                            <td>
                                                <a href="<?= base_url('deleteSparepart/' . esc($sparepart['id_sparepart_po'])) ?>" onclick="return confirm('Are you sure you want to delete this item?');">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                        $totalQty += $qty;
                                        $totalHarga += $totalHargaPerItem;
                                        ?>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td colspan="3" class="text-right"><strong>Total:</strong></td>
                                        <td><strong><?= $totalQty ?></strong></td>
                                        <td><strong><?= number_format($totalHarga, 0, ',', '.') ?></strong></td>
                                        <td colspan="2"></td>
                                    </tr>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="7" class="text-center">Tidak ada data sparepart</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#gambar">
                        Upload foto
                    </button>

                    <div class="table-responsive text-center">
                        <table class="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Keterangan</th>
                                    <th>Foto</th>
                                    <th>Deskripsi</th>
                                    <th>Act</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($gambarData)) : ?>
                                    <?php foreach ($gambarData as $index => $gambar) : ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><?= htmlspecialchars($gambar['keterangan']) ?></td>
                                            <td>
                                                <img src="<?= base_url('uploads/' . htmlspecialchars($gambar['gambar'])) ?>" alt="<?= htmlspecialchars($gambar['keterangan']) ?>" style="max-width: 200px;">
                                            </td>
                                            <td><?= htmlspecialchars($gambar['deskripsi']) ?></td>
                                            <td>
                                                <a href="<?= base_url('delete-gambar/' . $gambar['id_gambar_po']) ?>" class="btn btn-sm " onclick="return confirm('Apakah Anda yakin ingin menghapus gambar ini?');">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="5">Tidak ada gambar yang di-upload.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Horizontal Input end -->

<!-- modal pengerjaan -->
<div class="modal fade" id="pengerjaanModal" tabindex="-1" aria-labelledby="pengerjaanModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pengerjaanModalLabel">Pilih Pengerjaan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Form pencarian tanpa tombol -->
                <div class="mb-3">
                    <input type="text" class="form-control form-control-sm" id="searchInput" placeholder="Cari kode atau nama pengerjaan" oninput="searchPengerjaan()">
                </div>
                <!-- Tabel data pengerjaan -->
                <table class="table table-bordered text-center mt-3" style="font-size: 0.85rem;">
                    <thead>
                        <tr>
                            <th>Kode Pengerjaan</th>
                            <th>Nama Pengerjaan</th>
                        </tr>
                    </thead>
                    <tbody id="pengerjaan-list">
                        <?php if (!empty($pengerjaan)) : ?>
                            <?php foreach ($pengerjaan as $p) : ?>
                                <tr data-kode="<?= $p->kode_pengerjaan ?>" data-nama="<?= $p->nama_pengerjaan ?>">
                                    <td><?= $p->kode_pengerjaan ?></td>
                                    <td><?= $p->nama_pengerjaan ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="2">Tidak ada data</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal SparePart -->
<div class="modal fade text-left" id="kodepart" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Pilih Sparepart</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-12">
                        <input type="text" id="search-input" class="form-control form-control-sm" placeholder="Cari SparePart...">
                    </div>
                </div>
                <div class="table-responsive text-center">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Harga Beli</th>
                            </tr>
                        </thead>
                        <tbody id="sparepart-list">
                            <?php if (!empty($spareparts)) : ?>
                                <?php foreach ($spareparts as $sparepart) : ?>
                                    <tr data-id="<?= esc($sparepart['kode']) ?>" data-nama="<?= esc($sparepart['nama']) ?>" data-harga="<?= esc($sparepart['harga']) ?>">
                                        <td><?= esc($sparepart['kode']) ?></td>
                                        <td><?= esc($sparepart['nama']) ?></td>
                                        <td><?= number_format(esc($sparepart['harga']), 0, ',', '.') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="3">Tidak ada data spare part.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- Modal Kendaraan -->
<div class="modal fade" id="kendaraanModal" tabindex="-1" aria-labelledby="kendaraanLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="kendaraanLabel">Pilih Kendaraan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="text" id="search-kendaraan" class="form-control mb-3" placeholder="Cari Kendaraan...">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No. Kendaraan</th>
                            <th>Customer</th>
                            <th>No. Contact</th>
                        </tr>
                    </thead>
                    <tbody id="kendaraan-list">
                        <?php if (!empty($kendaraan)) : ?>
                            <?php foreach ($kendaraan as $k) : ?>
                                <tr data-no-kendaraan="<?= $k['no_kendaraan'] ?>" data-customer="<?= $k['customer_name'] ?>" data-no-contact="<?= $k['no_contact'] ?>">
                                    <td><?= $k['no_kendaraan'] ?></td>
                                    <td><?= $k['customer_name'] ?></td>
                                    <td><?= $k['no_contact'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="3">Data kendaraan tidak tersedia.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<!-- Modal Jenis Mobil -->
<div class="modal fade" id="jenisMobilModal" tabindex="-1" role="dialog" aria-labelledby="jenisMobilModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="jenisMobilModalLabel">Pilih Jenis Mobil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="text" id="searchJenisMobil" class="form-control mb-3" placeholder="Cari Jenis Mobil...">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Jenis Mobil</th>
                        </tr>
                    </thead>
                    <tbody id="jenis-mobil-list">
                        <?php if (isset($jenis_mobil) && !empty($jenis_mobil)) : ?>
                            <?php $no = 1; ?>
                            <?php foreach ($jenis_mobil as $j) : ?>
                                <tr data-jenis-mobil="<?= $j['jenis_mobil'] ?>">
                                    <td><?= $no++ ?></td>
                                    <td><?= $j['jenis_mobil'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="2">Tidak ada data</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Modal Warna -->
<div class="modal fade" id="warnaModal" tabindex="-1" role="dialog" aria-labelledby="warnaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="warnaModalLabel">Pilih Warna</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="text" id="searchWarna" class="form-control mb-3" placeholder="Cari Warna...">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Warna</th>
                        </tr>
                    </thead>
                    <tbody id="warna-list">
                        <?php if (isset($warna) && !empty($warna)) : ?>
                            <?php $no = 1; ?>
                            <?php foreach ($warna as $w) : ?>
                                <tr data-warna="<?= $w['warna'] ?>">
                                    <td><?= $no++ ?></td>
                                    <td><?= $w['warna'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="2">Tidak ada data</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal untuk memilih Asuransi -->
<div class="modal fade" id="asur" tabindex="-1" aria-labelledby="asurLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="asurLabel">Pilih Asuransi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="text" id="search-asuransi" class="form-control mb-3" placeholder="Cari Asuransi...">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama Asuransi</th>
                        </tr>
                    </thead>
                    <tbody id="asuransi-list">
                        <?php if (isset($asuransi) && !empty($asuransi)) : ?>
                            <?php foreach ($asuransi as $a) : ?>
                                <tr class="clickable-row" data-kode="<?= $a->kode ?>" data-nama="<?= $a->nama_asuransi ?>">
                                    <td><?= $a->kode ?></td>
                                    <td><?= $a->nama_asuransi ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="2">Data asuransi tidak tersedia.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal AccAsuransi -->
<div class="modal fade" id="asur-acc" tabindex="-1" aria-labelledby="myModalLabel3" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="max-height: 90vh; overflow-y: auto;">
        <div class="modal-content">
            <form action="<?= base_url('createAccAsuransi') ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id_terima_po" value="<?= esc($po['id_terima_po']) ?>">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel3">Detail Asuransi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- ID Section -->
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title">ID</h5>
                            <div class="mb-2 row">
                                <label for="no_acc" class="col-sm-3 col-form-label">No. Order</label>
                                <div class="col-sm-9">
                                    <input type="text" id="no_acc" class="form-control" name="no_acc" value="<?= isset($po['id_terima_po']) ? esc($po['id_terima_po']) : '' ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="tgl_acc" class="col-sm-3 col-form-label">Tanggal Acc</label>
                                <div class="col-sm-9">
                                    <input type="date" id="tgl_acc" class="form-control" name="tgl_acc" onkeydown="return false">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Data Section -->
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Data</h5>
                            <div class="mb-2 row">
                                <label for="no_kendaraan" class="col-sm-3 col-form-label">No. Kendaraan</label>
                                <div class="col-sm-9">
                                    <input type="text" id="no_kendaraan" class="form-control" name="no_kendaraan" value="<?= isset($po['no_kendaraan']) ? esc($po['no_kendaraan']) : '' ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="jenis_mobil" class="col-sm-3 col-form-label">Jenis Mobil</label>
                                <div class="col-sm-9">
                                    <input type="text" id="jenis_mobil" class="form-control" name="jenis_mobil" value="<?= isset($po['jenis_mobil']) ? esc($po['jenis_mobil']) : '' ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="warna" class="col-sm-3 col-form-label">Warna</label>
                                <div class="col-sm-9">
                                    <input type="text" id="warna" class="form-control" name="warna" value="<?= isset($po['warna']) ? esc($po['warna']) : '' ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="customer_name" class="col-sm-3 col-form-label">Customer Name</label>
                                <div class="col-sm-9">
                                    <input type="text" id="customer_name" class="form-control" name="customer_name" value="<?= isset($po['customer_name']) ? esc($po['customer_name']) : '' ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="no_contact" class="col-sm-3 col-form-label">No Contact</label>
                                <div class="col-sm-9">
                                    <input type="text" id="no_contact" class="form-control" name="no_contact" value="<?= isset($po['no_contact']) ? esc($po['no_contact']) : '' ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="tahun_mobil" class="col-sm-3 col-form-label">Tahun Kendaraan</label>
                                <div class="col-sm-9">
                                    <input type="text" id="tahun_mobil" class="form-control" name="tahun_mobil" value="<?= isset($po['tahun_kendaraan']) ? esc($po['tahun_kendaraan']) : '' ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="asuransi" class="col-sm-3 col-form-label">Asuransi</label>
                                <div class="col-sm-9">
                                    <input type="text" id="asuransi" class="form-control" name="asuransi" value="<?= isset($po['asuransi']) ? esc($po['asuransi']) : '' ?>" readonly>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Asuransi Section -->
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Asuransi</h5>
                            <div class="mb-2 row">
                                <label for="tgl_masuk" class="col-sm-3 col-form-label">Tanggal Masuk</label>
                                <div class="col-sm-9">
                                    <input type="date" id="tgl_masuk" class="form-control" name="tgl_masuk" value="<?= isset($po['tgl_klaim']) ? esc($po['tgl_klaim']) : '' ?>" onkeydown="return false" onclick="this.showPicker()" readonly>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="tgl_estimasi" class="col-sm-3 col-form-label">Tanggal Estimasi</label>
                                <div class="col-sm-9">
                                    <input type="date" id="tgl_estimasi" class="form-control" name="tgl_estimasi" onkeydown="return false">
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label class="col-sm-3 col-form-label">Biaya Jasa</label>
                                <div class="col-sm-9">
                                    <input type="text" id="jasa" class="form-control" name="jasa">
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label class="col-sm-3 col-form-label">Biaya Sparepart</label>
                                <div class="col-sm-9">
                                    <input type="text" id="sparepart" class="form-control" name="sparepart">
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label class="col-sm-3 col-form-label">Nilai Total</label>
                                <div class="col-sm-9">
                                    <input type="text" id="nilai_total" class="form-control" name="nilai_total" readonly>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="nilai_or" class="col-sm-3 col-form-label">Nilai OR</label>
                                <div class="col-sm-9">
                                    <input type="text" id="nilai_or" class="form-control" name="nilai_or">
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="qty_or" class="col-sm-3 col-form-label">Qty OR</label>
                                <div class="col-sm-9">
                                    <input type="text" id="qty_or" class="form-control" name="qty_or">
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="keterangan" class="col-sm-3 col-form-label">Keterangan</label>
                                <div class="col-sm-9">
                                    <textarea class="form-control" id="keterangan" rows="2" name="keterangan"></textarea>
                                </div>
                            </div>
                            <div class="mb-2 row">
                                <label for="formFileSm" class="col-sm-3 col-form-label">Foto SPK</label>
                                <div class="col-sm-9">
                                    <input class="form-control form-control-sm" id="formFileSm" type="file" name="foto_spk" accept="image/*">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer Section -->
                <div class="modal-footer">
                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary btn-sm">Save</button>
                        <button type="button" class="btn btn-secondary btn-sm ms-2" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>




<!-- Modal Foto -->
<div class="modal fade text-left" id="gambar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content modal-lg">
            <form action="<?= base_url('/createGambarPo') ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id_terima_po" value="<?= $id_terima_po ?>">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel1">Upload Foto</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <button type="button" class="btn btn-success btn-sm mb-2" id="add-row-btn"><i class="fas fa-plus"></i> Tambah Baris</button>
                    <div class="table-responsive">
                        <table class="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>Keterangan</th>
                                    <th>Deskripsi</th>
                                    <th>File Foto</th>
                                    <th>Act</th>
                                </tr>
                            </thead>
                            <tbody class="table-debet">
                                <tr>
                                    <td>
                                        <select class="form-select" name="keterangan[]" id="basicSelect">
                                            <option>Sebelum</option>
                                            <option>Epoxy</option>
                                            <option>Finish</option>
                                        </select>
                                    </td>
                                    <td><input type="text" name="deskripsi[]" class="form-control"></td>
                                    <td><input type="file" name="gambar[]" class="image-resize-filepond" accept=".jpg, .jpeg, .png, .svg"></td>
                                    <td>
                                        <button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- Tambahkan SweetAlert di view Anda -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Cek apakah ada parameter status di URL
        const urlParams = new URLSearchParams(window.location.search);
        const status = urlParams.get('status');

        if (status === 'success') {
            // Tampilkan toast sukses
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: 'Data berhasil disimpan',
                showConfirmButton: false,
                timer: 1500
            });
        } else if (status === 'error') {
            // Tampilkan toast error jika ada
            Swal.fire({
                position: 'top-end',
                icon: 'error',
                title: 'Terjadi kesalahan',
                showConfirmButton: false,
                timer: 1500
            });
        }
    });
</script>

<script>
    // pengerjaan
    function searchPengerjaan() {
        // Ambil input pencarian dan nilai pencarian
        const searchInput = document.getElementById('searchInput');
        const searchTerm = searchInput.value.toLowerCase();

        // Ambil semua baris dari tabel
        const rows = document.querySelectorAll('#pengerjaan-list tr');

        rows.forEach(row => {
            const kode = row.getAttribute('data-kode').toLowerCase();
            const nama = row.getAttribute('data-nama').toLowerCase();

            // Periksa apakah baris cocok dengan istilah pencarian
            if (kode.includes(searchTerm) || nama.includes(searchTerm)) {
                row.style.display = ''; // Tampilkan baris
            } else {
                row.style.display = 'none'; // Sembunyikan baris
            }
        });
    }
    // pengerjaan
    document.addEventListener('DOMContentLoaded', function() {
        // Tambahkan event listener untuk mengisi inputan dengan data yang dipilih
        const tableBody = document.getElementById('pengerjaan-list');

        tableBody.addEventListener('click', function(e) {
            const target = e.target.closest('tr');
            if (target) {
                const kode = target.getAttribute('data-kode');
                const nama = target.getAttribute('data-nama');

                // Set inputan dengan data yang dipilih
                document.getElementById('kodePengerjaan').value = kode;
                document.getElementById('pengerjaan').value = nama;

                // Tutup modal setelah memilih
                const modal = bootstrap.Modal.getInstance(document.getElementById('pengerjaanModal'));
                modal.hide();
            }
        });
    });
    // Sparepart
    // Fungsi pencarian untuk modal sparepart
    function searchSparepart() {
        // Ambil input pencarian dan nilai pencarian
        const searchInput = document.getElementById('search-input');
        const searchTerm = searchInput.value.toLowerCase();

        // Ambil semua baris dari tabel
        const rows = document.querySelectorAll('#sparepart-list tr');

        rows.forEach(row => {
            const kode = row.getAttribute('data-id').toLowerCase();
            const nama = row.getAttribute('data-nama').toLowerCase();
            const harga = row.getAttribute('data-harga').toLowerCase();

            // Periksa apakah baris cocok dengan istilah pencarian
            if (kode.includes(searchTerm) || nama.includes(searchTerm) || harga.includes(searchTerm)) {
                row.style.display = ''; // Tampilkan baris
            } else {
                row.style.display = 'none'; // Sembunyikan baris
            }
        });
    }

    // Tambahkan event listener untuk pencarian saat input berubah
    document.getElementById('search-input').addEventListener('input', searchSparepart);

    // Fungsi untuk mengisi inputan dengan data yang dipilih
    document.addEventListener('DOMContentLoaded', function() {
        const tableBody = document.getElementById('sparepart-list');

        tableBody.addEventListener('click', function(e) {
            const target = e.target.closest('tr');
            if (target) {
                const kode = target.getAttribute('data-id');
                const nama = target.getAttribute('data-nama');
                const harga = target.getAttribute('data-harga');

                // Set inputan dengan data yang dipilih
                document.getElementById('kodeSparepart').value = kode;
                document.getElementById('sparepartNama').value = nama;
                document.getElementById('hargaSparepart').value = harga;

                // Tutup modal setelah memilih
                const modal = bootstrap.Modal.getInstance(document.getElementById('kodepart'));
                modal.hide();
            }
        });
    });


    // asuransi
    document.addEventListener('DOMContentLoaded', function() {
        // Function to filter asuransi list based on search input
        document.getElementById('search-asuransi').addEventListener('input', function() {
            const searchValue = this.value.toLowerCase();
            const rows = document.querySelectorAll('#asuransi-list tr');

            rows.forEach(row => {
                const kode = row.getAttribute('data-kode').toLowerCase();
                const nama = row.getAttribute('data-nama').toLowerCase();

                if (kode.includes(searchValue) || nama.includes(searchValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        // Function to handle row click and set value to input
        document.querySelectorAll('#asuransi-list .clickable-row').forEach(row => {
            row.addEventListener('click', function() {
                const nama = this.getAttribute('data-nama');
                document.getElementById('asuransi').value = nama; // Set the name to the input field

                // Close the modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('asur'));
                modal.hide();
            });
        });
    });
    // Kendaraan Modal
    document.addEventListener('DOMContentLoaded', function() {
        const kendaraanList = document.getElementById('kendaraan-list');
        const searchKendaraan = document.getElementById('search-kendaraan');

        if (kendaraanList) {
            kendaraanList.addEventListener('click', function(e) {
                const target = e.target.closest('tr');
                if (target) {
                    const noKendaraan = target.getAttribute('data-no-kendaraan');
                    const customerName = target.getAttribute('data-customer');
                    const noContact = target.getAttribute('data-no-contact');

                    document.getElementById('no-kendaraan').value = noKendaraan;
                    document.getElementById('customer-name').value = customerName;
                    document.getElementById('no-contact').value = noContact;

                    // Close the modal
                    $('#kendaraanModal').modal('hide');
                }
            });

            if (searchKendaraan) {
                searchKendaraan.addEventListener('input', function() {
                    const filter = searchKendaraan.value.toLowerCase();
                    const rows = kendaraanList.getElementsByTagName('tr');

                    Array.from(rows).forEach(row => {
                        const cells = row.getElementsByTagName('td');
                        const noKendaraan = cells[0] ? cells[0].textContent.toLowerCase() : '';
                        const customerName = cells[1] ? cells[1].textContent.toLowerCase() : '';
                        const noContact = cells[2] ? cells[2].textContent.toLowerCase() : '';

                        if (noKendaraan.includes(filter) || customerName.includes(filter) || noContact.includes(filter)) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    });
                });
            }
        }
    });


    // Jenis Mobil Modal
    document.addEventListener('DOMContentLoaded', function() {
        const jenisMobilList = document.getElementById('jenis-mobil-list');
        const searchJenisMobil = document.getElementById('searchJenisMobil');

        if (jenisMobilList && searchJenisMobil) {
            // Filter function
            searchJenisMobil.addEventListener('input', function() {
                const filter = searchJenisMobil.value.toLowerCase();
                const rows = jenisMobilList.getElementsByTagName('tr');
                Array.from(rows).forEach(function(row) {
                    const jenisMobil = row.getAttribute('data-jenis-mobil').toLowerCase();
                    if (jenisMobil.indexOf(filter) > -1) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            // Handle row click
            jenisMobilList.addEventListener('click', function(e) {
                const target = e.target.closest('tr');
                if (target) {
                    const jenisMobil = target.getAttribute('data-jenis-mobil');

                    document.getElementById('jenis-mobil').value = jenisMobil;

                    // Close the modal
                    $('#jenisMobilModal').modal('hide');
                }
            });
        }
    });

    // Warna Modal
    document.addEventListener('DOMContentLoaded', function() {
        const warnaList = document.getElementById('warna-list');
        const searchWarna = document.getElementById('searchWarna');

        if (warnaList && searchWarna) {
            // Filter function
            searchWarna.addEventListener('input', function() {
                const filter = searchWarna.value.toLowerCase();
                const rows = warnaList.getElementsByTagName('tr');
                Array.from(rows).forEach(function(row) {
                    const warna = row.getAttribute('data-warna').toLowerCase();
                    if (warna.indexOf(filter) > -1) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            // Handle row click
            warnaList.addEventListener('click', function(e) {
                const target = e.target.closest('tr');
                if (target) {
                    const warna = target.getAttribute('data-warna');

                    document.getElementById('warna').value = warna;

                    // Close the modal
                    $('#warnaModal').modal('hide');
                }
            });
        }
    });
</script>

<!-- upload foto -->
<script>
    document.getElementById('add-row-btn').addEventListener('click', function() {
        var newRow = `<tr>
            <td>
                <select class="form-select" name="keterangan[]" id="basicSelect">
                    <option>Sebelum</option>
                    <option>Epoxy</option>
                    <option>Finish</option>
                </select>
            </td>
            <td><input type="text" name="deskripsi[]" class="form-control"></td>
            <td><input type="file" name="gambar[]" class="image-resize-filepond" accept=".jpg, .jpeg, .png, .svg"></td>
            <td>
                <button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>
            </td>
        </tr>`;
        document.querySelector('.table-debet').insertAdjacentHTML('beforeend', newRow);
    });

    document.querySelector('.table-debet').addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-row')) {
            e.target.closest('tr').remove();
        }
    });
</script>







<?= $this->endSection() ?>