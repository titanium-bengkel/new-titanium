<footer>
    <div class="footer clearfix mb-0 text-muted fixed-bottom">
        <div class="float-start">
            <p>2024 &copy; Titanium</p>
        </div>
        <!-- <div class="float-end">
            <p>Crafted with <span class="text-danger"><i class="bi bi-heart-fill icon-mid"></i></span>
                by <a href="https://saugi.me">Saugi</a></p>
        </div> -->
    </div>
</footer>
</div>
</div>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>

<!-- DataTables -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>

<!-- Perfect Scrollbar -->
<script src="<?= base_url('../dist/assets/extensions/perfect-scrollbar/perfect-scrollbar.min.js'); ?>"></script>

<!-- Apexcharts -->
<script src="<?= base_url('../dist/assets/extensions/apexcharts/apexcharts.min.js'); ?>"></script>
<script src="<?= base_url('../dist/assets/static/js/pages/dashboard.js'); ?>"></script>

<!-- Dark Mode -->
<script src="<?= base_url('../dist/assets/static/js/components/dark.js'); ?>"></script>

<!-- App JS -->
<script src="<?= base_url('../dist/assets/compiled/js/app.js'); ?>"></script>

<!-- Flatpickr -->
<script src="<?= base_url('../dist/assets/extensions/flatpickr/flatpickr.min.js'); ?>"></script>
<script src="<?= base_url('../dist/assets/static/js/pages/date-picker.js'); ?>"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



</body>

</html>