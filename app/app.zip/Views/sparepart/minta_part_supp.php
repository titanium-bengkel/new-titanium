<!-- File: app/Views/sparepart/permintaan_part.php -->
<?= $this->extend('layout/template'); ?>

<?= $this->section('content') ?>
<h3>Permintaan Sparepart Supply</h3>

<!-- Table Pre-order -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                    <!-- table head dark -->
                    <div class="table-responsive" style="font-size: 12px; margin:20px" ;>
                        <table class="table table-bordered mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th style="text-align: center;">#</th>
                                    <th style="text-align: center;">No. Order</th>
                                    <th style="text-align: center;">Tanggal klaim</th>
                                    <th style="text-align: center;">Tanggal Acc</th>
                                    <th style="text-align: center;">Type Mobil</th>
                                    <th style="text-align: center;">No. Polisi</th>
                                    <th style="text-align: center;">Warna</th>
                                    <th style="text-align: center;">Tahun</th>
                                    <th style="text-align: center;">Asuransi</th>
                                    <th style="text-align: center;">SA</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr>
                                    <td></td>
                                    <td><a href="order_posprev">TO01112024</a></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#creat-po">
                                            Terima Barang
                                        </button>
                                    </td>
                            </tbody>
                        </table>
                        <div class="card-body">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination pagination-primary">
                                    <li class="page-item"><a class="page-link" href="#">Prev</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modal terima barang -->
<div class="modal fade text-left" id="creat-po" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel3">Terima Barang</h5>
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5>ID</h5>
                                <div class="form-group row align-items-center">
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="nomor">Nomor (auto)</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="no-acc" class="form-control" name="no-acc" disabled>
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="tgl-acc">Tanggal</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="date" id="tgl" class="form-control" name="tgl" onkeydown="return false" onclick="this.showPicker()">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="jasa">Supplier</label>
                                    </div>
                                    <div class="col-lg-9 col-7 mb-3">
                                        <input type="text" id="jasa" class="form-control" name="jasa">
                                    </div>
                                    <div class="col-lg-1 col-2 mb-3">
                                        <button type="button" class="btn btn-secondary btn-sm" onclick="openModal()">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="sparepart">Gudang</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="sparepart" class="form-control" name="sparepart">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="keterangan">Keterangan</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <textarea class="form-control" id="keterangan" rows="1"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5>Data</h5>
                                <div class="form-group row align-items-center">
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="no-kendaraan">No. Repair Order</label>
                                    </div>
                                    <div class="col-lg-9 col-7 mb-3">
                                        <input type="text" id="no-kendaraan" class="form-control" name="no-kendaraan">
                                    </div>
                                    <div class="col-lg-1 col-2 mb-3">
                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#tertiarymodal">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="jenis-mobil">Asuransi</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="jenis-mobil" class="form-control" name="jenis-mobil">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="warna">Jenis mobil</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="warna" class="form-control" name="warna">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="pemilik">Nama pemilik</label>
                                    </div>
                                    <div class="col-lg-4 col-9 mb-3">
                                        <input type="text" id="pemilik" class="form-control" name="pemilik">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="warna-mobil">Warna</label>
                                    </div>
                                    <div class="col-lg-4 col-9 mb-3">
                                        <input type="text" id="warna-mobil" class="form-control" name="warna-mobil">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="no-contact">Nopol</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="no-contact" class="form-control" name="no-contact">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered mt-2">
                                        <thead>
                                            <tr>
                                                <th>Kode barang</th>
                                                <th>Nama barang</th>
                                                <th>Qty</th>
                                                <th>Satuan</th>
                                                <th>Pilih</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-group row align-items-center">
                                    <div class="col-lg-10 col-9">
                                        <button type="button" class="btn btn-primary" onclick="submitMainForm()">Simpan</button>
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Horizontal Input end -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Invoice sebagai modal sekunder -->
<div class="modal fade text-left" id="secondarymodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="search-input">Cari</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="search-input" class="form-control" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama Supplier</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ms-1" onclick="submitSecondaryModal()">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Submit</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade text-left" id="tertiarymodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Konten modal sekunder kedua -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary ms-1" onclick="submitTertiaryModal()">Submit</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    function openModal() {
        $('#secondarymodal').modal('show');
    }

    function submitSecondaryModal() {
        // Add logic for secondary modal submission
        console.log('Secondary modal submitted');
        $('#secondarymodal').modal('hide');
    }

    function submitMainForm() {
        // Add logic for main form submission
        console.log('Main form submitted');
        $('#creat-po').modal('hide');
    }

    $('#secondarymodal').on('hide.bs.modal', function() {
        // Custom logic when the secondary modal is closed
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get the current date
        const now = new Date();
        const currentMonth = now.getMonth() + 1; // Months are 0-based in JavaScript
        const currentYear = now.getFullYear();

        // Set the current month in the select
        const monthSelect = document.getElementById('selectMonth');
        monthSelect.value = currentMonth;

        // Set the current year and populate the year select
        const yearSelect = document.getElementById('selectYear');
        for (let year = 2020; year <= 2030; year++) {
            const option = document.createElement('option');
            option.value = year;
            option.text = year;
            if (year === currentYear) {
                option.selected = true;
            }
            yearSelect.appendChild(option);
        }
    });
</script>

<?= $this->endSection() ?>