<!-- File: app/Views/sparepart/permintaan_part.php -->
<?= $this->extend('layout/template'); ?>

<?= $this->section('content') ?>
<h3>Laporan Gudang Sparepart</h3>

<!-- Table Pre-order -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                <div class="card-header d-flex align-items-center justify-content-start flex-wrap" style="padding: 20px;">
                        <div class="d-flex align-items-center ms-md-auto w-100 w-md-auto">
                            <form action="/preorder/filter" method="get" class="d-flex align-items-center flex-wrap w-100">
                                <fieldset class="form-group me-2 mb-2 mb-md-0">
                                    <select class="form-select form-select-sm" id="basicSelect">
                                    <option>--Pilih Gudang--</option>
                                <option>GUDANG STOK SPAREPART</option>
                                <option>GUDANG REPAIR(MOBIL SUDAH ADA)</option>
                                <option>GUDANG SUPPLY DARI ASURANSI</option>
                                <option>GUDANG WAITING(MOBIL BELUM DATANG)</option>
                                <option>GUDANG SALVAGE</option>
                                    </select>
                                </fieldset>
                                <input type="text" name="search" class="form-control form-control-sm me-2 mb-2 mb-md-0" placeholder="Cari Kode/Nama Barang" style="width: 100%; max-width: 200px;">
                                <input type="date" name="date" class="form-control form-control-sm flatpickr-range me-2 mb-2 mb-md-0" placeholder="Select date.." style="width: 100%; max-width: 130px;">
                            </form>
                        </div>
                    </div>
                    <!-- <div class="card-header d-flex align-items-center">
                        <fieldset class="form-group mt-3 mr-2" style="width: 250px;">
                            <select class="form-select form-control" id="basicSelect">
                                <option>--Pilih Gudang--</option>
                                <option>GUDANG STOK SPAREPART</option>
                                <option>GUDANG REPAIR(MOBIL SUDAH ADA)</option>
                                <option>GUDANG SUPPLY DARI ASURANSI</option>
                                <option>GUDANG WAITING(MOBIL BELUM DATANG)</option>
                                <option>GUDANG SALVAGE</option>
                            </select>
                        </fieldset>
                        <input type="date" class="form-control flatpickr-range mt-2 mr-2"  placeholder="Select date.." style="margin-left:500px; width: 250px;">
                        <input type="text" class="form-control mt-2 mt-2 mr-2"  placeholder="Cari Kode/Nama Barang" style="margin-left:10px; width: 200px;">
                        <button type="button" class="btn btn-primary btn-sm mt-2 mr-2" style="margin-left:10px;">Show</button>
                    </div> -->
                    <!-- table head dark -->
                    <div class="table-responsive" style="margin: 20px;">
                        <table class="table table-bordered mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th style="text-align: center;">No</th>
                                    <th style="text-align: center;">Kode Barang</th>
                                    <th style="text-align: center;">Nama Barang</th>
                                    <th style="text-align: center;">Keterangan</th>
                                    <th style="text-align: center;">Harga</th>
                                    <th style="text-align: center;">Saldo Awal</th>
                                    <th style="text-align: center;">Debit</th>
                                    <th style="text-align: center;">Kredit</th>
                                    <th style="text-align: center;">Saldo Akhir</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr>
                                    <td></td>
                                    <td><a href="order_posprev">PO01112024</a></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Mutasi</a></td>
                                </tr>
                            </tbody>
                            <thead>
                                <tr>
                                    <th colspan="5" style="text-align: end;"></th>
                                    <th>0</th>
                                    <th>0</th>
                                    <th>0</th>
                                    <th>0</th>
                                    <th></th>
                                </tr>
                            </thead>
                        </table>
                        <div class="card-body">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination pagination-primary">
                                    <li class="page-item"><a class="page-link" href="#">Prev</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>


<!-- Table head options end -->

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get the current date
        const now = new Date();
        const currentMonth = now.getMonth() + 1; // Months are 0-based in JavaScript
        const currentYear = now.getFullYear();

        // Set the current month in the select
        const monthSelect = document.getElementById('selectMonth');
        monthSelect.value = currentMonth;

        // Set the current year and populate the year select
        const yearSelect = document.getElementById('selectYear');
        for (let year = 2020; year <= 2030; year++) {
            const option = document.createElement('option');
            option.value = year;
            option.text = year;
            if (year === currentYear) {
                option.selected = true;
            }
            yearSelect.appendChild(option);
        }
    });
</script>
<?= $this->endSection() ?>