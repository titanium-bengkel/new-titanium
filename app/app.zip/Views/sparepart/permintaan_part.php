<!-- File: app/Views/sparepart/permintaan_part.php -->
<?= $this->extend('layout/template'); ?>

<?= $this->section('content') ?>
<h3>Permintaan Sparepart</h3>

<!-- Table Pre-order -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                    <!-- table head dark -->
                    <div class="table-responsive" style="font-size: 12px; margin:20px" ;>
                        <table class="table table-bordered mb-0">
                            <thead class="thead-dark">
                                <tr style="text-align: center;">
                                    <th>#</th>
                                    <th>No. Order</th>
                                    <th>Tanggal klaim</th>
                                    <th>Tanggal Acc</th>
                                    <th>Type Mobil</th>
                                    <th>No. Polisi</th>
                                    <th>Warna</th>
                                    <th>Tahun</th>
                                    <th>Asuransi</th>
                                    <th>SA</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr>
                                    <td></td>
                                    <td><a href="order_posprev">PO01112024</a></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#creat-po">
                                            Creat PO
                                        </button>
                                    </td>
                            </tbody>
                        </table>
                        <div class="card-body">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination pagination-primary">
                                    <li class="page-item"><a class="page-link" href="#">Prev</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- modal creat PO -->
<div class="modal fade text-left" id="creat-po" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel3"></h5>
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5>ID</h5>
                                <div class="form-group row align-items-center">
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="nomor">Nomor (auto)</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="no-acc" class="form-control" name="no-acc" disabled>
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="tgl-acc">Tanggal</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="date" id="tgl" class="form-control" name="tgl" onkeydown="return false" onclick="this.showPicker()">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="jasa">Supplier</label>
                                    </div>
                                    <div class="col-lg-9 col-7 mb-3">
                                        <input type="text" id="jasa" class="form-control" name="jasa">
                                    </div>
                                    <div class="col-lg-1 col-2 mb-3">
                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#no-ken">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="sparepart">Jatuh tempo</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="sparepart" class="form-control" name="sparepart">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="keterangan">Keterangan</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <textarea class="form-control" id="keterangan" rows="1"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5>Data</h5>
                                <div class="form-group row align-items-center">
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="no-kendaraan">No. Repair Order</label>
                                    </div>
                                    <div class="col-lg-9 col-7 mb-3">
                                        <input type="text" id="no-kendaraan" class="form-control" name="no-kendaraan">
                                    </div>
                                    <div class="col-lg-1 col-2 mb-3">
                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#no-ken">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="jenis-mobil">Asuransi</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="jenis-mobil" class="form-control" name="jenis-mobil">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="warna">Jenis mobil</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="warna" class="form-control" name="warna">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="pemilik">Nama pemilik</label>
                                    </div>
                                    <div class="col-lg-4 col-9 mb-3">
                                        <input type="text" id="pemilik" class="form-control" name="pemilik">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="warna-mobil">Warna</label>
                                    </div>
                                    <div class="col-lg-4 col-9 mb-3">
                                        <input type="text" id="warna-mobil" class="form-control" name="warna-mobil">
                                    </div>
                                    <div class="col-lg-2 col-3 mb-3">
                                        <label class="col-form-label" for="no-contact">Nopol</label>
                                    </div>
                                    <div class="col-lg-10 col-9 mb-3">
                                        <input type="text" id="no-contact" class="form-control" name="no-contact">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered mt-2">
                                        <thead>
                                            <tr>
                                                <th>Kode barang</th>
                                                <th>Nama barang</th>
                                                <th>Qty</th>
                                                <th>Satuan</th>
                                                <th>Harga</th>
                                                <th>Jumlah</th>
                                                <th>Qty beli</th>
                                                <th>Qty sisa</th>
                                                <th>No faktur</th>
                                                <th>Tgl faktur</th>
                                                <th>Pilih</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-group row align-items-center">
                                    <div class="col-lg-10 col-9">
                                        <button type="button" class="btn btn-primary">Simpan Invoice</button>
                                        <button type="button" class="btn btn-danger">Batal</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Horizontal Input end -->
                </div>
            </div>
        </div>
        <!-- Table head options end -->

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Get the current date
                const now = new Date();
                const currentMonth = now.getMonth() + 1; // Months are 0-based in JavaScript
                const currentYear = now.getFullYear();

                // Set the current month in the select
                const monthSelect = document.getElementById('selectMonth');
                monthSelect.value = currentMonth;

                // Set the current year and populate the year select
                const yearSelect = document.getElementById('selectYear');
                for (let year = 2020; year <= 2030; year++) {
                    const option = document.createElement('option');
                    option.value = year;
                    option.text = year;
                    if (year === currentYear) {
                        option.selected = true;
                    }
                    yearSelect.appendChild(option);
                }
            });
        </script>
        <?= $this->endSection() ?>