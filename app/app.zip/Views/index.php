<?= $this->extend('layout/template'); ?>
<?= $this->section('content');  ?>
<div class="page-heading">
    <h3>OVERVIEW</h3>
</div>
<div class="page-content">
    <section class="row">
        <div class="col-12 col-lg-9">
            <div class="row">
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex align-justify ">
                                    <div class="stats-icon purple mb-2">
                                        <i class="iconly-boldShow"></i>
                                    </div>
                                </div>
                                <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                    <h6 class="text-muted font-semibold">Profile Views</h6>
                                    <h6 class="font-extrabold mb-0">112.000</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start ">
                                    <div class="stats-icon blue mb-2">
                                        <i class="iconly-boldProfile"></i>
                                    </div>
                                </div>
                                <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                    <h6 class="text-muted font-semibold">Followers</h6>
                                    <h6 class="font-extrabold mb-0">183.000</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start ">
                                    <div class="stats-icon green mb-2">
                                        <i class="iconly-boldAdd-User"></i>
                                    </div>
                                </div>
                                <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                    <h6 class="text-muted font-semibold">Following</h6>
                                    <h6 class="font-extrabold mb-0">80.000</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start ">
                                    <div class="stats-icon red mb-2">
                                        <i class="iconly-boldBookmark"></i>
                                    </div>
                                </div>
                                <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                    <h6 class="text-muted font-semibold">Saved Post</h6>
                                    <h6 class="font-extrabold mb-0">112</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end card -->


    <!-- pre order input start -->
    <!-- <section class="section">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">PRE ORDER</h4>
            </div>
            <div class="card-body">
                <div class="row"> -->
                    <!-- Bagian Kiri -->
                    <!-- <div class="col-md-4">
                        <div class="form-group">
                            <label for="disabledInput">Service Advisor</label>
                            <input type="text" class="form-control" id="basicInput" disabled>
                        </div>

                        <div class="form-group">
                            <label for="disabledInput">Pre-Order ID</label>
                            <input type="text" class="form-control" id="id" disabled>
                        </div>

                        <div class="form-group">
                            <label for="basicInput">No.Kendaraan</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>

                        <div class="form-group">
                            <label for="basicInput">No Rangka</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>

                        <div class="form-group">
                            <label for="basicInput">No Contact</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>
                        <div class="form-group">
                            <label for="basicInput">Jenis mobil</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>
                    </div> -->

                    <!-- Bagian Tengah -->
                    <!-- <div class="col-md-4">
                        <div class="form-group">
                            <label for="basicInput">Customer Name</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>

                        <div class="form-group">
                            <label for="basicInput">Asuransi</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>

                        <div class="form-group">
                            <label for="basicInput">No Polis</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>

                        <div class="form-group">
                            <label for="basicInput">Alamat</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>

                        <div class="form-group">
                            <label for="basicInput">Kota</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>
                        <div class="form-group">
                            <label for="basicInput">Warna</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>
                    </div> -->

                    <!-- Bagian Kanan -->
                    <!-- <div class="col-md-4">
                        <div class="form-group">
                            <label for="basicInput">Tahun kendaraan</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>

                        <div class="form-group">
                            <label for="basicInput">Tanggal masuk</label>
                            <input type="date" class="form-control mb-3 flatpickr-no-config" placeholder="Select date..">
                        </div>

                        <div class="form-group">
                            <label for="basicInput">Harga estimasi</label>
                            <input type="text" class="form-control" id="basicInput">
                        </div>

                        <div class="form-group">
                            <label for="basicInput">Status Order</label>
                            <fieldset class="form-group">
                                <select class="form-select" id="basicSelect">
                                    <option>Pre-Order</option>
                                </select>
                            </fieldset>
                        </div>

                        <div class="form-group">
                            <label for="basicInput">Progres</label>
                            <fieldset class="form-group">
                                <select class="form-select" id="basicSelect">
                                    <option>Proses Klaim</option>
                                    <option>Menunggu sparepart</option>
                                    <option>Menunggu part supply</option>
                                    <option>Siap Masuk</option>
                                    <option>Batal Klaim Asuransi</option>
                                    <option>Batal masuk</option>
                                </select>
                            </fieldset>
                        </div>
                    </div>
                </div> -->
                <!-- Tombol Simpan dan Batal -->
                <!-- <div class="card-footer text-center">
                    <div class="buttons">
                        <a href="#" class="btn btn-primary">Simpan Pre-Order</a>
                        <a href="#" class="btn btn-danger">Batal</a>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <!-- input stop -->


</div>

<?= $this->endSection(); ?>