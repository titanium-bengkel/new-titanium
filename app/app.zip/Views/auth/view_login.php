<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Office</title>
    <link rel="shortcut icon" href="<?= base_url('../dist/assets/compiled/svg/favicon.svg'); ?>" type="image/x-icon">
    <link rel="shortcut icon" href="data:image/png;base64,..." type="image/png">
    <link rel="stylesheet" href="<?= base_url('../dist/assets/compiled/css/app.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('../dist/assets/compiled/css/app-dark.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('../dist/assets/compiled/css/auth.css'); ?>">
</head>

<body>
    <script src="<?= base_url('../dist/assets/static/js/initTheme.js'); ?>"></script>
    <div id="auth" class="d-flex justify-content-center">
        <div class="card">
            <div class="d-flex align-content-center">
                <div id="auth-left">
                    <div class="auth-logo">
                        <a href="index.php"><img src="<?= base_url('../dist/assets/compiled/jpg/tt.jpg'); ?>" alt="Logo"></a>
                    </div>
                    <h1 class="auth-title text-center">Login</h1>
                    <?php if (session()->getFlashdata('error')) : ?>
                        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
                    <?php endif; ?>
                    <form action="<?= base_url('login') ?>" method="post">
                        <div class="form-group position-relative has-icon-left mb-4">
                            <input type="text" class="form-control form-control-xl" name="username" placeholder="Username">
                            <div class="form-control-icon">
                                <i class="bi bi-person"></i>
                            </div>
                        </div>
                        <div class="form-group position-relative has-icon-left mb-4">
                            <input type="password" class="form-control form-control-xl" name="password" placeholder="Password">
                            <div class="form-control-icon">
                                <i class="bi bi-shield-lock"></i>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-block btn-lg shadow-lg mt-5" type="submit">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>