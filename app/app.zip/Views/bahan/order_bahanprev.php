<?= $this->extend('layout/template'); ?>
<?= $this->section('content') ?>
<h3>Add PO Bahan</h3>

<!-- Horizontal Input start -->
<section id="horizontal-input">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5>ID</h5>
                    <div class="form-group row align-items-center">
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="id_po_bahan">Nomor (auto)</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="id_po_bahan" class="form-control" name="id_po_bahan" value="<?= $bahan['id_po_bahan']; ?>" readonly>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="tanggal">Tanggal</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="date" id="tanggal" class="form-control" name="tanggal" value="<?= $bahan['tanggal']; ?>" readonly>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="supplier">Supplier</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="supplier" class="form-control" name="supplier" value="<?= $bahan['supplier']; ?>" readonly>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="jatuh_tempo">Jatuh tempo</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="date" id="jatuh_tempo" class="form-control" name="jatuh_tempo" value="<?= $bahan['jatuh_tempo']; ?>" readonly>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="keterangan">Keterangan</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <textarea class="form-control" id="keterangan" rows="1" name="keterangan" readonly><?= $bahan['keterangan']; ?></textarea>
                        </div>
                    </div>
                    <hr>
                    <h5>Data</h5>
                    <div class="form-group row align-items-center">
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="no_ro">No. Repair Order</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="no_ro" class="form-control" name="no_ro" value="<?= $bahan['no_ro']; ?>" readonly>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="asuransi">Asuransi</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="asuransi" class="form-control" name="asuransi" value="<?= $bahan['asuransi']; ?>" readonly>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="jenis_mobil">Jenis mobil</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="jenis_mobil" class="form-control" name="jenis_mobil" value="<?= $bahan['jenis_mobil']; ?>" readonly>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="nama_pemilik">Nama pemilik</label>
                        </div>
                        <div class="col-lg-4 col-9 mb-3">
                            <input type="text" id="nama_pemilik" class="form-control" name="nama_pemilik" value="<?= $bahan['nama_pemilik']; ?>" readonly>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="warna">Warna</label>
                        </div>
                        <div class="col-lg-4 col-9 mb-3">
                            <input type="text" id="warna" class="form-control" name="warna" value="<?= $bahan['warna']; ?>" readonly>
                        </div>
                        <div class="col-lg-2 col-3 mb-3">
                            <label class="col-form-label" for="no_kendaraan">No. Kendaraan</label>
                        </div>
                        <div class="col-lg-10 col-9 mb-3">
                            <input type="text" id="no_kendaraan" class="form-control" name="no_kendaraan" value="<?= $bahan['no_kendaraan']; ?>" readonly>
                        </div>
                    </div>
                    <!-- tabel detail barang  -->
                    <div class="table-responsive mt-2">
                        <table class="table table-bordered my-table-class">
                            <thead>
                                <tr>
                                    <th>Kode barang</th>
                                    <th>Nama barang</th>
                                    <th>Qty</th>
                                    <th>Satuan</th>
                                    <th>Harga</th>
                                    <th>Jumlah</th>
                                    <th>Qty beli</th>
                                    <th>Qty sisa</th>
                                    <th>No faktur</th>
                                    <th>Tgl faktur</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="detail-barang-body">
                                <?php if (!empty($detail_barang)) : ?>
                                    <?php foreach ($detail_barang as $detail) : ?>
                                        <tr>
                                            <td><?= $detail['id_kode_barang']; ?></td>
                                            <td><?= $detail['nama_barang']; ?></td>
                                            <td><?= $detail['qty']; ?></td>
                                            <td><?= $detail['satuan']; ?></td>
                                            <td><?= number_format($detail['harga'], 0, ',', '.'); ?></td>
                                            <td><?= number_format($detail['jumlah'], 0, ',', '.'); ?></td>
                                            <td><?= $detail['qty_beli']; ?></td>
                                            <td><?= $detail['qty_sisa']; ?></td>
                                            <td><?= $detail['no_faktur']; ?></td>
                                            <td><?= $detail['tgl_faktur']; ?></td>
                                            <td></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="11">Tidak ada data barang</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="2">Total Qty</td>
                                    <td><?= $total_qty; ?></td>
                                    <td colspan="2">Total Jumlah</td>
                                    <td><?= number_format($total_jumlah, 0, ',', '.'); ?></td>
                                    <td colspan="5"></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="form-group row align-items-center mt-3">
                        <div class="col-lg-10 col-9">
                            <a href="<?= base_url('order_bahan'); ?>" class="btn btn-primary">Input Baru</a>
                            <!-- Tombol Batal -->
                            <a href="<?= base_url('po_bahan'); ?>" class="btn btn-danger">Batal</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Horizontal Input end -->

<!-- modal asuransi -->
<div class="modal fade text-left" id="supply" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="search-input">Cari</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="search-input" class="form-control" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama Supplier</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Submit</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end -->

<!-- modal supplier -->
<div class="modal fade text-left" id="supp" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="search-input">Cari</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="search-input" class="form-control" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama Supplier</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Accept</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- modal RP -->
<div class="modal fade text-left" id="repair" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="search-input">Cari</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="search-input" class="form-control" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>No.Order</th>
                                <th>Type mobil</th>
                                <th>Nopol</th>
                                <th>Warna</th>
                                <th>Tahun</th>
                                <th>Asuransi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        <i class="bx bx-x d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Close</span>
                    </button>
                    <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                        <i class="bx bx-check d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Submit</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- js tgl -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var today = new Date();
        var day = String(today.getDate()).padStart(2, '0');
        var month = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
        var year = today.getFullYear();
        var todayString = year + '-' + month + '-' + day;

        document.getElementById('tgl').value = todayString;
    });
</script>




<?= $this->endSection() ?>