<!-- File: app/Views/sparepart/permintaan_part.php -->
<?= $this->extend('layout/template'); ?>

<?= $this->section('content') ?>

<!-- Table Pre-order -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <h5 class="ms-3 mb-3">PO Pemesanan Bahan</h5>
            <div class="card">
                <div class="card-content">
                    <div class="card-header d-flex align-items-center justify-content-start flex-wrap" style="padding: 20px;">
                        <div class="d-flex align-items-center ms-md-auto w-100 w-md-auto">
                            <form action="/preorder/filter" method="get" class="d-flex align-items-center flex-wrap w-100">
                                <input type="text" name="search" class="form-control form-control-sm me-2 mb-2 mb-md-0" placeholder="Nomor" style="width: 100%; max-width: 130px;">
                                <input type="date" name="date" class="form-control form-control-sm flatpickr-range me-2 mb-2 mb-md-0" placeholder="Select date.." style="width: 100%; max-width: 130px;">
                                <select name="month" class="form-control form-control-sm me-2 mb-2 mb-md-0" id="selectMonth" style="width: 100%; max-width: 100px;">
                                    <option value="1">Januari</option>
                                    <option value="2">Februari</option>
                                    <option value="3">Maret</option>
                                    <option value="4">April</option>
                                    <option value="5">Mei</option>
                                    <option value="6">Juni</option>
                                    <option value="7">Juli</option>
                                    <option value="8">Agustus</option>
                                    <option value="9">September</option>
                                    <option value="10">Oktober</option>
                                    <option value="11">November</option>
                                    <option value="12">Desember</option>
                                </select>
                                <select name="year" class="form-control form-control-sm mb-2 mb-md-0" id="selectYear" style="width: 100%; max-width: 100px;">
                                    <!-- Tahun akan diisi otomatis -->
                                </select>
                            </form>
                        </div>
                        <div class="d-flex align-items-center mt-4 w-100 justify-content-start">
                            <a href="<?= base_url('order_bahan') ?>" class="btn btn-primary btn-sm" style="width: 60px;">Add</a>
                        </div>
                    </div>

                    <!-- table head dark -->
                    <div class="table-responsive" style="font-size: 12px; margin: 20px;">
                        <table class="table table-bordered mb-0" id="po_bahan_table">
                            <thead class="thead-dark" style="text-align: center;">
                                <tr>
                                    <th>#</th>
                                    <th>OK</th>
                                    <th>Nomor</th>
                                    <th>Tanggal</th>
                                    <th>Nama supplier</th>
                                    <th>No RO</th>
                                    <th>No. kendaraan</th>
                                    <th>Asuransi</th>
                                    <th>Unit</th>
                                    <th>Jumlah</th>
                                    <th>No. Faktur</th>
                                    <th>Ket</th>
                                    <th>User</th>
                                    <th>Act</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php if (!empty($bahan)) : ?>
                                    <?php foreach ($bahan as $key => $item) : ?>
                                        <tr>
                                            <td><?= $key + 1; ?></td>
                                            <td></td>
                                            <td>
                                                <a href="<?= base_url('order_bahanprev/' . $item['id_po_bahan']); ?>">
                                                    <?= $item['id_po_bahan']; ?>
                                                </a>
                                            </td>
                                            <td><?= $item['tanggal']; ?></td>
                                            <td><?= $item['supplier']; ?></td>
                                            <td><?= $item['no_ro']; ?></td>
                                            <td><?= $item['no_kendaraan']; ?></td>
                                            <td><?= $item['asuransi']; ?></td>
                                            <td><?= $item['jenis_mobil']; ?></td>
                                            <td><?= number_format($item['total_jumlah'], 0, ',', '.'); ?></td> <!-- Tambahkan kolom jumlah jika tersedia -->
                                            <td></td> <!-- Tambahkan kolom No. Faktur jika tersedia -->
                                            <td><?= $item['keterangan']; ?></td>
                                            <td></td> <!-- Tambahkan kolom user jika tersedia -->
                                            <td>
                                                <!-- button hapus -->
                                                <a href="<?= base_url('bahan/delete/' . $item['id_po_bahan']); ?>" class="btn btn-danger btn-sm delete-user-btn" style="padding: 1px 3px; font-size: 10px;" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="14">Tidak ada data</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr style="text-align: center;">
                                    <th colspan="9" style="text-align: end;">Total Perpage</th>
                                    <th></th>
                                    <th colspan="5"></th>
                                </tr>
                                <tr style="text-align: center;">
                                    <th colspan="9" style="text-align: end;">Total All</th>
                                    <th style="text-align: center;"></th>
                                    <th colspan="4"></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Table head options end -->

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get the current date
        const now = new Date();
        const currentMonth = now.getMonth() + 1; // Months are 0-based in JavaScript
        const currentYear = now.getFullYear();

        // Set the current month in the select
        const monthSelect = document.getElementById('selectMonth');
        monthSelect.value = currentMonth;

        // Set the current year and populate the year select
        const yearSelect = document.getElementById('selectYear');
        for (let year = 2020; year <= 2030; year++) {
            const option = document.createElement('option');
            option.value = year;
            option.text = year;
            if (year === currentYear) {
                option.selected = true;
            }
            yearSelect.appendChild(option);
        }
    });
</script>

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>


<!-- <script>
    $(document).ready( function () {
        $('#po_bahan_table').DataTable({
            "order": [[ 2, "desc" ]] // Mengurutkan berdasarkan kolom nomor (id_po_bahan) secara descending
        });
    });

</script> -->



<?= $this->endSection() ?>