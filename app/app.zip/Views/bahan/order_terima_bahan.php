<?= $this->extend('layout/template'); ?>
<?= $this->section('content') ?>
<h3>Add Penerimaan Sparepart</h3>

<!-- Horizontal Input start -->
<section id="horizontal-input">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5>ID</h5>
                    <form action="<?= base_url('/bahan/create_terima') ?>" method="post">
                        <div class="form-group row align-items-center">
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="nomor">No.penerimaan</label>
                            </div>
                            <div class="col-lg-10 col-9 mb-3">
                                <input type="text" id="no-terima" class="form-control" name="no-terima" value="<?= $generatedIdTerima ?>" readonly>
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="tgl">Tanggal</label>
                            </div>
                            <div class="col-lg-10 col-9 mb-3">
                                <input type="date" id="tgl" class="form-control" name="tgl" onkeydown="return false" onclick="this.showPicker()">
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="supplier">Supplier</label>
                            </div>
                            <div class="col-lg-9 col-7 mb-3">
                                <input type="text" id="supplier" class="form-control" name="supplier">
                            </div>
                            <div class="col-lg-1 col-2 mb-3">
                                <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#supp">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="jatuh_tempo">Jatuh tempo</label>
                            </div>
                            <div class="col-lg-10 col-9 mb-3">
                                <input type="date" id="jatuh_tempo" class="form-control" name="jatuh_tempo" onkeydown="return false" onclick="this.showPicker()">
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="keterangan">Keterangan</label>
                            </div>
                            <div class="col-lg-10 col-9 mb-3">
                                <textarea class="form-control" id="keterangan" name="keterangan" rows="1"></textarea>
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="gudang">Gudang</label>
                            </div>
                            <div class="col-lg-10 col-7 mb-3">
                                <fieldset class="form-group">
                                    <select class="form-select" id="gudang" name="gudang">
                                        <option>GUDANG BAHAN</option>
                                    </select>
                                </fieldset>
                            </div>
                        </div>
                        <h5>Data</h5>
                        <div class="form-group row align-items-center">
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="no-kendaraan">No. PO/Nopol</label>
                            </div>
                            <div class="col-lg-9 col-7 mb-3">
                                <input type="text" id="no-kendaraan" class="form-control" name="no-kendaraan">
                            </div>
                            <div class="col-lg-1 col-2 mb-3">
                                <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#no-kend">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="kota">Kota</label>
                            </div>
                            <div class="col-lg-4 col-9 mb-3">
                                <input type="text" id="kota" class="form-control" name="kota">
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="nopol">Nopol</label>
                            </div>
                            <div class="col-lg-4 col-9 mb-3">
                                <input type="text" id="nopol" class="form-control" name="nopol">
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="alamat">Alamat</label>
                            </div>
                            <div class="col-lg-9 col-7 mb-3">
                                <input type="text" id="alamat" class="form-control" name="alamat">
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="pembayaran">Metode Pembayaran</label>
                            </div>
                            <div class="col-lg-10 col-7 mb-3">
                                <fieldset class="form-group">
                                    <select class="form-select" id="pembayaran" name="pembayaran">
                                        <option>--Pilih--</option>
                                        <option>TRANSFER</option>
                                        <option>KREDIT</option>
                                        <option>CASH</option>
                                    </select>
                                </fieldset>
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="ppn">PPN</label>
                            </div>
                            <div class="col-lg-10 col-7 mb-3">
                                <fieldset class="form-group">
                                    <select class="form-select" id="ppn" name="ppn">
                                        <option>--Pilih--</option>
                                        <option>PPN</option>
                                        <option>Non PPN</option>
                                    </select>
                                </fieldset>
                            </div>
                            <div class="col-lg-2 col-3 mb-3">
                                <label class="col-form-label" for="term">Term</label>
                            </div>
                            <div class="col-lg-4 col-9 mb-3">
                                <input type="text" id="term" class="form-control" name="term">
                            </div>
                        </div>
                        <button type="button" class="btn btn-success btn-sm" id="add-row-btn"><i class="fas fa-plus"></i> Tambah Baris</button>
                        <div class="table-responsive">
                            <table class="table table-bordered mt-2 my-table-class">
                                <thead>
                                    <tr>
                                        <th>Kode barang</th>
                                        <th>Nama barang</th>
                                        <th>Qty</th>
                                        <th>Satuan</th>
                                        <th>Harga</th>
                                        <th>Disc</th>
                                        <th>Jumlah</th>
                                        <th>No PO</th>
                                        <th>PO id</th>
                                        <th>Pilih All <input type="checkbox" id="pilih-all"></th>
                                        <th>Act</th>
                                    </tr>
                                </thead>
                                <tbody id="detail-barang-body">
                                    <tr>
                                        <td><input type="text" class="form-control" name="kode_barang[]"  data-bs-toggle="modal" data-bs-target="#kodeBarangModal" readonly></td>
                                        <td><input type="text" class="form-control" name="nama_barang[]"></td>
                                        <td><input type="text" class="form-control qty" name="qty[]"></td>
                                        <td><input type="text" class="form-control" name="satuan[]"></td>
                                        <td><input type="text" class="form-control harga" name="harga[]"></td>
                                        <td><input type="text" class="form-control" name="disc[]"></td>
                                        <td><input type="text" class="form-control jumlah" name="jumlah[]" readonly></td>
                                        <td><input type="text" class="form-control" name="no_po[]"></td>
                                        <td></td>
                                        <td><input type="checkbox" class="form-check-input pilih-checkbox"></td>
                                        <td>
                                            <button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2">Total Qty</td>
                                        <td><input type="text" class="form-control" id="total-qty" name="total-qty[]" readonly></td>
                                        <td colspan="3">Total Jumlah</td>
                                        <td><input type="text" class="form-control" id="total-jumlah" name="total-jumlah[]" readonly></td>
                                        <td colspan="6"></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <div class="form-group row align-items-center mt-4">
                            <div class="col-lg-10 col-9">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <button type="button" class="btn btn-danger">Batal</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Horizontal Input end -->


<!-- modal supplier -->
<div class="modal fade" id="supp" tabindex="-1" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Cari Supplier</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="search-supplier" class="form-label">Cari</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="search-supplier" class="form-control" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama Supplier</th>
                            </tr>
                        </thead>
                        <tbody id="supplier-list">
                            <?php if (!empty($supplier)) : ?>
                                <?php foreach ($supplier as $a) : ?>
                                    <tr class="clickable-row" data-kode="<?= $a->kode ?>" data-nama="<?= $a->nama ?>">
                                        <td><?= $a->kode ?></td>
                                        <td><?= $a->nama ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="2">Data supplier tidak tersedia.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer p-2">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- End -->

<div class="modal fade" id="no_kend" tabindex="-1" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel2">Cari PO</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <label for="search-input" class="col-md-4 col-form-label">Cari</label>
                    <div class="col-md-8">
                        <input type="text" id="search-input" class="form-control" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>Nomor</th>
                                <th>Tanggal</th>
                                <th>Kode Supplier</th>
                                <th>Nama</th>
                                <th>Nopol</th>
                                <th>Jumlah PO</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- modal detail barang -->
<div class="modal fade" id="kodeBarangModal" tabindex="-1" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Cari Bahan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="search-barang" class="form-label">Cari</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="search-barang" class="form-control" name="search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Harga</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($barang)) : ?>
                                <?php foreach ($barang as $b) : ?>
                                    <tr data-satuan="<?= $b->sat_B ?>">
                                        <td><?= $b->kode ?></td>
                                        <td><?= $b->nama ?></td>
                                        <td><?= $b->hargabeli_B ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="2">Data supplier tidak tersedia.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- js tgl -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var today = new Date();
        var day = String(today.getDate()).padStart(2, '0');
        var month = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
        var year = today.getFullYear();
        var todayString = year + '-' + month + '-' + day;

        document.getElementById('tgl').value = todayString;
    });
</script>

<!-- tabel skrip -->



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function formatNumber(number) {
        return new Intl.NumberFormat('id-ID').format(number);
    }

    function updateJumlah() {
        let totalQty = 0;
        let totalJumlah = 0;
        $('#detail-barang-body tr').each(function() {
            const qty = parseFloat($(this).find('.qty').val()) || 0;
            const harga = parseFloat($(this).find('.harga').val()) || 0;
            const jumlah = qty * harga;
            $(this).find('.jumlah').val(formatNumber(jumlah));
            totalQty += qty;
            totalJumlah += jumlah;
        });
        $('#total-qty').val(formatNumber(totalQty));
        $('#total-jumlah').val(formatNumber(totalJumlah));
    }

    $(document).ready(function() {
        var selectedRow; // Variabel untuk menyimpan baris yang dipilih

        // Menambahkan baris baru ke dalam tabel
        $('#add-row-btn').click(function() {
            var row = '<tr>' +
                '<td><input type="text" class="form-control" name="kode_barang[]" data-bs-toggle="modal" data-bs-target="#kodeBarangModal" readonly></td>' +
                '<td><input type="text" class="form-control" name="nama_barang[]"></td>' +
                '<td><input type="text" class="form-control qty" name="qty[]"></td>' +
                '<td><input type="text" class="form-control" name="satuan[]"></td>' +
                '<td><input type="text" class="form-control harga" name="harga[]"></td>' +
                '<td><input type="text" class="form-control" name="disc[]"></td>' +
                '<td><input type="text" class="form-control jumlah" name="jumlah[]" readonly></td>' +
                '<td><input type="text" class="form-control" name="no_po[]"></td>' +
                '<td></td>' +
                '<td><input type="checkbox" class="form-check-input pilih-checkbox"></td>' +
                '<td>' +
                '<button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>' +
                '</td>' +
                '</tr>';
            $('#detail-barang-body').append(row);
            updateRemoveButtonStatus();
        });

        // Menyimpan referensi baris yang sedang dipilih
        $('#detail-barang-body').on('click', 'input[name="kode_barang[]"]', function() {
            selectedRow = $(this).closest('tr'); // Simpan referensi baris yang diklik
        });

        // Mengisi data ke baris yang dipilih ketika item di modal dipilih
        $('#kodeBarangModal tbody').on('click', 'tr', function() {
            // Mendapatkan data dari baris yang dipilih di modal
            const kodeBarang = $(this).find('td:eq(0)').text();
            const namaBarang = $(this).find('td:eq(1)').text();
            const hargaBarang = $(this).find('td:eq(2)').text();
            const satuanBarang = $(this).data('satuan'); // Mendapatkan data satuan dari atribut data-satuan

            // Mengisi data ke baris yang sedang dipilih di tabel utama
            if (selectedRow) {
                selectedRow.find('input[name="kode_barang[]"]').val(kodeBarang);
                selectedRow.find('input[name="nama_barang[]"]').val(namaBarang);
                selectedRow.find('input[name="harga[]"]').val(hargaBarang);
                selectedRow.find('input[name="satuan[]"]').val(satuanBarang); // Mengisi input satuan
            }

            // Menutup modal
            $('#kodeBarangModal').modal('hide');
        });

        // Menghapus baris
        $('.my-table-class tbody').on('click', '.remove-row', function() {
            $(this).closest('tr').remove();
            updateRemoveButtonStatus();
            updateJumlah();
        });

        // Fungsi untuk mengatur status tombol kurangi
        function updateRemoveButtonStatus() {
            var rowCount = $('.my-table-class tbody tr').length;
            if (rowCount === 1) {
                $('.my-table-class .remove-row').prop('disabled', true); // Menonaktifkan tombol jika hanya ada satu baris
            } else {
                $('.my-table-class .remove-row').prop('disabled', false); // Mengaktifkan tombol jika lebih dari satu baris
            }
        }

        // Memastikan status tombol saat halaman dimuat
        updateRemoveButtonStatus();

        // Fungsi untuk checkbox "Pilih All"
        $('#pilih-all').click(function() {
            var isChecked = $(this).is(':checked');
            $('.my-table-class .pilih-checkbox').prop('checked', isChecked);
        });

        // Pastikan checkbox "Pilih All" terupdate ketika checkbox lain di-klik
        $('.my-table-class').on('click', '.pilih-checkbox', function() {
            var allChecked = $('.my-table-class .pilih-checkbox').length === $('.my-table-class .pilih-checkbox:checked').length;
            $('#pilih-all').prop('checked', allChecked);
        });

        // Update jumlah ketika input qty atau harga berubah
        $('.my-table-class tbody').on('input', '.qty, .harga', function() {
            updateJumlah();
        });

        // Inisialisasi awal
        updateJumlah();
    });



    // modal supplier
    document.addEventListener('DOMContentLoaded', function() {
        // Function to filter supplier list based on search input
        document.getElementById('search-supplier').addEventListener('input', function() {
            const searchValue = this.value.toLowerCase();
            const rows = document.querySelectorAll('#supplier-list tr');

            rows.forEach(row => {
                const kode = row.getAttribute('data-kode').toLowerCase();
                const nama = row.getAttribute('data-nama').toLowerCase();

                if (kode.includes(searchValue) || nama.includes(searchValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        // Function to handle row click and set value to input
        document.querySelectorAll('#supplier-list .clickable-row').forEach(row => {
            row.addEventListener('click', function() {
                const nama = this.getAttribute('data-nama');
                document.getElementById('supplier').value = nama; // Set the name to the input field

                // Close the modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('supp'));
                modal.hide();
            });
        });
    });
    // modal supplier ends here
</script>


<?= $this->endSection() ?>