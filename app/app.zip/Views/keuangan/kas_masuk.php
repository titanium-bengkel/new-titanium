<!-- File: app/Views/sparepart/permintaan_part.php -->
<?= $this->extend('layout/template'); ?>

<?= $this->section('content') ?>
<h3>Kas Masuk</h3>

<!-- Table Pre-order -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-header d-flex align-items-center" style="width: fit-content;">
                        <div class="buttons d-flex align-items-center">
                            <div class="mt-2 mr-2" style="margin-right:10px; width: 200px;">
                                <select class="form-control" id="selectMonth">
                                    <option>--All--</option>
                                    <option>Kas Besar</option>
                                    <option>Bank BCA</option>
                                </select>
                            </div>
                            <a href="#" class="btn btn-info btn-sm mt-3 mr-2" style="width: 90px; margin-left:10px;">Show</a>
                            <input type="date" class="form-control flatpickr-range mt-2" placeholder="Select date.." style="margin-left:500px; width: 250px;">
                        </div>
                        <div class="mt-2 mr-2" style="margin-left:10px; width: 100px;">
                            <select class="form-control" id="selectMonth">
                                <option value="1">Januari</option>
                                <option value="2">Februari</option>
                                <option value="3">Maret</option>
                                <option value="4">April</option>
                                <option value="5">Mei</option>
                                <option value="6">Juni</option>
                                <option value="7">Juli</option>
                                <option value="8">Agustus</option>
                                <option value="9">September</option>
                                <option value="10">Oktober</option>
                                <option value="11">November</option>
                                <option value="12">Desember</option>
                            </select>
                        </div>
                        <div class="mt-2 mr-2" style="margin-left:10px; width: 100px;">
                            <select class="form-control" id="selectYear">
                                <option>2020</option>
                                <option>2021</option>
                                <option>2022</option>
                                <option>2023</option>
                                <option>2024</option>
                                <option>2025</option>
                                <option>2026</option>
                                <option>2027</option>
                                <option>2028</option>
                                <option>2029</option>
                                <option>2030</option>
                                <!-- Tambahkan pilihan tahun sesuai kebutuhan -->
                            </select>
                        </div>
                    </div>
                    <!-- table head dark -->
                    <div class="table-responsive" style="margin:20px" ;>
                        <table class="table table-bordered mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th style="text-align: center;">#</th>
                                    <th style="text-align: center;">Nomor</th>
                                    <th style="text-align: center;">Tanggal</th>
                                    <th style="text-align: center;">Kode Kas</th>
                                    <th style="text-align: center;">Nama Kas</th>
                                    <th style="text-align: center;">Debet</th>
                                    <th style="text-align: center;">Keterangan</th>
                                    <th style="text-align: center;">User</th>
                                </tr>
                            </thead>

                            <tbody class="text-center">
                                <tr>
                                    <td>1</td>
                                    <td>OCB/2024/07/11/3</td>
                                    <td>2024-07-11</td>
                                    <td>10011</td>
                                    <td>BANK BCA</td>
                                    <td>300,000</td>
                                    <td>1X OR HONDA BRIO H 1496 UQ/ ETIQA/ LIANAWATI</td>
                                    <td>Kocak</td>
                            </tbody>

                            <thead class="text-center">
                                <tr>
                                    <th colspan="5" style="text-align: right;">Total</th>
                                    <th>300,000</th>
                                    <th colspan="2;"></th>
                                </tr>
                            </thead>
                        </table>
                        <div class="card-body">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination pagination-primary">
                                    <li class="page-item"><a class="page-link" href="#">Prev</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Table head options end -->
<?= $this->endSection() ?>