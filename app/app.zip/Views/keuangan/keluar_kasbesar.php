<!-- File: app/Views/sparepart/permintaan_part.php -->
<?= $this->extend('layout/template'); ?>

<?= $this->section('content') ?>
<h3>Pengeluaran Kas Besar</h3>

<!-- Table Pre-order -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-content">
                        <div class="card-header d-flex align-items-center" style="width: fit-content;">
                            <h6 class="mt-3" style="margin-left: 15px;">Sortby</h6>
                            <input type="date" class="form-control flatpickr-range mt-2" placeholder="Select date.." style="margin-left:20px; width: 250px;">
                        </div>
                    </div>
                    <!-- table head dark -->
                    <div class="container" style="margin: 20px;">
                        <div class="row">
                            <!-- Tabel Jumlah Pengeluaran (col-4) -->
                            <div class="col-md-4">
                                <h5>Jumlah Pengeluaran</h5>
                                <table class="table table-bordered">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>Tanggal</th>
                                            <th>Jumlah</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>2024-07-01</td>
                                            <td>Rp. 1,000,000</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>2024-07-02</td>
                                            <td>Rp. 500,000</td>
                                            <td></td>
                                        </tr>
                                        <!-- Tambahkan data sesuai kebutuhan -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Tabel Rincian Pengeluaran Kas Besar (col-8) -->
                            <div class="col-md-8">
                                <h5>Rincian Pengeluaran Kas Besar</h5>
                                <table class="table table-bordered">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No</th>
                                            <th>Tanggal</th>
                                            <th>Account</th>
                                            <th>Keterangan</th>
                                            <th>Jumlah</th>
                                            <th>User</th>
                                            <th>Tanggal Input</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>2024-07-01</td>
                                            <td>Pembelian alat tulis</td>
                                            <td>Rp. 200,000</td>
                                            <td>John Doe</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <!-- button edit -->
                                                <button type="button" class="btn btn-primary btn-sm edit-user-btn"><i class="fas fa-edit"></i></button>
                                                <!-- button hapus -->
                                                <button type="button" class="btn btn-danger btn-sm delete-user-btn"><i class="fas fa-trash-alt"></i></button>
                                            </td>
                                        </tr>
                                        <!-- Tambahkan data sesuai kebutuhan -->
                                    </tbody>

                                    <thead>
                                        <tr>
                                            <th colspan="4" style="text-align: right;">Total</th>
                                            <th style="text-align: center;">Rp. 2,500,000</th>
                                            <th colspan="3"></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Table head options end -->
<?= $this->endSection() ?>