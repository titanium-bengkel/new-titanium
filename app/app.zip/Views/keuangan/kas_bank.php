<!-- File: app/Views/sparepart/permintaan_part.php -->
<?= $this->extend('layout/template'); ?>

<?= $this->section('content') ?>
<h3>Jurnal Kas & Bank</h3>

<!-- Table Pre-order -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-header d-flex align-items-center" style="width: fit-content;">
                        <div class="buttons d-flex align-items-center">
                            <button type="button" class="btn btn-secondary mt-3 mr-2" data-bs-toggle="modal" data-bs-target="#record">
                                New Record
                            </button>
                            <input type="text" id="helperText" class="form-control mt-2" placeholder="Nama Suplier" style="margin-right:10px; width: 150px;">
                            <a href="#" class="btn btn-info btn-sm mt-3 mr-2" style="width: 90px; margin-left:10px;">Show</a>
                            <input type="date" class="form-control flatpickr-range mt-2" placeholder="Select date.." style="margin-left:50px; width: 250px;">
                        </div>
                        <div class="mt-2 mr-2" style="margin-left:10px; width: 100px;">
                            <select class="form-control" id="selectMonth">
                                <option value="1">Januari</option>
                                <option value="2">Februari</option>
                                <option value="3">Maret</option>
                                <option value="4">April</option>
                                <option value="5">Mei</option>
                                <option value="6">Juni</option>
                                <option value="7">Juli</option>
                                <option value="8">Agustus</option>
                                <option value="9">September</option>
                                <option value="10">Oktober</option>
                                <option value="11">November</option>
                                <option value="12">Desember</option>
                            </select>
                        </div>
                        <div class="mt-2 mr-2" style="margin-left:10px; width: 100px;">
                            <select class="form-control" id="selectYear">
                                <option>2020</option>
                                <option>2021</option>
                                <option>2022</option>
                                <option>2023</option>
                                <option>2024</option>
                                <option>2025</option>
                                <option>2026</option>
                                <option>2027</option>
                                <option>2028</option>
                                <option>2029</option>
                                <option>2030</option>
                                <!-- Tambahkan pilihan tahun sesuai kebutuhan -->
                            </select>
                        </div>
                    </div>
                    <!-- table head dark -->
                    <div class="table-responsive" style="margin:20px" ;>
                        <table class="table table-bordered mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th style="text-align: center;">#</th>
                                    <th style="text-align: center;">Date</th>
                                    <th style="text-align: center;">No. Dokumen</th>
                                    <th style="text-align: center;">Account</th>
                                    <th style="text-align: center;">Name</th>
                                    <th style="text-align: center;">Deskripsi</th>
                                    <th style="text-align: center;">Debit</th>
                                    <th style="text-align: center;">Credit</th>
                                    <th style="text-align: center;">User</th>
                                    <th style="text-align: center;">Tanggal Input</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>

                            <tbody class="text-center">
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>5.000</td>
                                    <td>10.000</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                            </tbody>

                            <thead style="text-align: center;">
                                <th colspan="6" style="text-align: right;">Total</th>
                                <th>5.000</th>
                                <th>10.000</th>
                                <th colspan="3"></th>
                            </thead>
                        </table>
                        <div class="card-body">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination pagination-primary">
                                    <li class="page-item"><a class="page-link" href="#">Prev</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Table head options end -->


<!-- modal New Record-->
<div class="modal fade text-left" id="record" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-12">
                        <input type="date" id="tgl" class="form-control" name="tgl" onkeydown="return false" onclick="this.showPicker()">
                    </div>
                </div>
                <button type="button" class="btn btn-success btn-sm" id="add-row-btn"><i class="fas fa-plus"></i> Tambah Baris</button>
                <div class="table-responsive">
                    <table class="table table-bordered mt-2">
                        <thead>
                            <tr>
                                <th>Account Debet</th>
                                <th>keterangan</th>
                                <th>nilai</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="table-debet">
                            <tr>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="text" class="form-control"></td>
                                <td>
                                    <button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>
                                </td>
                            </tr>
                        </tbody>
                        <tbody class="table-credit">
                            <tr>
                                <td colspan="2">Account Credit</td>
                                <td><input type="text" class="form-control"></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Accept</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- End Modal -->


<!-- js tgl -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var today = new Date();
        var day = String(today.getDate()).padStart(2, '0');
        var month = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
        var year = today.getFullYear();
        var todayString = year + '-' + month + '-' + day;

        document.getElementById('tgl').value = todayString;
    });
</script>


<!-- Script untuk modal -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Menambahkan baris pada bagian Account Debet
        $('#record').on('click', '#add-row-btn', function() {
            var row = '<tr>' +
                '<td><input type="text" class="form-control"></td>' +
                '<td><input type="text" class="form-control"></td>' +
                '<td><input type="text" class="form-control"></td>' +
                '<td>' +
                '<button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>' +
                '</td>' +
                '</tr>';
            $(this).closest('.modal-content').find('.table-debet').append(row); // Memilih tbody di dalam bagian Account Debet
            updateRemoveButtonStatus();
        });

        // Menghapus baris
        $('#record').on('click', '.remove-row', function() {
            $(this).closest('tr').remove();
            updateRemoveButtonStatus();
        });

        // Fungsi untuk mengatur status tombol kurangi
        function updateRemoveButtonStatus() {
            var rowCount = $('#record').find('.table-debet tr').length;
            if (rowCount === 1) {
                $('#record').find('.table-debet .remove-row').prop('disabled', true); // Menonaktifkan tombol jika hanya ada satu baris
            } else {
                $('#record').find('.table-debet .remove-row').prop('disabled', false); // Mengaktifkan tombol jika lebih dari satu baris
            }
        }

        // Memastikan status tombol saat halaman dimuat
        updateRemoveButtonStatus();
    });
</script>





<?= $this->endSection() ?>