<?= $this->extend('layout/template'); ?>

<?= $this->section('content') ?>
<h3>Kas Kecil</h3>

<!-- Table Pre-order -->
<section class="section">
    <div class="row" id="table-head">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-header d-flex align-items-center" style="width: fit-content;">
                        <h6 class="mt-3" style="margin-left: 15px;">Sortby</h6>
                        <input type="date" class="form-control flatpickr-range mt-2" placeholder="Select date.." style="margin-left:20px; width: 250px;">
                    </div>
                </div>
                <!-- table head dark -->
                <div class="row" style="margin: 20px;">
                    <!-- Tabel Jumlah Pengeluaran (col-4) -->
                    <div class="col-md-4">
                        <h3>Jumlah Pengeluaran</h3>
                        <table class="table table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Jumlah</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td data-target="#pertgl"><a href="#" data-bs-toggle="modal" data-target="#pertgl">2024-07-01</a></td>
                                    <td>Rp. 1,000,000</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>2024-07-02</td>
                                    <td>Rp. 500,000</td>
                                    <td></td>
                                </tr>
                                <!-- Tambahkan data sesuai kebutuhan -->
                            </tbody>
                        </table>
                    </div>
                    <!-- Tabel Rincian Kas Kecil (col-8) -->
                    <div class="col-md-8">
                        <h3>Rincian Kas Kecil</h3>
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. 2024-07-01 - Pembelian alat tulis
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <table class="table table-bordered">
                                            <thead class="thead-dark">
                                                <tr>
                                                    <th>No</th>
                                                    <th>Tanggal</th>
                                                    <th>Account</th>
                                                    <th>Keterangan</th>
                                                    <th>Debit</th>
                                                    <th>Kredit</th>
                                                    <th>User</th>
                                                    <th>Tanggal Input</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>2024-07-01</td>
                                                    <td>Pembelian alat tulis</td>
                                                    <td>Rp. 200,000</td>
                                                    <td>A kasian a</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td>
                                                        <!-- button edit -->
                                                        <button type="button" class="btn btn-primary btn-sm edit-user-btn"><i class="fas fa-edit"></i></button>
                                                        <!-- button hapus -->
                                                        <button type="button" class="btn btn-danger btn-sm delete-user-btn"><i class="fas fa-trash-alt"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>1</td>
                                                    <td>2024-07-01</td>
                                                    <td>Pembelian alat tulis</td>
                                                    <td>Rp. 200,000</td>
                                                    <td>A kasian a</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td>
                                                        <!-- button edit -->
                                                        <button type="button" class="btn btn-primary btn-sm edit-user-btn"><i class="fas fa-edit"></i></button>
                                                        <!-- button hapus -->
                                                        <button type="button" class="btn btn-danger btn-sm delete-user-btn"><i class="fas fa-trash-alt"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>1</td>
                                                    <td>2024-07-01</td>
                                                    <td>Pembelian alat tulis</td>
                                                    <td>Rp. 200,000</td>
                                                    <td>A kasian a</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td>
                                                        <!-- button edit -->
                                                        <button type="button" class="btn btn-primary btn-sm edit-user-btn"><i class="fas fa-edit"></i></button>
                                                        <!-- button hapus -->
                                                        <button type="button" class="btn btn-danger btn-sm delete-user-btn"><i class="fas fa-trash-alt"></i></button>
                                                    </td>
                                                </tr>
                                                <!-- Tambahkan data sesuai kebutuhan -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseOne">
                                        2. 2024-07-01 - Pembelian alat tulis
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <table class="table table-bordered">
                                            <thead class="thead-dark">
                                                <tr>
                                                    <th>No</th>
                                                    <th>Tanggal</th>
                                                    <th>Account</th>
                                                    <th>Keterangan</th>
                                                    <th>Debit</th>
                                                    <th>Kredit</th>
                                                    <th>User</th>
                                                    <th>Tanggal Input</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>2024-07-01</td>
                                                    <td>Pembelian alat tulis</td>
                                                    <td>Rp. 200,000</td>
                                                    <td>A kasian a</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td>
                                                        <!-- button edit -->
                                                        <button type="button" class="btn btn-primary btn-sm edit-user-btn"><i class="fas fa-edit"></i></button>
                                                        <!-- button hapus -->
                                                        <button type="button" class="btn btn-danger btn-sm delete-user-btn"><i class="fas fa-trash-alt"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>1</td>
                                                    <td>2024-07-01</td>
                                                    <td>Pembelian alat tulis</td>
                                                    <td>Rp. 200,000</td>
                                                    <td>A kasian a</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td>
                                                        <!-- button edit -->
                                                        <button type="button" class="btn btn-primary btn-sm edit-user-btn"><i class="fas fa-edit"></i></button>
                                                        <!-- button hapus -->
                                                        <button type="button" class="btn btn-danger btn-sm delete-user-btn"><i class="fas fa-trash-alt"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>1</td>
                                                    <td>2024-07-01</td>
                                                    <td>Pembelian alat tulis</td>
                                                    <td>Rp. 200,000</td>
                                                    <td>A kasian a</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td>
                                                        <!-- button edit -->
                                                        <button type="button" class="btn btn-primary btn-sm edit-user-btn"><i class="fas fa-edit"></i></button>
                                                        <!-- button hapus -->
                                                        <button type="button" class="btn btn-danger btn-sm delete-user-btn"><i class="fas fa-trash-alt"></i></button>
                                                    </td>
                                                </tr>
                                                <!-- Tambahkan data sesuai kebutuhan -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
<!-- Table head options end -->


<!-- modal input tgl-->
<div class="modal fade" id="pertgl" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close rounded-pill" data-bs-dismiss="modal" aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-12">
                        <input type="date" id="tgl" class="form-control" name="tgl" onkeydown="return false" onclick="this.showPicker()">
                    </div>
                </div>
                <button type="button" class="btn btn-success btn-sm" id="add-row-btn"><i class="fas fa-plus"></i> Tambah Baris</button>
                <div class="table-responsive">
                    <table class="table table-bordered mt-2">
                        <thead>
                            <tr>
                                <th>Account Debet</th>
                                <th>keterangan</th>
                                <th>nilai</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="table-debet">
                            <tr>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="text" class="form-control"></td>
                                <td>
                                    <button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>
                                </td>
                            </tr>
                        </tbody>
                        <tbody class="table-credit">
                            <tr>
                                <td colspan="2">Account Credit</td>
                                <td><input type="text" class="form-control"></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="button" class="btn btn-primary ms-1" data-bs-dismiss="modal">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Accept</span>
                </button>
            </div>
        </div>
    </div>
</div>



<!-- JavaScript to handle click and show modal -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tableClickable = document.querySelectorAll('.table-clickable');

    tableClickable.forEach(function(cell) {
        cell.addEventListener('click', function() {
            const targetModal = this.getAttribute('data-target');
            const modal = new bootstrap.Modal(document.querySelector(targetModal));
            modal.show();
        });
    });
});
</script>



<!-- Script untuk modal -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Menambahkan baris pada bagian Account Debet
        $('#record').on('click', '#add-row-btn', function() {
            var row = '<tr>' +
                '<td><input type="text" class="form-control"></td>' +
                '<td><input type="text" class="form-control"></td>' +
                '<td><input type="text" class="form-control"></td>' +
                '<td>' +
                '<button type="button" class="btn btn-danger btn-sm remove-row"><i class="fas fa-minus"></i></button>' +
                '</td>' +
                '</tr>';
            $(this).closest('.modal-content').find('.table-debet').append(row); // Memilih tbody di dalam bagian Account Debet
            updateRemoveButtonStatus();
        });

        // Menghapus baris
        $('#record').on('click', '.remove-row', function() {
            $(this).closest('tr').remove();
            updateRemoveButtonStatus();
        });

        // Fungsi untuk mengatur status tombol kurangi
        function updateRemoveButtonStatus() {
            var rowCount = $('#record').find('.table-debet tr').length;
            if (rowCount === 1) {
                $('#record').find('.table-debet .remove-row').prop('disabled', true); // Menonaktifkan tombol jika hanya ada satu baris
            } else {
                $('#record').find('.table-debet .remove-row').prop('disabled', false); // Mengaktifkan tombol jika lebih dari satu baris
            }
        }

        // Memastikan status tombol saat halaman dimuat
        updateRemoveButtonStatus();
    });
</script>


<!-- End Modal -->
<?= $this->endSection() ?>