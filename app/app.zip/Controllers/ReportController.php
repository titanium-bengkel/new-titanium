<?php

namespace App\Controllers;

class ReportController extends BaseController
{
    public function jurnal_keuangan()
    {
        $data = [
            'title' => 'Report',
        ];
        return view('report/report_jurnal', $data);
    }

    public function bukubesar_generalledger()
    {
        $data = [
            'title' => 'Report',
        ];
        return view('report/buku_besar', $data);
    }

    public function laporan_labarugi()
    {
        $data = [
            'title' => 'Report',
        ];
        return view('report/laba_rugi', $data);
    }

    public function laporan_neraca()
    {
        $data = [
            'title' => 'Report',
        ];
        return view('report/neraca', $data);
    }
}
