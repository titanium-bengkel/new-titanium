<?php

namespace App\Controllers;

use App\Models\M_Po;
use App\Models\M_Kendaraan;
use App\Models\M_JenisMobil;
use App\Models\M_Warna;
use App\Models\M_PengerjaanPo;
use App\Models\M_SparepartPo;
use App\Models\M_GambarPo;
use App\Models\M_AccAsuransi;
use CodeIgniter\Controller;


class KlaimController extends BaseController
{

    public function preorder()
    {
        $poModel = new M_Po();
        $poData = $poModel->getPoWithUsername();
        $accData = $poModel->getPoWithAccAsuransi();

        foreach ($poData as &$po_item) {
            foreach ($accData as $acc_item) {
                if ($po_item['id_terima_po'] === $acc_item['id_terima_po']) {
                    $po_item['tgl_acc'] = $acc_item['tgl_acc'];
                    $po_item['harga_acc'] = $acc_item['harga_acc'];
                    break;
                }
            }
        }

        $preOrderId = $poModel->generateIdTerimaPo();
        $idPo = $poModel->generateIdPo();

        $data = [
            'title' => 'Pre Order',
            'preOrderId' => $preOrderId,
            'idPo' => $idPo,
            'po' => $poData,
        ];

        return view('klaim/preorder', $data);
    }

    public function input_order()
    {
        $poModel = new M_Po();
        $kendaraanModel = new M_Kendaraan();
        $jenisMobilModel = new M_JenisMobil();
        $warnaModel = new M_Warna();
        $pengerjaanModel = new M_PengerjaanPo(); // Tambahkan model ini

        $preOrderId = $poModel->generateIdTerimaPo();
        $newPoId = $poModel->generateIdPo();

        // Fetch data
        $asuransiData = $poModel->getAllAsuransi();
        $kendaraanData = $kendaraanModel->getAllKendaraan(); // Menggunakan method model untuk mendapatkan data
        $jenisMobilData = $jenisMobilModel->findAll();
        $warnaData = $warnaModel->findAll();
        $pengerjaanData = $pengerjaanModel->getAllPengerjaan(); // Ambil data pengerjaan

        $data = [
            'title' => 'Input Order',
            'preOrderId' => $preOrderId,
            'idPo' => $newPoId,
            'asuransi' => $asuransiData,
            'kendaraan' => $kendaraanData,
            'jenis_mobil' => $jenisMobilData,
            'warna' => $warnaData,
            'pengerjaan' => $pengerjaanData // Tambahkan data ini
        ];

        return view('klaim/order_pos', $data);
    }


    public function input_order_posprev($id_terima_po)
    {
        // Load models
        $poModel = new M_Po();
        $kendaraanModel = new M_Kendaraan();
        $jenisMobilModel = new M_JenisMobil();
        $warnaModel = new M_Warna();
        $pengerjaanModel = new M_PengerjaanPo();
        $sparepartsModel = new M_SparepartPo();
        $gambarModel = new M_GambarPo();

        // Ambil data PO berdasarkan ID
        $poData = $poModel->where('id_terima_po', $id_terima_po)->first();

        if (!$poData) {
            return redirect()->to('/')->with('error', 'Data PO tidak ditemukan');
        }

        // Ambil data pengerjaan berdasarkan id_terima_po
        $pengerjaanList = $pengerjaanModel->getPengerjaanByIdTerimaPo($id_terima_po);

        // Fetch related data
        $asuransiData = $poModel->getAllAsuransi();
        $kendaraanData = $kendaraanModel->findAll();
        $jenisMobilData = $jenisMobilModel->findAll();
        $warnaData = $warnaModel->findAll();
        $pengerjaan = $pengerjaanModel->getAllPengerjaan();
        $spareparts = $sparepartsModel->getAllSparepartPo();
        $daftarPengerjaan = $pengerjaanModel->getPengerjaanByIdTerimaPo($id_terima_po);
        $daftarSparepart = $sparepartsModel->getSparepartByIdTerimaPo($id_terima_po);
        $gambarData = $gambarModel->getGambarByIdTerimaPo($id_terima_po);
        $hargaEstimasi = $poModel->getHargaEstimasi($id_terima_po);

        $data = [
            'title' => 'Edit Order',
            'po' => $poData,
            'asuransi' => $asuransiData,
            'kendaraan' => $kendaraanData,
            'jenis_mobil' => $jenisMobilData,
            'warna' => $warnaData,
            'id_terima_po' => $id_terima_po,
            'pengerjaanList' => $pengerjaanList,
            'pengerjaan' => $pengerjaan,
            'spareparts' => $spareparts,
            'daftarPengerjaan' => $daftarPengerjaan,
            'daftarSparepart' => $daftarSparepart,
            'gambarData' => $gambarData,
            'hargaEstimasi' => $hargaEstimasi ? $hargaEstimasi->total_biaya : 0 // Pastikan nilai ada atau beri nilai default
        ];

        return view('klaim/order_posprev', $data);
    }


    public function createPO()
    {
        $user_id = session()->get('user_id');
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID tidak ditemukan dalam sesi');
        }

        $poModel = new M_Po();
        $kendaraanModel = new M_Kendaraan();
        $jenisMobilModel = new M_JenisMobil();
        $warnaModel = new M_Warna();

        // Generate new IDs
        $newPoId = $poModel->generateIdPo();
        $newIdTerimaPo = $poModel->generateIdTerimaPo();

        // Ambil data dari form
        $progres = $this->request->getPost('progres');

        // Pastikan $progres ada dan valid
        if (!$progres) {
            log_message('error', 'Progres tidak ditemukan dalam data POST.');
            return redirect()->back()->with('error', 'Progres tidak dipilih.');
        }

        $data = [
            'id_po' => $newPoId,
            'id_terima_po' => $newIdTerimaPo,
            'no_kendaraan' => $this->request->getPost('no-kendaraan'),
            'jenis_mobil' => $this->request->getPost('jenis-mobil'),
            'warna' => $this->request->getPost('warna'),
            'no_polis' => $this->request->getPost('no-polis'),
            'no_rangka' => $this->request->getPost('no-rangka'),
            'tahun_kendaraan' => $this->request->getPost('tahun-kendaraan'),
            'no_contact' => $this->request->getPost('no-contact'),
            'customer_name' => $this->request->getPost('customer-name'),
            'alamat' => $this->request->getPost('alamat'),
            'kota' => $this->request->getPost('kota'),
            'asuransi' => $this->request->getPost('asuransi'),
            'tgl_klaim' => $this->request->getPost('tanggal-masuk'),
            'harga_estimasi' => $this->request->getPost('harga-estimasi'),
            'keterangan' => $this->request->getPost('keterangan'),
            'status' => 'Pre-Order',
            'progres' => $progres, // Simpan progres yang dipilih
            'user_id' => $user_id
        ];

        // Debug data
        log_message('debug', 'Data yang dikirim ke database: ' . print_r($data, true));

        // Simpan data ke database
        $no_kendaraan = $this->request->getPost('no-kendaraan');
        $customer_name = $this->request->getPost('customer-name');
        $no_contact = $this->request->getPost('no-contact');

        // Periksa dan masukkan ke tabel kendaraan jika belum ada
        if (!$kendaraanModel->where('no_kendaraan', $no_kendaraan)->first()) {
            $kendaraanData = [
                'no_kendaraan' => $no_kendaraan,
                'customer_name' => $customer_name,
                'no_contact' => $no_contact
            ];
            $kendaraanModel->insert($kendaraanData);
        }

        // Periksa dan masukkan ke tabel jenis_mobil jika belum ada
        $jenis_mobil = $this->request->getPost('jenis-mobil');
        if (!$jenisMobilModel->where('jenis_mobil', $jenis_mobil)->first()) {
            $jenisMobilModel->insert(['jenis_mobil' => $jenis_mobil]);
        }

        // Periksa dan masukkan ke tabel warna jika belum ada
        $warna = $this->request->getPost('warna');
        if (!$warnaModel->where('warna', $warna)->first()) {
            $warnaModel->insert(['warna' => $warna]);
        }

        // Simpan data PO
        if (!$poModel->createPo($data)) {
            $errors = $poModel->errors();
            log_message('error', 'Gagal menyimpan data PO: ' . print_r($errors, true));
            return redirect()->back()->with('error', 'Gagal menyimpan data PO.');
        }

        // Jika berhasil
        return redirect()->to(base_url('/order_posprev/' . $newIdTerimaPo))->with('success', 'Data PO berhasil disimpan.');
    }
    public function updatePO($id_terima_po)
    {
        $user_id = session()->get('user_id');
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID tidak ditemukan dalam sesi');
        }

        $poModel = new M_Po();
        $kendaraanModel = new M_Kendaraan();
        $jenisMobilModel = new M_JenisMobil();
        $warnaModel = new M_Warna();

        // Ambil data PO yang ingin di-update berdasarkan id_terima_po
        $existingPO = $poModel->where('id_terima_po', $id_terima_po)->first();
        if (!$existingPO) {
            return redirect()->to('/preorder')->with('error', 'Data PO tidak ditemukan.');
        }

        // Ambil data dari form
        $status_order = $this->request->getPost('status_order');
        $no_kendaraan = $this->request->getPost('no_kendaraan');
        $progres = $this->request->getPost('progres');
        $harga_estimasi = $this->request->getPost('harga_estimasi');

        // Validasi input
        if (empty($no_kendaraan)) {
            log_message('error', 'no_kendaraan tidak diisi.');
            return redirect()->back()->with('error', 'No kendaraan harus diisi.');
        }

        if (!$status_order) {
            log_message('error', 'Status Order tidak ditemukan dalam data POST.');
            return redirect()->back()->with('error', 'Status Order tidak dipilih.');
        }

        // Hapus format angka dari harga_estimasi
        $harga_estimasi = str_replace(['.', ','], ['', '.'], $harga_estimasi);

        $data = [
            'no_kendaraan' => $no_kendaraan,
            'jenis_mobil' => $this->request->getPost('jenis_mobil'),
            'warna' => $this->request->getPost('warna'),
            'no_polis' => $this->request->getPost('no_polis'),
            'no_rangka' => $this->request->getPost('no_rangka'),
            'tahun_kendaraan' => $this->request->getPost('tahun_kendaraan'),
            'no_contact' => $this->request->getPost('no_contact'),
            'customer_name' => $this->request->getPost('customer_name'),
            'alamat' => $this->request->getPost('alamat'),
            'kota' => $this->request->getPost('kota'),
            'asuransi' => $this->request->getPost('asuransi'),
            'tgl_klaim' => $this->request->getPost('tanggal_masuk'),
            'harga_estimasi' => $harga_estimasi, // Nilai yang sudah diformat
            'keterangan' => $this->request->getPost('keterangan'),
            'status' => $status_order,
            'progres' => $progres,
            'user_id' => $user_id
        ];

        // Debug data
        log_message('debug', 'Data yang dikirim ke database: ' . print_r($data, true));

        // Periksa dan masukkan ke tabel kendaraan jika belum ada
        if (!$kendaraanModel->where('no_kendaraan', $no_kendaraan)->first()) {
            $kendaraanData = [
                'no_kendaraan' => $no_kendaraan,
                'customer_name' => $this->request->getPost('customer_name'),
                'no_contact' => $this->request->getPost('no_contact')
            ];
            $kendaraanModel->insert($kendaraanData);
        }

        // Periksa dan masukkan ke tabel jenis_mobil jika belum ada
        $jenis_mobil = $this->request->getPost('jenis_mobil');
        if (!$jenisMobilModel->where('jenis_mobil', $jenis_mobil)->first()) {
            $jenisMobilModel->insert(['jenis_mobil' => $jenis_mobil]);
        }

        // Periksa dan masukkan ke tabel warna jika belum ada
        $warna = $this->request->getPost('warna');
        if (!$warnaModel->where('warna', $warna)->first()) {
            $warnaModel->insert(['warna' => $warna]);
        }

        // Update data PO
        if (!$poModel->updateData($id_terima_po, $data)) {
            return redirect()->back()->with('error', 'Gagal memperbarui data PO.');
        }

        // Jika berhasil
        return redirect()->to('/preorder')->with('success', 'Data Pre Order berhasil diperbarui.');
    }


    public function createPengerjaanPo()
    {
        $user_id = session()->get('user_id');
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID tidak ditemukan di session');
        }

        // Mengambil nilai id_terima_po dari form input
        $id_terima_po = $this->request->getPost('id_terima_po');
        if (!$id_terima_po) {
            return redirect()->back()->with('error', 'ID Terima PO tidak ditemukan.');
        }

        // Inisialisasi model M_Po dan M_PengerjaanPo
        $poModel = new M_Po();
        $pengerjaanPoModel = new M_PengerjaanPo();

        // Mengambil data PO berdasarkan id_terima_po
        $poData = $poModel->where('id_terima_po', $id_terima_po)->first();
        if (!$poData) {
            return redirect()->back()->with('error', 'Data PO tidak ditemukan.');
        }

        // Mengumpulkan data dari form
        $data = [
            'kode_pengerjaan' => $this->request->getPost('kodePengerjaan'),
            'nama_pengerjaan' => $this->request->getPost('pengerjaan'),
            'harga' => $this->request->getPost('harga'),
            'id_terima_po' => $id_terima_po
        ];

        // Debug data yang akan disimpan
        log_message('debug', 'Data yang akan disimpan ke tabel pengerjaan_po: ' . print_r($data, true));

        // Insert data ke dalam tabel pengerjaan_po
        try {
            $pengerjaanPoModel->insert($data);

            // Hitung total harga pengerjaan untuk id_terima_po ini
            $pengerjaanList = $pengerjaanPoModel->where('id_terima_po', $id_terima_po)->findAll();
            $totalHarga = array_reduce($pengerjaanList, function ($carry, $item) {
                return $carry + $item['harga'];
            }, 0);

            // Debug total harga
            log_message('debug', 'Total harga pengerjaan untuk id_terima_po ' . $id_terima_po . ': ' . $totalHarga);

            // Update total_harga di tabel pengerjaan_po
            $pengerjaanPoModel->where('id_terima_po', $id_terima_po)->set(['total_harga' => $totalHarga])->update();

            // Update biaya_pengerjaan di tabel po
            $poModel->where('id_terima_po', $id_terima_po)->set(['biaya_pengerjaan' => $totalHarga])->update();

            return redirect()->to(base_url('/order_posprev/' . $id_terima_po))->with('success', 'Pengerjaan berhasil ditambahkan.');
        } catch (\Exception $e) {
            log_message('error', 'Error saat menyimpan data pengerjaan: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Error: ' . $e->getMessage());
        }
    }


    public function createSparepartPo()
    {
        // Mendapatkan user_id dari sesi
        $user_id = session()->get('user_id');
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID tidak ditemukan di session');
        }

        // Mengambil nilai id_terima_po dan kodePengerjaan dari form input
        $id_terima_po = $this->request->getPost('id_terima_po');
        $kodePengerjaan = $this->request->getPost('kodePengerjaan');

        // Pastikan ID Terima PO yang diterima adalah valid
        if (!$id_terima_po) {
            return redirect()->back()->with('error', 'ID Terima PO tidak ditemukan.');
        }

        // Inisialisasi model M_SparepartPo dan M_Po
        $sparepartPoModel = new M_SparepartPo();
        $poModel = new M_Po();

        // Mengumpulkan data dari form
        $qty = $this->request->getPost('sparepart'); // Pastikan ini sesuai dengan nama input field
        $harga = $this->request->getPost('hargaSparepart');

        // Validasi qty dan harga
        if (!is_numeric($qty) || $qty <= 0) {
            return redirect()->back()->with('error', 'Qty harus berupa angka yang lebih besar dari 0.');
        }
        if (!is_numeric($harga) || $harga < 0) {
            return redirect()->back()->with('error', 'Harga harus berupa angka yang lebih besar dari atau sama dengan 0.');
        }

        // Hitung total harga
        $total_harga = $qty * $harga;

        // Mengumpulkan data dari form
        $data = [
            'id_terima_po'       => $id_terima_po,
            'kode_sparepart'     => $this->request->getPost('kodeSparepart'),
            'nama_sparepart'     => $this->request->getPost('sparepartNama'),
            'qty'                => $qty,
            'harga'              => $harga,
            'total_qty'          => $qty,
            'total_harga'        => $total_harga,
            'kode_pengerjaan'    => $kodePengerjaan,
            'jenis_part'         => $this->request->getPost('jenisPart')
        ];

        // Debug data yang akan disimpan
        log_message('debug', 'Data yang akan disimpan ke tabel sparepart_po: ' . print_r($data, true));

        // Insert data ke dalam tabel sparepart_po
        try {
            $sparepartPoModel->insert($data);

            // Hitung total biaya sparepart untuk id_terima_po ini
            $sparepartList = $sparepartPoModel->where('id_terima_po', $id_terima_po)->findAll();
            $totalBiayaSparepart = array_reduce($sparepartList, function ($carry, $item) {
                return $carry + $item['total_harga'];
            }, 0);

            // Debug total biaya sparepart
            log_message('debug', 'Total biaya sparepart untuk id_terima_po ' . $id_terima_po . ': ' . $totalBiayaSparepart);

            // Update biaya_sparepart di tabel po
            $poModel->where('id_terima_po', $id_terima_po)->set(['biaya_sparepart' => $totalBiayaSparepart])->update();

            return redirect()->to(base_url('/order_posprev/' . $id_terima_po))->with('success', 'Data sparepart berhasil ditambahkan.');
        } catch (\Exception $e) {
            log_message('error', 'Error saat menyimpan data sparepart: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Error: ' . $e->getMessage());
        }
    }




    public function createGambarPo()
    {
        $user_id = session()->get('user_id');
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID tidak ditemukan di session');
        }

        // Mengambil nilai id_terima_po dari form input
        $id_terima_po = $this->request->getPost('id_terima_po');

        // Pastikan ID Terima PO yang diterima adalah valid
        if (!$id_terima_po) {
            return redirect()->back()->with('error', 'ID Terima PO tidak ditemukan.');
        }

        // Inisialisasi model M_GambarPo
        $gambarPoModel = new M_GambarPo();

        // Mendapatkan data dari form
        $keterangan = $this->request->getPost('keterangan');
        $deskripsi = $this->request->getPost('deskripsi');
        $gambarFiles = $this->request->getFiles();

        // Daftar ekstensi file yang diizinkan
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'svg'];

        // Validasi input gambar
        if (!isset($gambarFiles['gambar']) || !is_array($gambarFiles['gambar'])) {
            return redirect()->back()->with('error', 'Tidak ada file gambar yang diunggah.');
        }

        $gambarArray = $gambarFiles['gambar'];

        // Loop untuk menyimpan setiap gambar
        foreach ($keterangan as $key => $value) {
            if (isset($gambarArray[$key])) {
                $gambarFile = $gambarArray[$key];

                if ($gambarFile->isValid() && !$gambarFile->hasMoved()) {
                    // Cek ekstensi file
                    $fileExtension = $gambarFile->getClientExtension();
                    if (!in_array($fileExtension, $allowedExtensions)) {
                        return redirect()->back()->with('error', 'Jenis file tidak diizinkan. Hanya file dengan ekstensi jpg, jpeg, png, atau svg yang diperbolehkan.');
                    }

                    // Simpan file gambar
                    $gambarName = $gambarFile->getRandomName();
                    $gambarFile->move(FCPATH . 'uploads', $gambarName); // Menyimpan ke public/uploads

                    // Mengumpulkan data untuk disimpan
                    $data = [
                        'id_terima_po' => $id_terima_po,
                        'keterangan' => $value,
                        'deskripsi' => $deskripsi[$key],
                        'gambar' => $gambarName
                    ];

                    // Debug data yang akan disimpan
                    log_message('debug', 'Data yang akan disimpan ke tabel gambar_po: ' . print_r($data, true));

                    // Insert data ke dalam tabel gambar_po
                    try {
                        $gambarPoModel->insert($data);
                    } catch (\Exception $e) {
                        return redirect()->back()->with('error', 'Error: ' . $e->getMessage());
                    }
                } else {
                    return redirect()->back()->with('error', 'File gambar tidak valid.');
                }
            } else {
                return redirect()->back()->with('error', 'Gambar tidak ditemukan untuk keterangan index ' . $key);
            }
        }

        return redirect()->to(base_url('/order_posprev/' . $id_terima_po))->with('success', 'Gambar berhasil diunggah.');
    }
    public function createAccAsuransi()
    {
        $user_id = session()->get('user_id');
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID tidak ditemukan di session');
        }

        // Inisialisasi model
        $model = new M_AccAsuransi();
        $poModel = new M_Po(); // Model untuk tabel PO

        // Mengambil nilai id_terima_po dari form input
        $id_terima_po = $this->request->getPost('id_terima_po');
        $generatedId = $model->generateId();

        // Pastikan ID Terima PO yang diterima adalah valid
        if (!$id_terima_po) {
            return redirect()->back()->with('error', 'ID Terima PO tidak ditemukan.');
        }

        // Ambil data dari form
        $data = [
            'id_acc_asuransi' => $generatedId,
            'id_terima_po' => $id_terima_po,
            'tgl_acc' => $this->request->getPost('tgl_acc'),
            'no_kendaraan' => $this->request->getPost('no_kendaraan'),
            'jenis_mobil' => $this->request->getPost('jenis_mobil'),
            'warna' => $this->request->getPost('warna'),
            'customer_name' => $this->request->getPost('customer_name'),
            'no_contact' => $this->request->getPost('no_contact'),
            'tahun_kendaraan' => $this->request->getPost('tahun_mobil'),
            'asuransi' => $this->request->getPost('asuransi'),
            'tgl_masuk' => $this->request->getPost('tgl_masuk'),
            'tgl_estimasi' => $this->request->getPost('tgl_estimasi'),
            'biaya_jasa' => $this->request->getPost('jasa'),
            'biaya_sparepart' => $this->request->getPost('sparepart'),
            'biaya_total' => $this->request->getPost('nilai_total'),
            'nilai_or' => $this->request->getPost('nilai_or'),
            'qty_or' => $this->request->getPost('qty_or'),
            'keterangan' => $this->request->getPost('keterangan'),
            'user_id' => $user_id
        ];

        // Proses upload file jika ada
        if ($fotoSpk = $this->request->getFile('file_lampiran')) {
            if ($fotoSpk->isValid() && !$fotoSpk->hasMoved()) {
                $fileName = $fotoSpk->getRandomName();
                $fotoSpk->move(WRITEPATH . 'uploads', $fileName);
                $data['file_lampiran'] = $fileName;
            }
        }

        // Simpan data ke database
        if ($model->saveAccAsuransi($data)) {
            // Debugging: Cek apakah ID benar
            log_message('debug', 'ID Terima PO: ' . $id_terima_po);

            // Update status di tabel PO
            if ($poModel->updateData($id_terima_po, ['status' => 'Acc Asuransi'])) {
                log_message('debug', 'Status updated to Acc Asuransi for ID: ' . $id_terima_po);
                return redirect()->to('preorder')->with('success', 'Asuransi Berhasil Di Approve.');
            } else {
                log_message('error', 'Failed to update status for ID: ' . $id_terima_po);
                return redirect()->back()->with('error', 'Gagal mengupdate status di tabel PO.');
            }
        } else {
            log_message('error', 'Failed to save data asuransi.');
            return redirect()->back()->with('error', 'Gagal menyimpan data asuransi.');
        }
    }


    public function deletePengerjaan($kode_pengerjaan)
    {
        $pengerjaanPoModel = new M_PengerjaanPo();

        // Ambil data pengerjaan berdasarkan kode_pengerjaan
        $pengerjaanData = $pengerjaanPoModel->where('kode_pengerjaan', $kode_pengerjaan)->first();

        if (!$pengerjaanData) {
            return redirect()->back()->with('error', 'Data pengerjaan tidak ditemukan.');
        }

        // Simpan id_terima_po sebelum menghapus
        $id_terima_po = $pengerjaanData['id_terima_po'];

        // Hapus data pengerjaan
        try {
            $pengerjaanPoModel->where('kode_pengerjaan', $kode_pengerjaan)->delete();

            // Hitung total harga pengerjaan untuk id_terima_po ini
            $pengerjaanList = $pengerjaanPoModel->where('id_terima_po', $id_terima_po)->findAll();
            $totalHarga = array_reduce($pengerjaanList, function ($carry, $item) {
                return $carry + $item['harga'];
            }, 0);

            // Update total harga di tabel pengerjaan_po
            $pengerjaanPoModel->update($id_terima_po, ['total_harga' => $totalHarga]);

            return redirect()->back()->with('success', 'Data pengerjaan berhasil dihapus.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Error: ' . $e->getMessage());
        }
    }
    public function orderlist_asuransi()
    {
        $user_id = session()->get('user_id');

        $accAsuransiModel = new M_AccAsuransi();

        // Menggunakan metode untuk mengambil semua data acc dengan username
        $accData = $accAsuransiModel->getAccAsuransiWithUser();

        $data = [
            'title' => 'List Asuransi',
            'accData' => $accData,
        ];

        return view('klaim/orderlist_asuransi', $data);
    }


    public function prev_as()
    {
        $data = [
            'title' => 'Asuransi',
        ];
        return view('klaim/order_post_asprev', $data);
    }

    public function repair_order()
    {
        $data = [
            'title' => 'Repair Order',
        ];
        return view('klaim/repair_order', $data);
    }

    public function orderlist_pending()
    {
        $data = [
            'title' => 'Pending Invoice',
        ];
        return view('klaim/orderlist_pending', $data);
    }

    public function kwitansi()
    {
        $data = [
            'title' => 'Kwitansi',
        ];
        return view('klaim/kwitansi', $data);
    }

    public function kwitansi_piutang()
    {
        $data = [
            'title' => 'Piutang List',
        ];
        return view('klaim/kwitansi_piutang', $data);
    }

    public function bayar_piutang()
    {
        $data = [
            'title' => 'Bayar Piutang',
        ];
        return view('klaim/bayar_piutang', $data);
    }

    public function invoice_or()
    {
        $data = [
            'title' => 'Cetak Kwitansi OR',
        ];
        return view('klaim/invoice_or', $data);
    }

    // add di asuransi
    public function input_od_asuransi()
    {
        $data = [
            'title' => 'Asuransi',
        ];
        return view('klaim/order_pos_as', $data);
    }

    // add di repair order
    public function input_repair()
    {
        $data = [
            'title' => 'Repair Order',
        ];
        return view('klaim/order_repair', $data);
    }

    // add di kwitansi
    public function add_invoice()
    {
        $data = [
            'title' => 'Add Invoice',
        ];
        return view('klaim/add_invo', $data);
    }

    public function add_invoice_prev()
    {
        $data = [
            'title' => 'Add Invoice',
        ];
        return view('klaim/add_invoprev', $data);
    }

    // order pos pending
    public function order_pos_pending()
    {
        $data = [
            'title' => 'Pending Invoice',
        ];
        return view('klaim/order_pospending', $data);
    }

    // kwitansi pending preview
    public function kwitansi_pending_preview()
    {
        $data = [
            'title' => 'Kwitansi Pending Preview',
        ];
        return view('klaim/kwitansi_piutangprev', $data);
    }

    // add pembayaran
    public function add_pembayaran()
    {
        $data = [
            'title' => 'Add Pembayaran',
        ];
        return view('klaim/add_bayar', $data);
    }
}
