<?php

namespace App\Controllers;


use App\Models\M_Po_Bahan;
use App\Models\M_Detail_Barang;
use App\Models\M_Terima_Bahan;
use App\Models\M_Detail_Terima;
use App\Models\M_Bahan_Repair;
use App\Models\M_Detail_Repair;


class BahanController extends BaseController
{

    public function pemesanan_bahan()
    {
        $bahanModel = new M_Po_Bahan();
        $data = [
            'title' => 'Bahan | Titanium',
            'bahan' => $bahanModel->orderBy('id_po_bahan', 'DESC')->findAll()
        ];
        return view('bahan/po_bahan', $data);
    }

    public function add_bahan()
    {
        $bahanModel = new M_Po_Bahan();

        $supplierData = $bahanModel->getAllSupplier();
        $barangData = $bahanModel->getAllBarang();


        $data = [
            'title' => 'Bahan',
            'generatedId' => $bahanModel->generateId(),
            'supplier' => $supplierData,
            'barang' => $barangData,
        ];
        return view('bahan/order_bahan', $data);
    }


    public function create_bahan()
    {
        $poBahanModel = new M_Po_Bahan();
        $detailBarangModel = new M_Detail_Barang();
        $GenerateId = $poBahanModel->generateId();

        // Menghitung total qty dan total jumlah
        $qty = $this->request->getPost('qty');
        $harga = $this->request->getPost('harga');
        $jumlah = array_map(function ($qty, $harga) {
            return $qty * $harga;
        }, $qty, $harga);
        $total_qty = array_sum($qty);
        $total_jumlah = array_sum($jumlah);

        $data = [
            'id_po_bahan' => $this->request->getPost('id_po_bahan'),
            'tanggal' => $this->request->getPost('tanggal'),
            'supplier' => $this->request->getPost('supplier'),
            'jatuh_tempo' => $this->request->getPost('jatuh_tempo'),
            'keterangan' => $this->request->getPost('keterangan'),
            'no_ro' => $this->request->getPost('no_ro'),
            'asuransi' => $this->request->getPost('asuransi'),
            'jenis_mobil' => $this->request->getPost('jenis_mobil'),
            'nama_pemilik' => $this->request->getPost('nama_pemilik'),
            'no_kendaraan' => $this->request->getPost('no_kendaraan'),
            'total_qty' => $total_qty,
            'total_jumlah' => $total_jumlah,
        ];

        // Simpan data PO Bahan
        $poBahanModel->insert($data);

        // Simpan detail barang ke tabel detail_barang
        $kode_barang = $this->request->getPost('kode_barang');
        $nama_barang = $this->request->getPost('nama_barang');
        $satuan = $this->request->getPost('satuan');
        $qty_beli = $this->request->getPost('qty_beli');
        $qty_sisa = $this->request->getPost('qty_sisa');

        if ($kode_barang) {
            foreach ($kode_barang as $index => $kode) {
                $barangData = [
                    'id_kode_barang' => $kode,
                    'nama_barang' => $nama_barang[$index],
                    'qty' => $qty[$index],
                    'satuan' => $satuan[$index],
                    'harga' => $harga[$index],
                    'jumlah' => $jumlah[$index],
                    'qty_beli' => $qty_beli[$index],
                    'qty_sisa' => $qty_sisa[$index],
                    'id_po_bahan' => $data['id_po_bahan']
                ];

                // Simpan data barang
                $detailBarangModel->insert($barangData);
            }
        }

        return redirect()->to(base_url('/order_bahanprev/' . $GenerateId))->with('message', 'Data berhasil disimpan.');
    }

    public function delete_bahan($id)
    {
        $db = \Config\Database::connect();
        $db->transStart(); // Memulai transaksi

        // Menghapus data terkait di tabel detail_barang
        $detailBarangModel = new M_Detail_Barang();
        $detailBarangModel->where('id_po_bahan', $id)->delete();

        // Menghapus data di tabel po_bahan
        $poBahanModel = new M_Po_Bahan();
        $poBahanModel->where('id_po_bahan', $id)->delete();

        $db->transComplete(); // Menyelesaikan transaksi

        if ($db->transStatus() === FALSE) {
            return redirect()->to('po_bahan')->with('error', 'Data gagal dihapus');
        } else {
            return redirect()->to('po_bahan')->with('message', 'Data berhasil dihapus');
        }
    }
    public function prev_bahan($id_po_bahan)
    {
        $bahanModel = new \App\Models\M_Po_Bahan();
        $dataBahan = $bahanModel->find($id_po_bahan);

        if ($dataBahan) {
            // Ambil detail barang dari tabel detail po_bahan
            $detailModel = new \App\Models\M_Detail_Barang();
            $detailBarang = $detailModel->where('id_po_bahan', $id_po_bahan)->findAll();

            // Hitung total qty dan total jumlah
            $totalQty = 0;
            $totalJumlah = 0;

            foreach ($detailBarang as $detail) {
                $totalQty += $detail['qty'];
                $totalJumlah += $detail['jumlah'];
            }

            $data = [
                'title' => 'Detail Bahan',
                'bahan' => $dataBahan,
                'detail_barang' => $detailBarang,
                'total_qty' => $totalQty,
                'total_jumlah' => $totalJumlah,
            ];
            return view('bahan/order_bahanprev', $data);
        } else {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    // public function prev_bahan()
    // {
    //     $data = [
    //         'title' => 'bahan',
    //     ];
    //     return view('bahan/order_terima_bahanprev', $data);
    // }

    // TERIMA BARANG
    public function penerimaan_bahan()
    {
        $TerimaBahanModel = new M_Terima_Bahan();



        $data = [
            'title' => 'Bahan | Titanium',
            'bahan' => $TerimaBahanModel->orderBy('id_penerimaan', 'DESC')->findAll(),


        ];
        return view('bahan/terima_bahan', $data);
    }

    public function bahan_terima_add()
    {
        $TerimaBahanModel = new M_Terima_Bahan();

        // Ambil data supplier dan PO bahan
        $supplierData = $TerimaBahanModel->getAllSupplier();
        $barangData = $TerimaBahanModel->getAllBarang();


        // Siapkan data untuk dikirim ke view
        $data = [
            'title' => 'Bahan | Titanium',
            'generatedIdTerima' => $TerimaBahanModel->generateIdTerima(),
            'supplier' => $supplierData,
            'barang' => $barangData,
        ];

        return view('bahan/order_terima_bahan', $data);
    }

    public function create_terima()
    {
        $terimaBahanModel = new M_Terima_Bahan();
        $detailTerimaModel = new M_Detail_Terima();
        $GenerateIdT = $terimaBahanModel->generateIdTerima();

        // Mengambil data dari request
        $qty = $this->request->getPost('qty');
        $harga = $this->request->getPost('harga');
        $disc = $this->request->getPost('disc');
        $ppn_option = $this->request->getPost('ppn');

        // Menghitung total qty dan total jumlah menggunakan model
        $totals = $detailTerimaModel->calculateTotals($qty, $harga, $disc, $ppn_option);

        // Menyiapkan data untuk disimpan di tabel terima_bahan
        $dataBahan = [
            'id_penerimaan' => $this->request->getPost('no-terima'),
            'tanggal' => $this->request->getPost('tgl'),
            'supplier' => $this->request->getPost('supplier'),
            'jatuh_tempo' => $this->request->getPost('jatuh_tempo'),
            'keterangan' => $this->request->getPost('keterangan'),
            'gudang' => $this->request->getPost('gudang'),
            'no_kendaraan' => $this->request->getPost('no-kendaraan'),
            'kota' => $this->request->getPost('kota'),
            'alamat' => $this->request->getPost('alamat'),
            'nopol' => $this->request->getPost('nopol'),
            'pembayaran' => $this->request->getPost('pembayaran'),
            'ppn' => ($ppn_option == 'PPN') ? 11 : 0,
            'term' => $this->request->getPost('term'),
            'total_qty' => $totals['total_qty'],
            'total_jumlah' => $totals['total_jumlah'],
            'nilai_ppn' => $totals['nilai_ppn'],
            'netto' => $totals['netto'],
        ];

        // Simpan data ke tabel terima_bahan
        $terimaBahanModel->insert($dataBahan);

        // Menyiapkan data untuk disimpan di tabel detail_terima
        $kode_barang = $this->request->getPost('kode_barang');
        $nama_barang = $this->request->getPost('nama_barang');
        $satuan = $this->request->getPost('satuan');
        $no_po = $this->request->getPost('no_po');

        if ($kode_barang) {
            foreach ($kode_barang as $index => $kode) {
                $detailData = [
                    'id_kode_barang' => $kode,
                    'nama_barang' => $nama_barang[$index],
                    'qty' => $qty[$index],
                    'satuan' => $satuan[$index],
                    'harga' => $harga[$index],
                    'disc' => $disc[$index],
                    'jumlah' => $totals['jumlah'][$index],
                    'no_po' => $no_po[$index],
                    'id_penerimaan' => $GenerateIdT,
                ];

                // Simpan data ke tabel detail_terima
                $detailTerimaModel->insert($detailData);
            }
        }

        return redirect()->to(base_url('/order_terima_bahanprev/' . $GenerateIdT))->with('message', 'Data berhasil disimpan.');
    }

    public function delete_terima($id)
    {
        $db = \Config\Database::connect();
        $db->transStart(); // Memulai transaksi

        // Menghapus data terkait di tabel detail_barang
        $detailTerimaModel = new M_Detail_Terima();
        $detailTerimaModel->where('id_penerimaan', $id)->delete();

        // Menghapus data di tabel id_penerimaan
        $terimaBahanModel = new M_Terima_Bahan();
        $terimaBahanModel->where('id_penerimaan', $id)->delete();

        $db->transComplete(); // Menyelesaikan transaksi

        if ($db->transStatus() === FALSE) {
            return redirect()->to('terima_bahan')->with('error', 'Data gagal dihapus');
        } else {
            return redirect()->to('terima_bahan')->with('message', 'Data berhasil dihapus');
        }
    }


    public function bahan_terima_prev($id_penerimaan)
    {
        $terimaBahanModel = new \App\Models\M_Terima_Bahan();

        $TerimaBahanModel = new M_Terima_Bahan();
        $dataTerima = $terimaBahanModel->find($id_penerimaan);
        // ambil
        $supplierData = $TerimaBahanModel->getAllSupplier();
        $barangData = $TerimaBahanModel->getAllBarang();

        if ($dataTerima) {
            // Ambil detail barang dari tabel detail_terima
            $detailTerimaModel = new \App\Models\M_Detail_Terima();
            $detailTerima = $detailTerimaModel->where('id_penerimaan', $id_penerimaan)->findAll();

            // Hitung total qty dan total jumlah
            $totalQty = 0;
            $totalJumlah = 0;

            foreach ($detailTerima as $detail) {
                $totalQty += $detail['qty'];
                $totalJumlah += $detail['jumlah'];
            }
            $data = [
                'title' => 'Detail Bahan',
                'terima' => $dataTerima,
                'detail_terima' => $detailTerima,
                'total_qty' => $totalQty,
                'total_jumlah' => $totalJumlah,
                'supplier' => $supplierData,
                'barang' => $barangData,
            ];
            return view('bahan/order_terima_bahanprev', $data);
        } else {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    public function updateTerima()
    {
        $terimaBahanModel = new M_Terima_Bahan();

        // Mengambil data dari request
        $id_penerimaan = $this->request->getPost('no-terima');
        $dataUpdate = [
            'tanggal' => $this->request->getPost('tgl'),
            'supplier' => $this->request->getPost('supplier'),
            'jatuh_tempo' => $this->request->getPost('jatuh_tempo'),
            'keterangan' => $this->request->getPost('keterangan'),
            'gudang' => $this->request->getPost('gudang'),
            'no_kendaraan' => $this->request->getPost('no-kendaraan'),
            'kota' => $this->request->getPost('kota'),
            'alamat' => $this->request->getPost('alamat'),
            'nopol' => $this->request->getPost('nopol'),
            'pembayaran' => $this->request->getPost('pembayaran'),
            'ppn' => ($this->request->getPost('ppn') == 'PPN') ? 11 : 0,
            'term' => $this->request->getPost('term')
        ];

        // Melakukan update pada tabel terima_bahan
        $terimaBahanModel->update($id_penerimaan, $dataUpdate);

        return redirect()->to(base_url('/order_terima_bahanprev/' . $id_penerimaan))->with('message', 'Data berhasil diperbarui.');
    }

    public function createDetailTambah()
    {
        $detailTerimaModel = new M_Detail_Terima();

        $id_penerimaan = $this->request->getPost('id_penerimaan');
        if (!$id_penerimaan) {
            return redirect()->back()->with('error', 'ID Terima PO tidak ditemukan.');
        }

        // Validasi input
        if ($this->request->getMethod() === 'post') {
            $validation = \Config\Services::validation();

            $validation->setRules([
                'kode_barang' => 'required',
                'nama_barang' => 'required',
                'qty'         => 'required|numeric',
                'satuan'      => 'required',
                'harga'       => 'required|numeric',
                'disc'        => 'permit_empty|numeric'
            ]);

            if ($validation->withRequest($this->request)->run()) {
                // Data valid, simpan ke database
                $data = [
                    'kode_barang' => $this->request->getPost('kode_barang'),
                    'nama_barang' => $this->request->getPost('nama_barang'),
                    'qty'         => $this->request->getPost('qty'),
                    'satuan'      => $this->request->getPost('satuan'),
                    'harga'       => $this->request->getPost('harga'),
                    'disc'        => $this->request->getPost('disc'),
                    'jumlah'      => $this->request->getPost('qty') * ($this->request->getPost('harga') - $this->request->getPost('disc')),
                    // Pastikan untuk menambahkan field lain yang dibutuhkan
                ];

                $detailTerimaModel->insert($data);

                return redirect()->to('/order_terima_bahanprev')->with('success', 'Detail Terima berhasil ditambahkan');
            } else {
                // Jika validasi gagal
                return redirect()->back()->withInput()->with('errors', $validation->getErrors());
            }
        }
    }



    public function repair_materialbahan()
    {

        $data = [
            'title' => 'Bahan | Titanium',
        ];
        return view('bahan/repair_material', $data);
    }

    public function bahan_repair_add()
    {
        $bahanRepairModel = new M_Bahan_Repair();
        $data = [
            'title' => 'Bahan | Titanium',
            'generateIdrepair' => $bahanRepairModel->generateId(),
        ];
        return view('bahan/order_repair_bahan', $data);
    }

    public function createRepairBahan()
    {
        $bahanRepairModel = new M_Bahan_Repair();
        $detailRepairModel = new M_Detail_Repair();
        $generatedId = $bahanRepairModel->generateId();

        // Menghitung total qty dan total nilai
        $qty_B = $this->request->getPost('qty_B');
        $qty_T = $this->request->getPost('qty_T');
        $qty_K = $this->request->getPost('qty_K');
        $hpp = $this->request->getPost('hpp');
        // $nilai = array_map(function ($qty_B, $hpp) {
        //     return $qty_B * $hpp;
        // }, $qty_B, $hpp);
        $total_qty_B = array_sum($qty_B);
        $total_qty_T = array_sum($qty_T);
        $total_qty_K = array_sum($qty_K);
        $total_hpp = array_sum($hpp);

        $data = [
            'id_material' => $generatedId,
            'tanggal' => $this->request->getPost('tanggal'),
            'no_repair' => $this->request->getPost('no_repair'),
            'gudang' => $this->request->getPost('gudang'),
            'tanggal_masuk' => $this->request->getPost('tanggal_masuk'),
            'no_kendaraan' => $this->request->getPost('no_kendaraan'),
            'jenis_mobil' => $this->request->getPost('jenis_mobil'),
            'warna' => $this->request->getPost('warna'),
            'tahun' => $this->request->getPost('tahun'),
            'nama_pemilik' => $this->request->getPost('nama_pemilik'),
            'keterangan' => $this->request->getPost('keterangan'),
            'total_qty_B' => $total_qty_B,
            'total_qty_T' => $total_qty_T,
            'total_qty_K' => $total_qty_K,
            'total_hpp' => $total_hpp,
            
            // Pastikan untuk menambahkan field lain yang dibutuhkan
        ];

        // Simpan data bahan repair
        $bahanRepairModel->insert($data);

        // Simpan detail repair ke tabel detail_repair
        $kode_barang = $this->request->getPost('kode_barang');
        $nama_barang = $this->request->getPost('nama_barang');
        $qty_B = $this->request->getPost('qty_B');
        $sat_b = $this->request->getPost('sat_b');
        $qty_T = $this->request->getPost('qty_T');
        $sat_T = $this->request->getPost('sat_T');
        $qty_K = $this->request->getPost('qty_K');
        $sat_K = $this->request->getPost('sat_K');
        $hpp = $this->request->getPost('hpp');
        $nilai = $this->request->getPost('nilai');

        if ($kode_barang) {
            foreach ($kode_barang as $index => $kode) {
                $detailData = [
                    'id_kode_barang' => $kode,
                    'nama_barang' => $nama_barang[$index],
                    'qty_B' => $qty_B[$index],
                    'sat_b' => $sat_b[$index],
                    'qty_T' => $qty_T[$index],
                    'sat_T' => $sat_T[$index],
                    'qty_K' => $qty_K[$index],
                    'sat_K' => $sat_K[$index],
                    'hpp' => $hpp[$index],
                    'nilai' => $nilai[$index],
                    'id_material' => $data['id_material']
                ];

                // Simpan data detail repair
                $detailRepairModel->insert($detailData);
            }
        }

        return redirect()->to(base_url('/repair_material'))->with('message', 'Data berhasil disimpan.');
    }

    public function laporan_mutasigudang()
    {
        $data = [
            'title' => 'Bahan | Titanium',
        ];
        return view('bahan/laporan_mutasi', $data);
    }



    public function bahan_repair_prev()
    {
        $data = [
            'title' => 'Bahan | Titanium',
        ];
        return view('bahan/order_repair_bahanprev', $data);
    }
}
