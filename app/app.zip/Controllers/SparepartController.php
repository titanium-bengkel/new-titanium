<?php

namespace App\Controllers;



class SparepartController extends BaseController
{
    
    public function permintaan_sparepart()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/permintaan_part', $data);
    }

    public function pemesanan_sparepart()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/pesan_part', $data);
    }

    public function penerimaan_sparepart()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/terima_part', $data);
    }

    public function permintaan_sparepart_supply()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/minta_part_supp', $data);
    }

    public function supply_asuransi()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/supp_asuransi', $data);
    }

    public function repair_material_sparepart()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/repair_material_part', $data);
    }

    public function mutasi_gudang_sparepart()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/mutasi_gudang_part', $data);
    }

    public function part_dalam_pesanan()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/waiting_part', $data);
    }

    public function part_diterima()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/sparepart_masuk', $data);
    }

    public function sparepart_salvage()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/part_salvage', $data);
    }

    public function sparepart_sisa()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/part_sisa', $data);
    }

    public function stok_sparepart()
    {
        $data =[
            'title' => 'Sparepart',
        ];
        return view('sparepart/stok_part', $data);
    }

    // ADD PART
    public function add_part()
    {
        $data = [
            'title' => 'Sparepart',
        ];
        return view('sparepart/beli_part', $data);
    }

    public function add_partpreview()
    {
        $data = [
            'title' => 'Sparepart',
        ];
        return view('sparepart/beli_partprev', $data);
    }

    public function add_terimapart()
    {
        $data = [
            'title' => 'Sparepart',
        ];
        return view('sparepart/order_pos_terimapart', $data);
    }

    public function add_terimapart_preview()
    {
        $data = [
            'title' => 'Sparepart',
        ];
        return view('sparepart/order_pos_terimapartprev', $data);
    }

    public function add_supp_asuransi()
    {
        $data = [
            'title' => 'Sparepart',
        ];
        return view('sparepart/supp_asuransi_add', $data);
    }

    public function prev_supp_asuransi()
    {
        $data = [
            'title' => 'Sparepart',
        ];
        return view('sparepart/supp_asuransi_prev', $data);
    }

    public function add_repair_material()
    {
        $data = [
            'title' => 'Sparepart',
        ];
        return view('sparepart/repair_material_add', $data);
    }

    public function prev_repair_preview()
    {
        $data = [
            'title' => 'Sparepart',
        ];
        return view('sparepart/repair_material_prev', $data);
    }
}
