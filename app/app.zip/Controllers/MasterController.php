<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\M_BarangK;
use App\Models\M_Barang;
use App\Models\M_Group;
use App\Models\M_Pengerjaan;
use App\Models\M_Jasa;
use App\Models\M_Alokasi;
use App\Models\M_Gudang;
use App\Models\M_Salesman;
use App\Models\M_Asuransi;
use App\Models\M_Coa;
use App\Models\M_Supplier;
use CodeIgniter\Controller;

class MasterController extends BaseController
{

    protected $userModel;
    protected $m_BarangK;
    protected $m_Barang;
    protected $m_Group;
    protected $m_Pengerjaan;
    protected $m_Jasa;
    protected $m_Alokasi;
    protected $m_Gudang;
    protected $m_Salesman;
    protected $m_Asuransi;
    protected $m_Coa;
    protected $m_Supplier;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->m_BarangK = new M_BarangK();
        $this->m_Barang = new M_Barang();
        $this->m_Group = new M_Group();
        $this->m_Pengerjaan = new M_Pengerjaan();
        $this->m_Jasa = new M_Jasa();
        $this->m_Alokasi = new M_Alokasi();
        $this->m_Gudang = new M_Gudang();
        $this->m_Salesman = new M_Salesman();
        $this->m_Asuransi = new M_Asuransi();
        $this->m_Coa = new M_Coa();
        $this->m_Supplier = new M_Supplier();
    }

    public function barangkategori()
    {
        $user_id = session()->get('user_id');
        $kategori = $this->m_BarangK->getBarangKategoriWithUsername();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Barang Kategori',
            'kategori' => $kategori,
            'username' => $username
        ];

        return view('master/barangkategori', $data);
    }

    public function createBarang()
    {
        // Mendapatkan user_id dari session
        $user_id = session()->get('user_id');

        // Validasi jika user_id tidak ditemukan di sesi
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        // Mendapatkan data dari form
        $data = [
            'userid' => $user_id,
            'kode' => $this->request->getPost('kode'),
            'nama' => $this->request->getPost('nama'),
            'stok' => $this->request->getPost('stok'),
            'keterangan' => $this->request->getPost('keterangan'),
            'status' => null // Atur status sesuai kebutuhan Anda
        ];


        // Memanggil model untuk menyimpan data baru
        if (!$this->m_BarangK->insertBarangKategori($data));

        // Tampilkan SweetAlert dengan tipe toast setelah proses update berhasil
        $alert = [
            'title' => 'Sukses!',
            'text' => 'Data berhasil Ditambahkan .',
            'icon' => 'success',
            'toast' => true,
            'position' => 'top-end',
            'showConfirmButton' => false,
            'timer' => 3000
        ];

        return redirect()->to('master/barangkategori')->with('alert', $alert);
    }
    // Metode untuk menyimpan perubahan barang yang sudah diedit
    public function updateBarang($id)
    {
        // Ambil data dari form
        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama' => $this->request->getPost('nama'),
            'stok' => $this->request->getPost('stok'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        // Update data di database
        $this->m_BarangK->updateBarangKategori($id, $data);

        // Tampilkan SweetAlert dengan tipe toast setelah proses update berhasil
        $alert = [
            'title' => 'Sukses!',
            'text' => 'Data berhasil diperbarui.',
            'icon' => 'success',
            'toast' => true,
            'position' => 'top-end',
            'showConfirmButton' => false,
            'timer' => 3000
        ];

        return redirect()->to('master/barangkategori')->with('alert', $alert);
    }

    // Method to delete a Barang
    public function deleteBarang($id)
    {
        $this->m_Barang->deleteBarangKategori($id);

        // Tampilkan SweetAlert dengan tipe toast setelah proses delete berhasil
        $alert = [
            'title' => 'Sukses!',
            'text' => 'Data berhasil dihapus.',
            'icon' => 'success',
            'toast' => true,
            'position' => 'top-end',
            'showConfirmButton' => false,
            'timer' => 3000
        ];

        return redirect()->to('master/barangkategori')->with('alert', $alert);
    }
    //  Barang Group

    public function baranggroup()
    {
        // Mendapatkan user_id dari session
        $userid = session()->get('user_id');

        // Memeriksa apakah user_id tersedia dalam session
        if (!$userid) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        // Mengambil data kategori dari model
        $categories = $this->m_Group->getKategori();

        // Mengambil data grup dari model
        $groups = $this->m_Group->getBarangGroupTableJoin();

        // Mengirim data ke view dengan variabel title, categories, dan groups
        return view('master/baranggroup', [
            'title' => 'Barang Group',
            'categories' => $categories,
            'groups' => $groups
        ]);
    }

    public function createBarangGroup()
    {
        // Mendapatkan user_id dari session
        $userid = session()->get('user_id');

        // Memeriksa apakah user_id tersedia dalam session
        if (!$userid) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        // Validasi input
        $validationRules = [
            'kodegroup' => 'required',
            'namagroup' => 'required',
            'kodekategori' => 'required',
            'kodeperkiraan' => 'required',
            'keterangan' => 'required'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('error', $this->validator->getErrors());
        }

        // Memasukkan data baru menggunakan model
        $data = [
            'kodegroup' => $this->request->getPost('kodegroup'),
            'namagroup' => $this->request->getPost('namagroup'),
            'user_id' => $userid,
            'kodekategori' => $this->request->getPost('kodekategori'),
            'kodeperkiraan' => $this->request->getPost('kodeperkiraan'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        if (!$this->m_Group->insertBarangGroup($data)) {
            return redirect()->back()->withInput()->with('error', 'Gagal Menambahkan Barang Group');
        }

        // Redirect kembali ke halaman master/baranggroup dengan pesan sukses
        return redirect()->to('master/baranggroup')->with('success', 'Barang Group Berhasil Ditambahkan');
    }
    public function updateBarangGroup($id)
    {
        // Mendapatkan user_id dari session
        $userid = session()->get('user_id');

        // Memeriksa apakah user_id tersedia dalam session
        if (!$userid) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        // Validasi input
        $validationRules = [
            'edit_id' => 'required',
            'edit_kodegroup' => 'required',
            'edit_namagroup' => 'required',
            'edit_kodekategori' => 'required',
            'edit_kodeperkiraan' => 'required',
            'edit_keterangan' => 'required'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('error', $this->validator->getErrors());
        }

        // Memperbarui data menggunakan model
        $data = [
            'kodegroup' => $this->request->getPost('edit_kodegroup'),
            'namagroup' => $this->request->getPost('edit_namagroup'),
            'user_id' => $userid,
            'kodekategori' => $this->request->getPost('edit_kodekategori'),
            'kodeperkiraan' => $this->request->getPost('edit_kodeperkiraan'),
            'keterangan' => $this->request->getPost('edit_keterangan')
        ];

        // ID data yang akan diupdate
        $id = $this->request->getPost('edit_id');

        // Memanggil model untuk melakukan update
        if (!$this->m_Group->updateBarangGroup($id, $data)) {
            return redirect()->back()->withInput()->with('error', 'Gagal Memperbarui Barang Group');
        }

        // Redirect kembali ke halaman master/baranggroup dengan pesan sukses
        return redirect()->to('master/baranggroup')->with('success', 'Barang Group Berhasil Diperbarui');
    }

    // public function deleteBarangGroup($id)
    // {
    //     $this->m_Group->deleteBarangGroup($id);
    //     return redirect()->to('/master/baranggroup')->with('success', 'Data deleted successfully');
    // }
    public function barang()
    {
        $user_id = session()->get('user_id');
        $barang = $this->m_Barang->getAllBarangWithDetails();
        $kategori = $this->m_Group->getKategori();
        $groups = $this->m_Group->getGroups();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Barang',
            'barang' => $barang,
            'kategori' => $kategori,
            'groups' => $groups,
            'username' => $username
        ];

        return view('master/barang', $data);
    }

    public function createBar()
    {
        $user_id = session()->get('user_id');
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama' => $this->request->getPost('nama'),
            'kode_group' => $this->request->getPost('kode_group'),
            'sat_B' => $this->request->getPost('sat_B'),
            'isi_B' => $this->request->getPost('isi_B'),
            'sat_T' => $this->request->getPost('sat_T'),
            'isi_T' => $this->request->getPost('isi_T'),
            'sat_K' => $this->request->getPost('sat_K'),
            'stok_minimal' => $this->request->getPost('stok_minimal'),
            'stok_maksimal' => $this->request->getPost('stok_maksimal'),
            'harga_beli' => $this->request->getPost('harga_beli'),
            'harga_jual' => $this->request->getPost('harga_jual'),
            'kode_kategori' => $this->request->getPost('kode_kategori'),
            'nama_kategori' => $this->request->getPost('nama_kategori'),
            'stok' => $this->request->getPost('stok'),
            'tahun' => $this->request->getPost('tahun'),
            'periode' => $this->request->getPost('periode'),
            'upd' => $this->request->getPost('upd'),
            'hargabeli_B' => $this->request->getPost('hargabeli_B'),
            'hargabeli_T' => $this->request->getPost('hargabeli_T'),
            'hargajual_B' => $this->request->getPost('hargajual_B'),
            'hargajual_T' => $this->request->getPost('hargajual_T'),
            'aktif' => $this->request->getPost('aktif'),
            'user_id' => $user_id
        ];

        if (!$this->m_Barang->insertBarang($data)) {
            return redirect()->to('master/barang')->with('error', 'Gagal Menambahkan Data Barang');
        }

        return redirect()->to('master/barang')->with('success', 'Data Barang Berhasil Ditambahkan');
    }

    public function updateBar($id)
    {
        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama' => $this->request->getPost('nama'),
            'kode_group' => $this->request->getPost('kode_group'),
            'sat_B' => $this->request->getPost('sat_B'),
            'isi_B' => $this->request->getPost('isi_B'),
            'sat_T' => $this->request->getPost('sat_T'),
            'isi_T' => $this->request->getPost('isi_T'),
            'sat_K' => $this->request->getPost('sat_K'),
            'stok_minimal' => $this->request->getPost('stok_minimal'),
            'stok_maksimal' => $this->request->getPost('stok_maksimal'),
            'harga_beli' => $this->request->getPost('harga_beli'),
            'harga_jual' => $this->request->getPost('harga_jual'),
            'kode_kategori' => $this->request->getPost('kode_kategori'),
            'nama_kategori' => $this->request->getPost('nama_kategori'),
            'stok' => $this->request->getPost('stok'),
            'tahun' => $this->request->getPost('tahun'),
            'periode' => $this->request->getPost('periode'),
            'upd' => $this->request->getPost('upd'),
            'hargabeli_B' => $this->request->getPost('hargabeli_B'),
            'hargabeli_T' => $this->request->getPost('hargabeli_T'),
            'hargajual_B' => $this->request->getPost('hargajual_B'),
            'hargajual_T' => $this->request->getPost('hargajual_T'),
            'aktif' => $this->request->getPost('aktif')
        ];

        $this->m_Barang->updateBarang($id, $data);

        $alert = [
            'title' => 'Sukses!',
            'text' => 'Data berhasil diperbarui.',
            'icon' => 'success',
            'toast' => true,
            'position' => 'top-end',
            'showConfirmButton' => false,
            'timer' => 3000
        ];

        return redirect()->to('master/barang')->with('alert', $alert);
    }


    public function pengerjaan()
    {
        $user_id = session()->get('user_id');
        $kategori = $this->m_Pengerjaan->getPengerjaanWithUsername();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Pengerjaan',
            'kategori' => $kategori,
            'username' => $username
        ];

        return view('master/pengerjaan', $data);
    }

    public function createPengerjaan()
    {
        // Mendapatkan user_id dari session
        $user_id = session()->get('user_id');

        // Validasi jika user_id tidak ditemukan di sesi
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        // Mendapatkan data dari form
        $data = [
            'user_id' => $user_id,
            'kode_pengerjaan' => $this->request->getPost('kode_pengerjaan'),
            'nama_pengerjaan' => $this->request->getPost('nama_pengerjaan'),
            'keterangan_pengerjaan' => $this->request->getPost('keterangan_pengerjaan'),
        ];

        // Memanggil model untuk menyimpan data baru
        if (!$this->m_Pengerjaan->insertPengerjaan($data)) {
            return redirect()->to('master/pengerjaan')->with('error', 'Gagal Menambahkan Pengerjaan');
        }

        return redirect()->to('master/pengerjaan')->with('success', 'Pengerjaan Berhasil Ditambahkan');
    }

    // Method untuk menyimpan perubahan barang yang sudah diedit
    public function updatePengerjaan($id)
    {
        $data = [
            'kode_pengerjaan' => $this->request->getPost('kode_pengerjaan'),
            'nama_pengerjaan' => $this->request->getPost('nama_pengerjaan'),
            'keterangan_pengerjaan' => $this->request->getPost('keterangan_pengerjaan'),
            'user_id' => session()->get('user_id')  // Menggunakan session untuk mendapatkan user_id
        ];

        $this->m_Pengerjaan->updatePengerjaan($id, $data);

        return redirect()->back()->with('success', 'Pengerjaan updated successfully');
    }

    // Alokasi
    public function alokasibarang()
    {
        $user_id = session()->get('user_id');
        $kategori = $this->m_Alokasi->getAlokasiWithUsername();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Alokasi Barang',
            'kategori' => $kategori,
            'username' => $username
        ];

        return view('master/alokasibarang', $data);
    }

    public function createAlokasi()
    {
        $user_id = session()->get('user_id');

        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        $data = [
            'user_id' => $user_id,
            'kode_alokasi' => $this->request->getPost('kode_alokasi'),
            'kode_perkiraan' => $this->request->getPost('kode_perkiraan'),
            'nama_alokasi' => $this->request->getPost('nama_alokasi'),
            'keterangan_alokasi' => $this->request->getPost('keterangan_alokasi'),
        ];

        if (!$this->m_Alokasi->insertAlokasi($data)) {
            return redirect()->to('master/alokasibarang')->with('error', 'Gagal Menambahkan Alokasi Barang');
        }

        return redirect()->to('master/alokasibarang')->with('success', 'Alokasi Barang Berhasil Ditambahkan');
    }

    // Method untuk menyimpan perubahan barang yang sudah diedit
    public function updateAlokasi($id)
    {
        $data = [
            'kode_alokasi' => $this->request->getPost('kode_alokasi'),
            'kode_perkiraan' => $this->request->getPost('kode_perkiraan'),
            'nama_alokasi' => $this->request->getPost('nama_alokasi'),
            'keterangan_alokasi' => $this->request->getPost('keterangan_alokasi'),
            'user_id' => session()->get('user_id')  // Menggunakan session untuk mendapatkan user_id
        ];

        $this->m_Alokasi->updateAlokasi($id, $data);

        return redirect()->back()->with('success', 'Alokasi Barang updated successfully');
    }
    // -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public function jasa()
    {
        $user_id = session()->get('user_id');
        $jasa = $this->m_Jasa->getAllJasaWithDetails();
        $coa = $this->m_Coa->getCoa();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Jasa',
            'jasa' => $jasa,
            'coa' => $coa,
            'username' => $username
        ];

        return view('master/jasa', $data);
    }

    public function createJasa()
    {
        $user_id = session()->get('user_id');
        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama_jasa' => $this->request->getPost('nama_jasa'),
            'kode_biaya' => $this->request->getPost('kode_biaya'),
            'kode_alokasi' => $this->request->getPost('kode_alokasi'),
            'keterangan' => $this->request->getPost('keterangan'),
            'user_id' => $user_id
        ];

        if (!$this->m_Jasa->insertJasa($data)) {
            return redirect()->to('master/jasa')->with('error', 'Gagal Menambahkan Data Jasa');
        }

        return redirect()->to('master/jasa')->with('success', 'Data Jasa Berhasil Ditambahkan');
    }

    public function updateJasa($id)
    {
        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama_jasa' => $this->request->getPost('nama_jasa'),
            'kode_biaya' => $this->request->getPost('kode_biaya'),
            'kode_alokasi' => $this->request->getPost('kode_alokasi'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        $this->m_Jasa->updateJasa($id, $data);

        $alert = [
            'title' => 'Sukses!',
            'text' => 'Data berhasil diperbarui.',
            'icon' => 'success',
            'toast' => true,
            'position' => 'top-end',
            'showConfirmButton' => false,
            'timer' => 3000
        ];

        return redirect()->to('master/jasa')->with('alert', $alert);
    }


    public function asuransi()
    {
        $user_id = session()->get('user_id');
        $asuransi = $this->m_Asuransi->getAsuransiWithUsername();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Asuransi',
            'asuransi' => $asuransi,
            'username' => $username
        ];

        return view('master/asuransi', $data);
    }

    public function createAsuransi()
    {
        $user_id = session()->get('user_id');

        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        $data = [
            'user_id' => $user_id,
            'kode' => $this->request->getPost('kode'),
            'nama_asuransi' => $this->request->getPost('nama_asuransi'),
            'status_member' => $this->request->getPost('status_member'),
            'kode_alokasi' => $this->request->getPost('kode_alokasi'),
            'kode_group' => $this->request->getPost('kode_group'),
            'alamat' => $this->request->getPost('alamat'),
            'kodepos' => $this->request->getPost('kodepos'),
            'kota' => $this->request->getPost('kota'),
            'telp' => $this->request->getPost('telp'),
            'fax' => $this->request->getPost('fax'),
            'no_hp_whatsapp' => $this->request->getPost('no_hp_whatsapp'),
            'email' => $this->request->getPost('email'),
            'contact_person' => $this->request->getPost('contact_person'),
            'discount' => $this->request->getPost('discount'),
            'npwp' => $this->request->getPost('npwp'),
            'plafond' => $this->request->getPost('plafond'),
            'max_bill' => $this->request->getPost('max_bill'),
            'customer_pos' => $this->request->getPost('customer_pos'),
            'kode_gudang' => $this->request->getPost('kode_gudang'),
            'status' => $this->request->getPost('status'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        if (!$this->m_Asuransi->insertAsuransi($data)) {
            return redirect()->to('master/asuransi')->with('error', 'Gagal Menambahkan Data Asuransi');
        }

        return redirect()->to('master/asuransi')->with('success', 'Data Asuransi Berhasil Ditambahkan');
    }

    public function updateAsuransi($id)
    {
        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama_asuransi' => $this->request->getPost('nama_asuransi'),
            'status_member' => $this->request->getPost('status_member'),
            'kode_alokasi' => $this->request->getPost('kode_alokasi'),
            'kode_group' => $this->request->getPost('kode_group'),
            'alamat' => $this->request->getPost('alamat'),
            'kodepos' => $this->request->getPost('kodepos'),
            'kota' => $this->request->getPost('kota'),
            'telp' => $this->request->getPost('telp'),
            'fax' => $this->request->getPost('fax'),
            'no_hp_whatsapp' => $this->request->getPost('no_hp_whatsapp'),
            'email' => $this->request->getPost('email'),
            'contact_person' => $this->request->getPost('contact_person'),
            'discount' => $this->request->getPost('discount'),
            'npwp' => $this->request->getPost('npwp'),
            'plafond' => $this->request->getPost('plafond'),
            'max_bill' => $this->request->getPost('max_bill'),
            'customer_pos' => $this->request->getPost('customer_pos'),
            'kode_gudang' => $this->request->getPost('kode_gudang'),
            'status' => $this->request->getPost('status'),
            'keterangan' => $this->request->getPost('keterangan'),
            'user_id' => session()->get('user_id')
        ];

        $this->m_Asuransi->updateAsuransi($id, $data);

        return redirect()->back()->with('success', 'Data Asuransi berhasil diperbarui');
    }
    // ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public function gudang()
    {
        $user_id = session()->get('user_id');
        $kategori = $this->m_Gudang->getGudangWithUsername();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Gudang',
            'kategori' => $kategori,
            'username' => $username
        ];

        return view('master/gudang', $data);
    }

    public function createGudang()
    {
        $user_id = session()->get('user_id');

        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        $data = [
            'user_id' => $user_id,
            'telp' => $this->request->getPost('telp'),
            'fax' => $this->request->getPost('fax'),
            'kota' => $this->request->getPost('kota'),
            'alamat' => $this->request->getPost('alamat'),
            'kode' => $this->request->getPost('kode'),
            'gudangpos' => $this->request->getPost('gudangpos'),
            'nama' => $this->request->getPost('nama'),
            'contactperson' => $this->request->getPost('contactperson'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        if (!$this->m_Gudang->insertGudang($data)) {
            return redirect()->to('master/gudang')->with('error', 'Gagal Menambahkan Data Gudang');
        }

        return redirect()->to('master/gudang')->with('success', 'Data Gudang Berhasil Ditambahkan');
    }

    // Method untuk menyimpan perubahan barang yang sudah diedit
    public function updateGudang($id)
    {
        $data = [
            'telp' => $this->request->getPost('telp'),
            'fax' => $this->request->getPost('fax'),
            'kota' => $this->request->getPost('kota'),
            'alamat' => $this->request->getPost('alamat'),
            'kode' => $this->request->getPost('kode'),
            'gudangpos' => $this->request->getPost('gudangpos'),
            'nama' => $this->request->getPost('nama'),
            'contactperson' => $this->request->getPost('contactperson'),
            'keterangan' => $this->request->getPost('keterangan'),
            'user_id' => session()->get('user_id')  // Menggunakan session untuk mendapatkan user_id
        ];

        $this->m_Gudang->updateGudang($id, $data);

        return redirect()->back()->with('success', 'Data Gudang updated successfully');
    }

    public function salesman()
    {
        $user_id = session()->get('user_id');
        $salesmen = $this->m_Salesman->getSalesmanWithUsername();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Salesman',
            'salesmen' => $salesmen,
            'username' => $username
        ];

        return view('master/salesman', $data);
    }

    public function createSalesman()
    {
        $user_id = session()->get('user_id');

        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID not found in session');
        }

        $data = [
            'user_id' => $user_id,
            'kode' => $this->request->getPost('kode'),
            'nama' => $this->request->getPost('nama'),
            'keterangan' => $this->request->getPost('keterangan'),
            'alamat' => $this->request->getPost('alamat'),
            'kota' => $this->request->getPost('kota'),
            'telp' => $this->request->getPost('telp'),
            'target' => $this->request->getPost('target')
        ];

        if (!$this->m_Salesman->insertSalesman($data)) {
            return redirect()->to('master/salesman')->with('error', 'Gagal Menambahkan Data Salesman');
        }

        return redirect()->to('master/salesman')->with('success', 'Data Salesman Berhasil Ditambahkan');
    }

    public function updateSalesman($id)
    {
        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama' => $this->request->getPost('nama'),
            'keterangan' => $this->request->getPost('keterangan'),
            'alamat' => $this->request->getPost('alamat'),
            'kota' => $this->request->getPost('kota'),
            'telp' => $this->request->getPost('telp'),
            'target' => $this->request->getPost('target'),
            'user_id' => session()->get('user_id')
        ];

        $this->m_Salesman->updateSalesman($id, $data);

        return redirect()->back()->with('success', 'Data Salesman Berhasil Diperbarui');
    }


    public function coa()
    {
        $user_id = session()->get('user_id');
        $coa = $this->m_Coa->getCoaWithUsername();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Chart Of Account',
            'coa' => $coa,
            'username' => $username
        ];

        return view('master/coa', $data);
    }

    // Method untuk menyimpan data baru Chart Of Account
    public function createCoa()
    {
        $user_id = session()->get('user_id');

        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID tidak ditemukan di sesi');
        }

        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama_account' => $this->request->getPost('nama_account'),
            'level' => $this->request->getPost('level'),
            'kode_head' => $this->request->getPost('kode_head'),
            'kelompok' => $this->request->getPost('kelompok'),
            'posisi' => $this->request->getPost('posisi'),
            'keterangan' => $this->request->getPost('keterangan'),
            'user_id' => $user_id,
            'transaksi' => $this->request->getPost('transaksi')
        ];

        if (!$this->m_Coa->insertCoa($data)) {
            return redirect()->to('master/coa')->with('error', 'Gagal Menambahkan Data Chart Of Account');
        }

        return redirect()->to('master/coa')->with('success', 'Data Chart Of Account Berhasil Ditambahkan');
    }
    // Method untuk memperbarui data Chart Of Account
    public function updateCoa($id)
    {
        $user_id = session()->get('user_id');

        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID tidak ditemukan di sesi');
        }

        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama_account' => $this->request->getPost('nama_account'),
            'level' => $this->request->getPost('level'),
            'kode_head' => $this->request->getPost('kode_head'),
            'kelompok' => $this->request->getPost('kelompok'),
            'posisi' => $this->request->getPost('posisi'),
            'keterangan' => $this->request->getPost('keterangan'),
            'user_id' => $user_id,
            'transaksi' => $this->request->getPost('transaksi')
        ];

        if (!$this->m_Coa->updateCoa($id, $data)) {
            return redirect()->to('master/coa')->with('error', 'Gagal Memperbarui Data Chart Of Account');
        }

        return redirect()->to('master/coa')->with('success', 'Data Chart Of Account Berhasil Diperbarui');
    }

    // Method untuk menghapus data Chart Of Account
    public function delete($id)
    {
        $this->m_Coa->deleteCoa($id);
        return redirect()->to('master/coa');
    }

    public function supplier()
    {
        $user_id = session()->get('user_id');
        $suppliers = $this->m_Supplier->getSupplierWithUser();

        $username = '';
        if ($user_id) {
            $user = $this->userModel->find($user_id);
            if ($user) {
                $username = $user['username'];
            }
        }

        $data = [
            'title' => 'Supplier',
            'suppliers' => $suppliers,
            'username' => $username
        ];

        return view('master/supplier', $data);
    }

    public function createSupplier()
    {
        $user_id = session()->get('user_id');

        if (!$user_id) {
            return redirect()->to('/')->with('error', 'User ID tidak ditemukan di sesi');
        }

        $data = [
            'user_id' => $user_id,
            'kode' => $this->request->getPost('kode'),
            'nama' => $this->request->getPost('nama'),
            'alamat' => $this->request->getPost('alamat'),
            'email' => $this->request->getPost('email'),
            'contactperson' => $this->request->getPost('contactperson'),
            'telp' => $this->request->getPost('telp'),
            'kota' => $this->request->getPost('kota'),
            'fax' => $this->request->getPost('fax'),
            'hp' => $this->request->getPost('hp'),
            'rekening' => $this->request->getPost('rekening'),
            'term' => $this->request->getPost('term'),
            'npwp' => $this->request->getPost('npwp'),
            'status' => $this->request->getPost('status'),
            'inisial' => $this->request->getPost('inisial'),
            'keterangan' => $this->request->getPost('keterangan')
        ];

        if (!$this->m_Supplier->insertSupplier($data)) {
            return redirect()->to('master/supplier')->with('error', 'Gagal Menambahkan Data Supplier');
        }

        return redirect()->to('master/supplier')->with('success', 'Data Supplier Berhasil Ditambahkan');
    }


    public function updateSupplier($id)
    {
        $data = [
            'kode' => $this->request->getPost('kode'),
            'nama' => $this->request->getPost('nama'),
            'alamat' => $this->request->getPost('alamat'),
            'email' => $this->request->getPost('email'),
            'contactperson' => $this->request->getPost('contactperson'),
            'telp' => $this->request->getPost('telp'),
            'kota' => $this->request->getPost('kota'),
            'fax' => $this->request->getPost('fax'),
            'hp' => $this->request->getPost('hp'),
            'rekening' => $this->request->getPost('rekening'),
            'term' => $this->request->getPost('term'),
            'npwp' => $this->request->getPost('npwp'),
            'status' => $this->request->getPost('status'),
            'inisial' => $this->request->getPost('inisial'),
            'keterangan' => $this->request->getPost('keterangan'),
            'user_id' => session()->get('user_id')
        ];

        $this->m_Supplier->updateSupplier($id, $data);

        return redirect()->back()->with('success', 'Data Supplier Berhasil Diperbarui');
    }
}
