<?php

namespace App\Controllers;


class KeuanganController extends BaseController
{

    public function hutang_supp()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/hutang', $data);
    }

    public function pembayaran_hutang()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/bayar_hutang', $data);
    }

    public function laporan_pembelian()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/pembelian', $data);
    }

    public function jurnal_kasbank()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/kas_bank', $data);
    }

    public function kaskecil()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/kas_kecil', $data);
    }

    public function keluarkasbesar()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/keluar_kasbesar', $data);
    }

    public function jurnal_kasmasuk()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/kas_masuk', $data);
    }

    public function jurnal_kaskeluar()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/kas_keluar', $data);
    }

    public function repairoder_list()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/ro_list', $data);
    }

    public function repair_materialjasa()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/material_jasa', $data);
    }

    public function add_bayar_hutang()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/bayar_hutang_add', $data);
    }

    public function prev_bayar_hutang()
    {
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/bayar_hutang_prev', $data);
    }

    public function add_pembelian()
    {  
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/pembelian_add', $data);
    }

    public function prev_pembelian()
    {  
        $data = [
            'title' => 'Keuangan',
        ];
        return view('keuangan/pembelian_prev', $data);
    }

}